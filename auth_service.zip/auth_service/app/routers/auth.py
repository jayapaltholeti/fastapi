# app/routers/auth.py
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse
from app.services import oauth_service, auth_service, jwt_service
from app.config import settings

router = APIRouter()
provider_name = settings.OAUTH_PROVIDER_NAME or "entrea"
redirect_path = settings.OAUTH_REDIRECT_PATH or "/auth/callback"

@router.get("/login")
async def login(request: Request):
    client = oauth_service.oauth.create_client(provider_name)
    if not client:
        raise HTTPException(500, "OAuth client not configured")
    redirect_uri = str(request.base_url).rstrip("/") + redirect_path
    return await client.authorize_redirect(request, redirect_uri)

@router.get("/callback", name="auth_callback")
async def auth_callback(request: Request):
    client = oauth_service.oauth.create_client(provider_name)
    if not client:
        raise HTTPException(500, "OAuth client not configured")

    try:
        token = await client.authorize_access_token(request)
    except Exception as e:
        raise HTTPException(400, f"Failed to fetch token: {e}")

    try:
        user_info = await client.parse_id_token(request, token)
    except Exception:
        if hasattr(client, "userinfo"):
            user_info = await client.userinfo(token)
        else:
            user_info = token.get("userinfo") or {}

    if not user_info:
        raise HTTPException(400, "No user info returned from provider")

    subject = user_info.get("sub") or user_info.get("email") or user_info.get("id")
    if not subject:
        raise HTTPException(400, "Provider did not return a usable subject claim")

    roles = auth_service.get_roles_for_user(subject)
    internal_payload = {"sub": subject, "roles": roles}
    internal_token = jwt_service.create_access_token(internal_payload)

    return JSONResponse(
        {
            "access_token": internal_token,
            "token_type": "bearer",
            "provider_token": token,
            "user_info": user_info,
            "roles": roles,
        }
    )