# app/middleware/auth_middleware.py
from starlette.requests import Request
from starlette.middleware.base import BaseHTTPMiddleware

class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Pass-through middleware placeholder.
        # Implement token validation + attach request.state.user later.
        return await call_next(request)