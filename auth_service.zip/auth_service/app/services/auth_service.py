# app/services/auth_service.py
from typing import List

_USER_ROLES = {
    "admin@example.com": ["admin"],
}

def get_roles_for_user(user_id: str) -> List[str]:
    return _USER_ROLES.get(user_id, ["user"])