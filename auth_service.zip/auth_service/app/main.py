# app/main.py
from fastapi import FastAPI
from app.config import settings
from app.logging_config import setup_logging
from app.routers import auth

# Initialize logging before creating app
setup_logging(settings.LOG_LEVEL)

app = FastAPI(title="Auth Service", version="0.1.0")

# Include auth router under /auth
app.include_router(auth.router, prefix="/auth", tags=["auth"])

@app.get("/health", tags=["health"])
def health():
    return {"status": "ok", "env": settings.ENV}
