# tests/test_oauth_flow.py
import pytest
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_login_redirect():
    resp = client.get("/auth/login", allow_redirects=False)
    assert resp.status_code in [302, 307]
    assert "/auth/callback" in resp.headers["location"]

def test_callback_returns_token():
    resp = client.get("/auth/callback?code=fake-code")
    assert resp.status_code == 200
    data = resp.json()
    assert "access_token" in data
    assert data["user_info"]["sub"] == "dev-user"
    assert "roles" in data

