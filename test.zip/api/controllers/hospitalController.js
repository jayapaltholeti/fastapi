const {
  parse
} = require("node:path");

const path = require("node:path");
let fs = require('node:fs');
let os = require('node:os');
const Hospital = require("../models/hospitalModel");
const multer = require('multer');
const multerS3 = require('multer-s3');
let config = require("../config");
const sql = require("../db.js");
const { Console } = require("node:console");
const { exit } = require("node:process");


exports.debugUserAPI = (req, res) => {
  res.status(200).send({
    message: "Successfully Tested.."
  });
};

// Get Hospital
exports.getAllHospital = (req, res) => {
  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  if (req.body.year) {
    let isYearValid = (isYearValidation(req.body.year));
    if (!isYearValid) {
      return res.status(400).send({
        message: "Invalid Input Year!"
      });
    }
  }
  if (req.body.permission) {
    let isPermissionValid = (isAlphaOnly(req.body.permission));
    if (!isPermissionValid) {
      return res.status(400).send({
        message: "Invalid Input Permission !"
      });
    }
  }
  if (req.body.System_Performance_Score) {
    let isNumValid = (isNumberValidation(req.body.System_Performance_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input System Performance Score!"
      });
    }
  }
  if (req.body.System_Target_Score) {
    let isNumValid = (isNumberValidation(req.body.System_Target_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input System Target Score!"
      });
    }
  }

  let isNumValidUser_Id = (isIntValidation(req.body.User_Id));
  if (!isNumValidUser_Id) {
    return res.status(400).send({
      message: "Invalid Input User ID Request!"
    });
  }
  if (req.body.hospital_id) {
    let isNumValid = (isNumberValidation(req.body.hospital_id));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input Hospital ID!"
      });
    }
  }

  if (req.body.batchName) {
    let isValid = (isAlphaNumericValidation(req.body.batchName));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid Input BatchName!"
      });
    }
  }

  if (req.body.hospital_Name) {
    let isValid = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid Input Hospital Name!"
      });
    }
  }

  let isNumValid = (isIntValidation(req.body.Insurance_Company_ID));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }

  if (req.body.Is_Manual) {
    let isNumValid = (isNumberValidation(req.body.Is_Manual));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input Is_Manual!"
      });
    }
  }
  let isInputValidmodule_name = sanitizeInputValidation(req.body.module_name)
  if (isInputValidmodule_name) {
    return res.status(400).send({
      message: "Invalid Input Module Name!"
    });
  }
  let isInputValidpermission = sanitizeInputValidation(req.body.permission)
  if (isInputValidpermission) {
    return res.status(400).send({
      message: "Invalid Input Permission!"
    });
  }
  let isInputValidrole = sanitizeInputValidation(req.body.role)
  if (isInputValidrole) {
    return res.status(400).send({
      message: "Invalid Input Role!"
    });
  }
  Hospital.getAllHospital(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult);
    }
  });
};


// Get payoutHospital
exports.payoutHospital = (req, res) => {
  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "1.Invalid Input Year"
    });
  }

  let isNumValidinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumValidinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }

  let isNumValiduser_id = (isNumberValidation(req.body.user_id));
  if (!isNumValiduser_id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }

  let isValidhospital_Name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValidhospital_Name) {
    return res.status(400).send({
      message: "Invalid Input Hospital Name!"
    });
  }

  let isValid = (isAlphaNumericSpaceParanValidation(req.body.batchName));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input BatchName!"
    });
  }

  if (req.body.System_Performance_Score) {
    let isNumValid = (isDecimalValidation(req.body.System_Performance_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input System Performance Score!"
      });
    }
  }

  if (req.body.System_Target_Score) {
    let isNumValid = (isDecimalValidation(req.body.System_Target_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input System Target Score!"
      });
    }
  }
  if (req.body.Is_Manual) {
    let isNumValid = (isNumberValidation(req.body.Is_Manual));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input Is Manual!"
      });
    }
  }
  Hospital.payoutHospital(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult);
    }
  });
};

// Get patoutMeasureGroupList
exports.patoutMeasureGroupList = (req, res) => {
 
  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "1.Invalid Input Year!"
    });
  }

  let isHospitalId = (isNumberValidation(req.body.hospital_id));
  if (!isHospitalId) {
    return res.status(400).send({
      message: "Invalid Input Hospital ID!"
    });
  }

  let isInsurenceid = (isNumberValidation(req.body.insurance_company_id));
  if (!isInsurenceid) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }

  let isHospitalName = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isHospitalName) {
    return res.status(400).send({
      message: "Invalid Input Hospital Name!"
    });
  }

  let isValid = (isAlphaNumericSpaceParanValidation(req.body.batchName));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input BatchName!"
    });
  }

  let isNumValid = (isNumberValidation(req.body.user_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }
if(req.body.System_Performance_Score){
  let isNumValid = (isDecimalValidation(req.body.System_Performance_Score));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input System Performance Score!"
    });
  }
}
if(req.body.System_Target_Score){
  let isNumValid = (isDecimalValidation(req.body.System_Target_Score));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input System Target Score!"
    });
  }
}
  Hospital.patoutMeasureGroupList(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult);
    }
  });
};
exports.scaleMeasureGroupList = (req, res) => {

  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "1.Invalid Input Year!"
    });
  }

  let isNumValidhospital_id = (isNumberValidation(req.body.hospital_id));
  if (!isNumValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Input Hospital ID!"
    });
  }

  let isNumValidinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumValidinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }

  let isValid = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input Hospital Name!"
    });
  }

 
  let isNumValiduser_id = (isNumberValidation(req.body.user_id));
  if (!isNumValiduser_id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }


  let isNumValid = (isNumberValidation(req.body.Is_Manual));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Is Manual!"
    });
  }

  Hospital.scaleMeasureGroupList(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult);
    }
  });
};


// Group Syatem Pagination
// Make sure these validation functions are defined or imported at the top:
// const { isNumberValidation, isColumnValidation, isColumnNameValidation, 
//         isColumnSearchValidation, isAlphaNumericValidation, 
//         isAlphaNumericSearchValueValidation, isIntValidation } = require('../utils/validation');

exports.getGroupSystemPagination = (req, res) => {
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //   Use different variable names for results
  let drawValid = isNumberValidation(req.body.draw);
  if (!drawValid) {
    return res.status(400).send({ message: "Invalid Input Draw!" });
  }

  let startValid = isNumberValidation(req.body.start);
  if (!startValid) {
    return res.status(400).send({ message: "Invalid Input Start!" });
  }

  let lengthValid = isNumberValidation(req.body.length);
  if (!lengthValid) {
    return res.status(400).send({ message: "Invalid Input Length!" });
  }

  let columnsValid = isColumnValidation(req.body.columns);
  if (!columnsValid) {
    return res.status(400).send({ message: "Invalid Input Column!" });
  }

  let columnNameValid = isColumnNameValidation(req.body.columns);
  if (!columnNameValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  let columnSearchValid = isColumnSearchValidation(req.body.columns);
  if (!columnSearchValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  let orderColumnValid = isNumberValidation(req.body.order[0].column);
  if (!orderColumnValid) {
    return res.status(400).send({ message: "Invalid Input Column!" });
  }

  let dirValid = isAlphaNumericValidation(req.body.order[0].dir);
  if (!dirValid) {
    return res.status(400).send({ message: "Invalid Input Order!" });
  }

  let searchValueValid = isAlphaNumericSearchValueValidation(req.body.search.value);
  if (!searchValueValid) {
    return res.status(400).send({ message: "Invalid Input Value!" });
  }

  let userValid = isIntValidation(req.body.dateObject.user);
  if (!userValid) {
    return res.status(400).send({ message: "Invalid Input User!" });
  }

  //   Finally call your model
  Hospital.getGroupSystemPagination(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};



// Group Measure Group Pagination
exports.getMeasureGroupPagination = (req, res) => {
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //   Validate draw
  let drawValid = isNumberValidation(req.body.draw);
  if (!drawValid) {
    return res.status(400).send({ message: "Invalid Input Draw!" });
  }

  //   Validate start
  let startValid = isNumberValidation(req.body.start);
  if (!startValid) {
    return res.status(400).send({ message: "Invalid Input Start!" });
  }

  //   Validate length
  let lengthValid = isNumberValidation(req.body.length);
  if (!lengthValid) {
    return res.status(400).send({ message: "Invalid Input Length!" });
  }

  //   Validate columns
  let columnsValid = isColumnValidation(req.body.columns);
  if (!columnsValid) {
    return res.status(400).send({ message: "Invalid Input Column!" });
  }

  //   Validate column names
  let columnNameValid = isColumnNameValidation(req.body.columns);
  if (!columnNameValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  //   Validate column search
  let columnSearchValid = isColumnSearchValidation(req.body.columns);
  if (!columnSearchValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  //   Validate order column
  let orderColumnValid = isNumberValidation(req.body.order[0].column);
  if (!orderColumnValid) {
    return res.status(400).send({ message: "Invalid Input Order Column!" });
  }

  //   Validate order direction
  let dirValid = isAlphaNumericValidation(req.body.order[0].dir);
  if (!dirValid) {
    return res.status(400).send({ message: "Invalid Input Order!" });
  }

  //   Validate user
  let userValid = isIntValidation(req.body.dateObject.user);
  if (!userValid) {
    return res.status(400).send({ message: "Invalid Input User!" });
  }

  //   Call the model
  Hospital.getMeasureGroupPagination(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};


function isColumnValidation(arrayData) {
  let tempArray = [];
  if (arrayData.length > 0) {
    for (const element of arrayData) {
      let myRegEx = /^[a-z0-9][a-z\d]*(?:_[a-z\d]+)*$/i;
    
      let isValid = (myRegEx.test(element.data));
      if (isValid) {
        console.log(isValid, "true column")
        tempArray.push(element.data);
      }
    }
    return tempArray.length === arrayData.length;
  }
}

function isColumnNameValidation(arrayData) {
  let tempArray = [];
  if (arrayData.length > 0) {
    for (const element of arrayData) {
      let myRegEx = /^[a-zA-Z\s]*$/;
      let isValid = (myRegEx.test(element.name));
      if (isValid) {
        console.log(isValid, "true column")
        tempArray.push(element.name);
      }
    }
    return tempArray.length === arrayData.length;
  }
}

function isColumnSearchValidation(arrayData) {
  let tempArray = [];
  if (arrayData.length > 0) {
    for (const element of arrayData) {
      let myRegEx = /^[a-zA-Z\s]*$/;
      let isValid = (myRegEx.test(element.search.value));
      if (isValid) {
        console.log(isValid, "true column")
        tempArray.push(element.search.value);
      }
    }
    if (tempArray.length === arrayData.length) {
      return true;
    } else {
      return false;
    }
  }
}

// Group Measure Group Pagination
exports.getMeasureIDPagination = (req, res) => {
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //   Validate start
  let startValid = isNumberValidation(req.body.start);
  if (!startValid) {
    return res.status(400).send({ message: "Invalid Input Start!" });
  }

  //   Validate length
  let lengthValid = isNumberValidation(req.body.length);
  if (!lengthValid) {
    return res.status(400).send({ message: "Invalid Input Length!" });
  }

  //   Validate columns
  let columnsValid = isColumnValidation(req.body.columns);
  if (!columnsValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  //   Validate column names
  let columnNameValid = isColumnNameValidation(req.body.columns);
  if (!columnNameValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  //   Validate column search
  let columnSearchValid = isColumnSearchValidation(req.body.columns);
  if (!columnSearchValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  //   Validate order column
  let orderColumnValid = isNumberValidation(req.body.order[0].column);
  if (!orderColumnValid) {
    return res.status(400).send({ message: "Invalid Input Order Columns!" });
  }

  //   Validate order direction
  let dirValid = isAlphaNumericValidation(req.body.order[0].dir);
  if (!dirValid) {
    return res.status(400).send({ message: "Invalid Input Order!" });
  }

  //   Validate user
  let userValid = isIntValidation(req.body.dateObject.user);
  if (!userValid) {
    return res.status(400).send({ message: "Invalid Input User!" });
  }

  //   Call the model
  Hospital.getMeasureIDPagination(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};


exports.getBatch = (req, res) => {
 
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isNumberValidationinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumberValidationinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }

  let isNumberValidationuser_id = (isNumberValidation(req.body.user_id));
  if (!isNumberValidationuser_id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }

  let isNumValid = (isNumberValidation(req.body.hospital_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Hospital ID!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Input Year!"
    });
  }

  let isValid = (isAlphaNumValidation(req.body.Measure_Group_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input Measure Group Name!"
    });
  }

  Hospital.getBatch(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

exports.getBatchListUrl = (req, res) => {

  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isNumberValidationuser_id = (isNumberValidation(req.body.user_id));
  if (!isNumberValidationuser_id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }

  let isNumberValidationinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumberValidationinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }
  let isNumberValidationIs_Manual = (isNumberValidation(req.body.Is_Manual));
  if (!isNumberValidationIs_Manual) {
    return res.status(400).send({
      message: "Invalid Input Is Manual !"
    });
  }
  let isNumberValidationSystem_Performance_Score = (isNumberValidation(req.body.System_Performance_Score));
  if (!isNumberValidationSystem_Performance_Score) {
    return res.status(400).send({
      message: "Invalid Input System Performance Score !"
    });
  }
  let isNumValid = (isNumberValidation(req.body.System_Target_Score));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input System Target Score!"
    });
  }
  let isValid = (isAlphaNumValidation(req.body.batchName));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input BatchName!"
    });
  }

  const fileObject = req.body.file;
  if(!fileObject[0]){
  let isValid = (isAlphaNumValidation(req.body.file));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input File!"
    });
  }
}
  Hospital.getBatchListUrl(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

exports.getBatchByName = (req, res) => {
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isValid = (isAlphaNumericSpaceValidation(req.body.batchName));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input BatchName!"
    });
  }
  let isNumberValidationuser_id = (isNumberValidation(req.body.user_id));
  if (!isNumberValidationuser_id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }

  let isNumberValidationinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumberValidationinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }


  let isNumberValidationSystem_Performance_Score = (isNumberValidation(req.body.System_Performance_Score));
  if (!isNumberValidationSystem_Performance_Score) {
    return res.status(400).send({
      message: "Invalid Input System Performance Score!"
    });
  }
  let isNumberValidationSystem_Target_Score = (isNumberValidation(req.body.System_Target_Score));
  if (!isNumberValidationSystem_Target_Score) {
    return res.status(400).send({
      message: "Invalid Input System Target Score!"
    });
  }
  let isNumValid = (isNumberValidation(req.body.Is_Manual));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Is_Manual!"
    });
  }
  Hospital.getBatchByName(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

exports.getYearHospitalByBatchName = (req, res) => {
  
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.getYearHospitalByBatchName(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

exports.getYearHospitalByBatchName = (req, res) => {
 
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.getYearHospitalByBatchName(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};


 
exports.getNationalPercentile = (req, res) => {
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }
 
  //  Validate columns
  let columnNameValid = isColumnNameValidation(req.body.columns);
  if (!columnNameValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }
 
  let columnSearchValid = isColumnSearchValidation(req.body.columns);
  if (!columnSearchValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }
 
  //  Validate measure_group_id
  if (req.body.dateObject.measure_group_id) {
    let measureGroupIdValid = isIntValidation(req.body.dateObject.measure_group_id);
    if (!measureGroupIdValid) {
      return res.status(400).send({ message: "Invalid Measure Group ID!" });
    }
  }
 
  //  Validate measure_ID
  if (req.body.dateObject.measure_ID) {
    let measureIdValid = isIntValidation(req.body.dateObject.measure_ID);
    if (!measureIdValid) {
      return res.status(400).send({ message: "Invalid Measure ID!" });
    }
  }
 
  //  Validate year
  if (req.body.dateObject.year) {
    let yearValid = isYearValidation(req.body.dateObject.year);
    if (!yearValid) {
      return res.status(400).send({ message: "Invalid Year!" });
    }
  }
 
  //  Validate user
  let userValid = isNumberValidation(req.body.dateObject.user);
  if (!userValid) {
    return res.status(400).send({ message: "Invalid User ID!" });
  }
 
  //  Validate draw
  let drawValid = isNumberValidation(req.body.draw);
  if (!drawValid) {
    return res.status(400).send({ message: "Invalid Draw!" });
  }
 
  //  Validate start
  let startValid = isNumberValidation(req.body.start);
  if (!startValid) {
    return res.status(400).send({ message: "Invalid Start!" });
  }
 
  //  Validate length
  let lengthValid = isNumberValidation(req.body.length);
  if (!lengthValid) {
    return res.status(400).send({ message: "Invalid Length!" });
  }
 
  //  Validate columns again
  let columnsValid = isColumnValidation(req.body.columns);
  if (!columnsValid) {
    return res.status(400).send({ message: "Invalid Columns!" });
  }
 
  //  Validate order column
  let orderColumnValid = isNumberValidation(req.body.order[0].column);
  if (!orderColumnValid) {
    return res.status(400).send({ message: "Invalid Column Order!" });
  }
 
  //  Validate order direction
  let dirValid = isAlphaNumericValidation(req.body.order[0].dir);
  if (!dirValid) {
    return res.status(400).send({ message: "Invalid Column Direction!" });
  }
 
  //  Call the model
  Hospital.getNationalPercentilePagination(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

//hospitalPercentRank
exports.hospitalPercentRank = (req, res) => {
    // validate request
    let body = req.body
    if (Object.keys(body).length <= 0) {
      return res.status(400).send({
        'status': 400,
        'message': "Error! Request Parameter Can Not Be Empty!"
      });
    }
  
    let isNumberValidationhospital_id = (isNumberValidation(req.body.hospital_id));
    if (!isNumberValidationhospital_id) {
      return res.status(400).send({
        message: "Invalid Hospital ID!"
      });
    }
    let isNumberValidationhospital_name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
    if (!isNumberValidationhospital_name) {
      return res.status(400).send({
        message: "Invalid Hospital Name!"
      });
    }
    let isNumberValidationmeasure_group_id= (isIntValidation(req.body.measure_group_id));
    if (!isNumberValidationmeasure_group_id) {
      return res.status(400).send({
        message: "Invalid Measure Group ID!"
      });
    }
    let isNumValid = (isNumberValidation(req.body.insurance_company_id));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Insurance Company ID!"
      });
    }
    let isValid = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid Measure Group Name!"
      });
    }
    let isYearValid = (isYearValidation(req.body.year));
    if (!isYearValid) {
      return res.status(400).send({
        message: "Invalid Year!"
      });
    }
    Hospital.getHospitalPercentRankDetails(req.body, (err, resResult) => {
      if (err) {
        console.log(err);
        return res.status(err.status).send({
          status: err.status,
          message: err.message
        });
      } else {
        return res.status(resResult.status).json(resResult);
      }
    });
  };

  
exports.getMearureIDs = (req, res) => {
 
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Year!"
    });
  }
  let isNumValidhospital_id = (isIntValidation(req.body.hospital_id));
  if (!isNumValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Hospital ID!"
    });
  }
  let isNumValidmeasure_group_id = (isIntValidation(req.body.measure_group_id));
  if (!isNumValidmeasure_group_id) {
    return res.status(400).send({
      message: "Invalid Measure Group ID!"
    });
  }

  Hospital.getMearureIDs(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};
exports.getScaleMearureIDs = (req, res) => {
  
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Year!"
    });
  }
  let isNumValidhospital_id = (isIntValidation(req.body.hospital_id));
  if (!isNumValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Hospital ID!"
    });
  }
  let isNumValid = (isIntValidation(req.body.measure_group_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Measure Group ID!"
    });
  }

  Hospital.getMearureIDs(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

exports.getScaleRangeDetailsList = (req, res) => {
 
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Year!"
    });
  }
  let isNumValidhospital_id = (isIntValidation(req.body.hospital_id));
  if (!isNumValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Hospital ID!"
    });
  }
  let isNumValidmeasure_group_id = (isIntValidation(req.body.measure_group_id));
  if (!isNumValidmeasure_group_id) {
    return res.status(400).send({
      message: "Invalid Measure Group ID!"
    });
  }

  let isNumValid = (isNumberValidation(req.body.insurance_company_id));
   if (!isNumValid) {
      return res.status(400).send({
      message: "Invalid Insurance Company ID!"
     });
    }
    let isValid = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid Measure Group Name!"
      });
    }

  Hospital.getScaleRangeDetails(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

exports.getNationalPercentileMeasureIDs = (req, res) => {

  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Input Year!"
    });
  }

  let isNumValid = (isIntValidation(req.body.measure_group_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Measure Group ID!"
    });
  }
  Hospital.getNationalPercentileMeasureIDs(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

exports.getNationalPercentileMeasureGroup = (req, res) => {
  
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Input Year!"
    });
  }
  Hospital.getNationalPercentileMeasureGroup(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

// Delete batch
exports.deleteBatch = (req, res) => {
  
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  let isValid = (isAlphanumericSpaceValidation(req.body.batchName));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Batch Name!"
    });
  }

  Hospital.deleteBatch(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};


exports.getBothScore = (req, res) => {
 
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.getBothScore(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
  }
  });
};

exports.getTableName = (req, res) => {

  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.getTableName(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};




function isAlphaNumValidation(data) {
  let myRegEx = /^[a-zA-Z\s_()]*$/;
  // /^[ A-Za-z0-9_@./#&+-]*$/
  let isValid = (myRegEx.test(data));
  if (isValid) {
    return true;
  } else {
    return false;
  }
}

function isDecimalNumberValidation(data) {
  let myRegEx = /^[0-9]\d*(\.\d+)?$/
  let isValid = (myRegEx.test(data));
  if (isValid) {
    return true;
  } else {
    return false;
  }
}

function isIntValidation(data) {
  let myRegEx = /^(0|[1-9]\d*)$/
  let isValid = (myRegEx.test(data));
  if (isValid) {
    return true;
  } else {
    return false;
  }
}

function isAlphaOnly(data) {
  let myRegEx = /^[a-zA-Z]+$/;
  return myRegEx.test(data);
}

function isYearValidation(fileYear) {
  
  
  let isfileYear = (isIntValidation(fileYear));
  if (isfileYear) {
    if (fileYear.toString().length === 4) {
      console.log(fileYear, "true")
      return true;
    } else {
      console.log(fileYear, "false")
      return false;
    }
  } else {
    console.log(fileYear, "false")
    return false;
  }
}


exports.getMearureAllocation = (req, res) => {

  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isNumValidhospital_id = (isNumberValidation(req.body.hospital_id));
  if (!isNumValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Input Hospital ID!"
    });
  }

  let isNumValidmeasure_group_id = (isNumberValidation(req.body.measure_group_id));
  if (!isNumValidmeasure_group_id) {
    return res.status(400).send({
      message: "Invalid Input Measure Group ID!"
    });
  }
  const fileObject = req.body.file;
  if(!fileObject[0]){
  let isValid = (isAlphaNumValidation(req.body.file));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid file!"
    });
  }
}
  let isValidMeasure_Group_Name = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
  if (!isValidMeasure_Group_Name) {
    return res.status(400).send({
      message: "Invalid Input Request Measure Group Name!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Input Request Year!"
    });
  }

  let isValidhospital_Name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValidhospital_Name) {
    return res.status(400).send({
      message: "Invalid Input Hospital Name!"
    });
  }

  if (req.body.originalName) {
    let isValid = (isAlphaNumericSpaceValidation(req.body.originalName));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid Input OriginalName!"
      });
    }
  }
  if (req.body.System_Target_Score) {
    let isNumValid = (isDecimalValidation(req.body.System_Target_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input System Target Score!"
      });
    }
  }
  if (req.body.System_Performance_Score) {
    let isNumValid = (isDecimalValidation(req.body.System_Performance_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid System Performance Score!"
      });
    }
  }
  let isNumValid = (isNumberValidation(req.body.user_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input User ID !"
    });
  }
  let isValid = (isAlphaNumericSpaceParanValidation(req.body.batchName));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input BatchName!"
    });
  }

  Hospital.getMearureAllocation(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};
// hospital Pagination 
// Make sure these validation functions are defined or imported at the top:
// const { isNumberValidation, isColumnValidation, isColumnNameValidation, 
//         isColumnSearchValidation, isAlphaNumericValidation, 
//         isIntValidation, sanitizeInputValidation } = require('../utils/validation');

exports.hospitalPagination = (req, res) => {
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //   Use distinct variable names for results
  let columnNameValid = isColumnNameValidation(req.body.columns);
  if (!columnNameValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  let columnSearchValid = isColumnSearchValidation(req.body.columns);
  if (!columnSearchValid) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  let lengthValid = isNumberValidation(req.body.length);
  if (!lengthValid) {
    return res.status(400).send({ message: "Invalid Length!" });
  }

  let startValid = isNumberValidation(req.body.start);
  if (!startValid) {
    return res.status(400).send({ message: "Invalid Start!" });
  }

  let drawValid = isNumberValidation(req.body.draw);
  if (!drawValid) {
    return res.status(400).send({ message: "Invalid Draw!" });
  }

  let columnsValid = isColumnValidation(req.body.columns);
  if (!columnsValid) {
    return res.status(400).send({ message: "Invalid Columns!" });
  }

  let orderColumnValid = isNumberValidation(req.body.order[0].column);
  if (!orderColumnValid) {
    return res.status(400).send({ message: "Invalid Column Order!" });
  }

  let dirValid = isAlphaNumericValidation(req.body.order[0].dir);
  if (!dirValid) {
    return res.status(400).send({ message: "Invalid Direction!" });
  }

  let userValid = isIntValidation(req.body.dateObject.user);
  if (!userValid) {
    return res.status(400).send({ message: "Invalid User!" });
  }

  //   Sanitize column names
  const checkedColName = req.body.columns;
  let invalidColName = checkedColName.some(entry => sanitizeInputValidation(entry.name));
  if (invalidColName) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  //   Sanitize column search values
  const checkedColValue = req.body.columns;
  let invalidColValue = checkedColValue.some(entry => sanitizeInputValidation(entry.search.value));
  if (invalidColValue) {
    return res.status(400).send({ message: "Invalid Input Columns!" });
  }

  //   Finally call your model
  Hospital.hospitalPagination(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};



exports.userPagination = (req, res) => {
 
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  let isNumValidlength = (isNumberValidation(req.body.length));
  if (!isNumValidlength) {
    return res.status(400).send({
      message: "Invalid Input Length!"
    });
  }

  let isNumValidstart = (isNumberValidation(req.body.start));
  if (!isNumValidstart) {
    return res.status(400).send({
      message: "Invalid Input Start!"
    });
  }

  let isNumValiddraw = (isNumberValidation(req.body.draw));
  if (!isNumValiddraw) {
    return res.status(400).send({
      message: "Invalid Input Draw!"
    });
  }
  let isNumberValidation = (isNumberValidation(req.body.start));
  if (!isNumberValidation) {
    return res.status(400).send({
      message: "Invalid Input Start!"
    });
  }

  let isNumberValidationlength = (isNumberValidation(req.body.length));
  if (!isNumberValidationlength) {
    return res.status(400).send({
      message: "Invalid Input Length!"
    });
  }

  let isColumnValidation = (isColumnValidation(req.body.columns));
  if (!isColumnValidation) {
    return res.status(400).send({
      message: "Invalid Input Columns!"
    });
  }

  let isColumnNameValidation = (isColumnNameValidation(req.body.columns));
  if (!isColumnNameValidation) {
    return res.status(400).send({
      message: "Invalid Input Columns!"
    });
  }

  let isScoreValid = (isColumnSearchValidation(req.body.columns));
  if (!isScoreValid) {
    return res.status(400).send({
      message: "Invalid Input Columns!"
    });
  }

  let isNumberValidationcolumn = (isNumberValidation(req.body.order[0].column));
  if (!isNumberValidationcolumn) {
    return res.status(400).send({
      message: "Invalid Input Order Column!"
    });
  }

  let isValid = (isAlphaNumericValidation(req.body.order[0].dir));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input Order!"
    });
  }

  let isNumValid = (isIntValidation(req.body.dateObject.user));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input User!"
    });
  }

  Hospital.userPagination(req.body, (err, hospitalResult) => {

    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};

// Get Criteria.
exports.getCriteria = (req, res) => {
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //  Validate year length
  if (!req.body.year || req.body.year.length !== 4) {
    return res.status(400).send({
      status: 400,
      message: "Invalid Year"
    });
  }

  //  Validate hospital_id
  let hospitalIdValid = isNumberValidation(req.body.hospital_id);
  if (!hospitalIdValid) {
    return res.status(400).send({ message: "Invalid Input Hospital ID!" });
  }

  //  Validate hospital_Name
  let hospitalNameValid = isAlphaNumericSpaceParanValidation(req.body.hospital_Name);
  if (!hospitalNameValid) {
    return res.status(400).send({ message: "Invalid Input Hospital Name!" });
  }

  //  Validate measure_group_id
  let measureGroupIdValid = isNumberValidation(req.body.measure_group_id);
  if (!measureGroupIdValid) {
    return res.status(400).send({ message: "Invalid Input Measure Group ID!" });
  }

  //  Validate Measure_Group_Name
  let measureGroupNameValid = isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name);
  if (!measureGroupNameValid) {
    return res.status(400).send({ message: "Invalid Input Measure Group Name!" });
  }

  //  Validate insurance_company_id
  let insuranceCompanyIdValid = isNumberValidation(req.body.insurance_company_id);
  if (!insuranceCompanyIdValid) {
    return res.status(400).send({ message: "Invalid Input Insurance Company ID!" });
  }

  //  Validate batchName
  let batchNameValid = isAlphaNumericSpaceParanValidation(req.body.batchName);
  if (!batchNameValid) {
    return res.status(400).send({ message: "Invalid Input BatchName!" });
  }

  //  Validate System_Performance_Score (if provided)
  if (req.body.System_Performance_Score) {
    let performanceScoreValid = isDecimalValidation(req.body.System_Performance_Score);
    if (!performanceScoreValid) {
      return res.status(400).send({ message: "Invalid Input System Performance Score!" });
    }
  }

  //  Validate user_id
  let userIdValid = isIntValidation(req.body.user_id);
  if (!userIdValid) {
    return res.status(400).send({ message: "Invalid Input User ID!" });
  }

  //  Validate System_Target_Score (if provided)
  if (req.body.System_Target_Score) {
    let targetScoreValid = isDecimalValidation(req.body.System_Target_Score);
    if (!targetScoreValid) {
      return res.status(400).send({ message: "Invalid Input System Target Score!" });
    }
  }

  //  Call the model
  Hospital.getCriteria(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(200).json(hospitalResult.data);
    }
  });
};


// Get InsuranceCompany
exports.getAllInsuranceCompany = (req, res) => {

  Hospital.getAllInsuranceCompany(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(201).json(hospitalResult);
    }
  });
};

// Create Measure ID List
exports.createMeasureIDList = (req, res) => {
  //  Validate request body
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //  Validate Measure_ID_Name (alphanumeric + underscore)
  let measureIdNameValid = isAlphaNumericUnderscoreValidation(req.body.Measure_ID_Name);
  if (!measureIdNameValid) {
    return res.status(400).send({ message: "Invalid Measure ID Name!" });
  }

  //  Sanitize Measure_ID_Name
  let measureIdNameSanitized = sanitizeInputValidation(req.body.Measure_ID_Name);
  if (measureIdNameSanitized) {
    return res.status(400).send({ message: "Invalid Measure ID Name!" });
  }

  //  Validate Insurance_Company_ID
  let insuranceCompanyValid = isIntValidation(req.body.Insurance_Company_ID);
  if (!insuranceCompanyValid) {
    return res.status(400).send({ message: "Invalid Insurance Company ID!" });
  }

  //  Validate Measure_Group_List_ID
  let measureGroupListValid = isNumberValidation(req.body.Measure_Group_List_ID);
  if (!measureGroupListValid) {
    return res.status(400).send({ message: "Invalid Measure Group List ID!" });
  }

  //  Validate Measure_ID
  let measureIdValid = isAlphaNumericUnderscoreValidation(req.body.Measure_ID);
  if (!measureIdValid) {
    return res.status(400).send({ message: "Invalid Measure ID!" });
  }

  //  Re-check Measure_ID_Name (redundant but kept for consistency)
  let measureIdNameCheck = isAlphaNumericUnderscoreValidation(req.body.Measure_ID_Name);
  if (!measureIdNameCheck) {
    return res.status(400).send({ message: "Invalid Measure ID Name!" });
  }

  //  Call the model
  Hospital.createMeasureIDList(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Get Hospital By ID
exports.getHospitalById = (req, res) => {
  // validate request
 
 
  if (req.params.ID === undefined) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Hospital Id Not Found."
    });
  }
  Hospital.getHospitalById(req.params, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(hospitalResult.status).json(hospitalResult);
    }
  });
};

// Get Report List
exports.getReportList = (req, res) => {
  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.getReportList(req.body, (err, reportListResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(reportListResult.status).json(reportListResult);
    }
  });
};

// Get Measure Group List

exports.getMeasureGroupList = (req, res) => {
  //   Validate request body
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //   Validate User_Id
  let userIdValid = isNumberValidation(req.body.User_Id);
  if (!userIdValid) {
    return res.status(400).send({ message: "Invalid Input User ID!" });
  }

  //   Validate Insurance_Company_ID
  let insuranceCompanyValid = isIntValidation(req.body.Insurance_Company_ID);
  if (!insuranceCompanyValid) {
    return res.status(400).send({ message: "Invalid Input Insurance Company ID!" });
  }

  //   Validate module_name (if provided)
  if (req.body.module_name) {
    let moduleNameValid = isAlphaSpaceValidation(req.body.module_name);
    if (!moduleNameValid) {
      return res.status(400).send({ message: "Invalid Input Module Name!" });
    }
  }

  //   Double-check Insurance_Company_ID as integer
  let insuranceCompanyId = Number.parseInt(req.body.Insurance_Company_ID);
  if (!Number.isNaN(insuranceCompanyId) && Number.isInteger(insuranceCompanyId)) {
    let insuranceCompanyIdValid = isIntValidation(insuranceCompanyId);
    if (!insuranceCompanyIdValid) {
      return res.status(400).send({ message: "Invalid Input Insurance Company ID!" });
    }
  } else {
    return res.status(400).send({ message: "Invalid Input Insurance Company ID!" });
  }

  //   Validate Facility_List_ID (if provided)
  if (req.body.Facility_List_ID) {
    let facilityListValid = isNumberValidation(req.body.Facility_List_ID);
    if (!facilityListValid) {
      return res.status(400).send({ message: "Invalid Input Facility List ID!" });
    }
  }

  //   Validate Measure_Group_List_ID (if provided)
  if (req.body.Measure_Group_List_ID) {
    let measureGroupListValid = isNumberValidation(req.body.Measure_Group_List_ID);
    if (!measureGroupListValid) {
      return res.status(400).send({ message: "Invalid Input Measure Group List ID!" });
    }
  }

  //   Validate year (if provided)
  if (req.body.year) {
    let yearValid = isYearValidation(req.body.year);
    if (!yearValid) {
      return res.status(400).send({ message: "Invalid Input Year!" });
    }
  }

  //   Sanitize permission
  let permissionInvalid = sanitizeInputValidation(req.body.permission);
  if (permissionInvalid) {
    return res.status(400).send({ message: "Invalid Input Permission!" });
  }

  //   Call the model
  Hospital.getMeasureGroupList(req.body, (err, MeasureGroupListResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(MeasureGroupListResult.status).json(MeasureGroupListResult);
    }
  });
};

// Get Measure Group List
exports.getMeasureIDList = (req, res) => {
  
  Hospital.getMeasureIDList(req.body, (err, MeasureGroupListResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(MeasureGroupListResult.status).json(MeasureGroupListResult);
    }
  });
};

// Get Hospital Group List
exports.getRoleList = (req, res) => {

  // validate request
  Hospital.getRoleList(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

exports.getHospitalGroupList = (req, res) => {
  //   Validate User_Id
  let userIdValid = isNumberValidation(req.body.User_Id);
  if (!userIdValid) {
    return res.status(400).send({
      message: "Invalid Input User Id!"
    });
  }

  //   Validate Insurance_Company_ID
  let insuranceCompanyValid = isIntValidation(req.body.Insurance_Company_ID);
  if (!insuranceCompanyValid) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }

  //   Sanitize module_name
  let moduleNameInvalid = sanitizeInputValidation(req.body.module_name);
  if (moduleNameInvalid) {
    return res.status(400).send({
      message: "Invalid Input Module Name!"
    });
  }

  //   Sanitize permission
  let permissionInvalid = sanitizeInputValidation(req.body.permission);
  if (permissionInvalid) {
    return res.status(400).send({
      message: "Invalid Input Permission!"
    });
  }

  //   Call the model
  Hospital.getHospitalGroupList(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Create Hospital Group
exports.createHospitalGroup = (req, res) => {
  //   Validate request body
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //   Validate User_Id
  let userIdValid = isNumberValidation(req.body.User_Id);
  if (!userIdValid) {
    return res.status(400).send({ message: "Invalid User ID!" });
  }

  //   Validate Group_Name
  let groupNameValid = isAlphaNumericValidation(req.body.Group_Name);
  if (!groupNameValid) {
    return res.status(400).send({ message: "Invalid Group Name!" });
  }

  //   Validate Group_ID
  let groupIdValid = isAlphaNumericValidation(req.body.Group_ID);
  if (!groupIdValid) {
    return res.status(400).send({ message: "Invalid Group ID!" });
  }

  //   Call the model
  Hospital.createHospitalGroup(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

//Create Mapping
exports.createMapping = (req, res) => {

  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.createMapping(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Create Measure Group
exports.createHospitalMeasureGroup = (req, res) => {
  //   Validate request body
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //   Validate User_Id
  let userIdValid = isNumberValidation(req.body.User_Id);
  if (!userIdValid) {
    return res.status(400).send({ message: "Invalid User ID!" });
  }

  //   Validate Insurance_Company_ID
  let insuranceCompanyValid = isIntValidation(req.body.Insurance_Company_ID);
  if (!insuranceCompanyValid) {
    return res.status(400).send({ message: "Invalid Insurance Company ID!" });
  }

  //   Validate Measure_Group_Name
  let measureGroupNameValid = isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name);
  if (!measureGroupNameValid) {
    return res.status(400).send({ message: "Invalid Measure Group Name!" });
  }

  //   Call the model
  Hospital.createHospitalMeasureGroup(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};


function isAlphaSpaceValidation(data) {
  let myRegEx = /^[a-zA-Z ]*$/;
  let isValid = (myRegEx.test(data));
  return !!(isValid);
}

function isAlphaNumericValidation(data) {
  let myRegEx = /[^a-z\d]/i;
  let isValid = !(myRegEx.test(data));
  if (isValid) {
    console.log(isValid, "true")
    return true;
  } else {
    console.log(isValid, "false")
    return false;
  }
}

function isAlphaNumericSearchValueValidation(data) {
  let myRegEx = /[^a-z\d]/i;
  let isValid = !(myRegEx.test(data));
  if (isValid) {
    console.log(isValid, "true")
    return true;
  } else {
    console.log(isValid, "false")
    return false;
  }
}
// Create Hospital
exports.createHospital = (req, res) => {
  //  Validate request body
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //  Validate Facility_Name
  let facilityNameValid = isAlphaNumericSpaceParanValidation(req.body.Facility_Name);
  if (!facilityNameValid) {
    return res.status(400).send({ message: "Invalid Input Facility Name!" });
  }

  //  Validate User_Id
  let userIdValid = isNumberValidation(req.body.User_Id);
  if (!userIdValid) {
    return res.status(400).send({ message: "Invalid Input User ID!" });
  }

  //  Validate Insurance_Company_ID
  let insuranceCompanyValid = isIntValidation(req.body.Insurance_Company_ID);
  if (!insuranceCompanyValid) {
    return res.status(400).send({ message: "Invalid Input Insurance Company ID!" });
  }

  //  Validate Hospital_Group_ID
  let hospitalGroupIdValid = isNumberValidation(req.body.Hospital_Group_ID);
  if (!hospitalGroupIdValid) {
    return res.status(400).send({ message: "Invalid Input Hospital Group ID!" });
  }

  //  Validate Facility_ID
  let facilityIdValid = isIntValidation(req.body.Facility_ID);
  if (!facilityIdValid) {
    return res.status(400).send({ message: "Invalid Input Facility ID!" });
  }

  //  Check required fields
  if (body.Facility_Name === undefined) {
    return res.status(400).send({
      status: 400,
      message: "Error! Hospital Facility_Name Not Found."
    });
  }
  if (body.Facility_ID === undefined) {
    return res.status(400).send({
      status: 400,
      message: "Error! Hospital Facility_ID Not Found."
    });
  }
  if (body.Hospital_Group_ID === undefined) {
    return res.status(400).send({
      status: 400,
      message: "Error! Hospital Hospital_Group_ID Not Found."
    });
  }

  //  Call the model
  Hospital.createHospital(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};


// delete Hospital
exports.deleteHospital = (req, res) => {
  Hospital.deleteHospital(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Delete user
exports.deleteUser = (req, res) => {
  let isNumValid = (isIntValidation(req.body.Insurance_Company_ID));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }
  Hospital.deleteUser(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};


// Update Hospital
exports.updateHospital = (req, res) => {
  //  Validate numeric inputs with regex first
  let numbers = /^[-+]?[0-9]+$/;
  if (!req.body.Insurance_Company_ID.match(numbers) || !req.body.Facility_ID.match(numbers)) {
    return res.status(400).send({
      status: 400,
      message: "Error! Invalid Input."
    });
  }

  //  Validate Hospital_Group_ID
  let hospitalGroupIdValid = isNumberValidation(req.body.Hospital_Group_ID);
  if (!hospitalGroupIdValid) {
    return res.status(400).send({ message: "Invalid Input Hospital Group ID!" });
  }

  //  Validate User_Id
  let userIdValid = isNumberValidation(req.body.User_Id);
  if (!userIdValid) {
    return res.status(400).send({ message: "Invalid Input User ID!" });
  }

  //  Validate Insurance_Company_ID
  let insuranceCompanyValid = isIntValidation(req.body.Insurance_Company_ID);
  if (!insuranceCompanyValid) {
    return res.status(400).send({ message: "Invalid Input Insurance Company ID!" });
  }

  //  Validate Facility_ID
  let facilityIdValid = isIntValidation(req.body.Facility_ID);
  if (!facilityIdValid) {
    return res.status(400).send({ message: "Invalid Input Facility ID!" });
  }

  //  Validate Facility_Name
  let facilityNameValid = isAlphaNumericSpaceParanValidation(req.body.Facility_Name);
  if (!facilityNameValid) {
    return res.status(400).send({ message: "Invalid Input Facility Name!" });
  }

  //  Build update object
  let updateObject = {
    Facility_Name: req.body.Facility_Name,
    Facility_ID: req.body.Facility_ID,
    Hospital_Group_ID: req.body.Hospital_Group_ID,
    Insurance_Company_ID: req.body.Insurance_Company_ID,
    ID: req.body.ID
  };

  //  Call the model
  Hospital.updateHospital(updateObject, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};


// Update Hospital
exports.updateUser = (req, res) => {

  // validate request
  let isIntValidationInsurance_Company_ID = (isIntValidation(req.body.Insurance_Company_ID));
  if (!isIntValidationInsurance_Company_ID) {
    return res.status(400).send({
      message: "Invalid Insurance ID!"
    });
  }
  let isNumValidRoles_ID = (isIntValidation(req.body.Roles_ID));
  if (!isNumValidRoles_ID) {
    return res.status(400).send({
      message: "Invalid Roles ID!"
    });
  }
  let isNumValid = (isIntValidation(req.body.ID));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid ID!"
    });
  }
  let isAlphaSpaceValidation = (isAlphaSpaceValidation(req.body.First_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid First Name!"
    });
  }
  let isValid = (isAlphaSpaceValidation(req.body.Last_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Last Name!"
    });
  }
  const emailvalidator = require("email-validator");
  if (!emailvalidator.validate(req.body.Email)) {
    return res.status(400).send({
      message: "Invalid Email"
    });
  }

  let updateObject = {
    First_Name: req.body.First_Name,
    Last_Name: req.body.Last_Name,
    Email: req.body.Email,
    Role_ID: req.body.Roles_ID,
    ID: req.body.ID
  }

  Hospital.updateUser(updateObject, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Create updateGroupSystem
exports.updateGroupSystem = (req, res) => {
  if (Object.keys(req.body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //   Validate Group_Name
  let groupNameValid = isAlphanumericSpaceValidation(req.body.Group_Name);
  if (!groupNameValid) {
    return res.status(400).send({ message: "Invalid Group Name!" });
  }

  //   Validate Group_ID
  let groupIdValid = isAlphanumericSpaceValidation(req.body.Group_ID);
  if (!groupIdValid) {
    return res.status(400).send({ message: "Invalid Group ID!" });
  }

  //   Validate ID
  let idValid = isNumberValidation(req.body.ID);
  if (!idValid) {
    return res.status(400).send({ message: "Invalid ID!" });
  }

  //   Call the model
  Hospital.updateGroupSystem(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};


// Create updateMeasureGroup
exports.updateMeasureGroup = (req, res) => {


  if (Object.keys(req.body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.updateMeasureGroup(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Create updateMeasureID
exports.updateMeasureID = (req, res) => {


  if (Object.keys(req.body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  let isNumberValidationMeasure_Group_List_ID = (isNumberValidation(req.body.Measure_Group_List_ID));
  if (!isNumberValidationMeasure_Group_List_ID) {
    return res.status(400).send({
      message: "Invalid Input Measure Group List ID !"
    });
  }
  let isNumValidUser_Id = (isNumberValidation(req.body.User_Id));
  if (!isNumValidUser_Id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }
  let isNumValidInsurance_Company_ID = (isIntValidation(req.body.Insurance_Company_ID));
  if (!isNumValidInsurance_Company_ID) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }
  let isNumValid = (isAlphaNumericSpaceParanValidation(req.body.Measure_ID));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Measure ID !"
    });
  }
  let isValid = (isAlphaNumericSpaceParanValidation(req.body.Measure_ID_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input Measure ID Name !"
    });
  }
  let isInputValidmodule_name = sanitizeInputValidation(req.body.module_name)
  if (isInputValidmodule_name) {
    return res.status(400).send({
      message: "Invalid Input Module Name!"
    });
  }
  let isInputValidpermission = sanitizeInputValidation(req.body.permission)
  if (isInputValidpermission) {
    return res.status(400).send({
      message: "Invalid Input Permission!"
    });
  }
  let isInputValid = sanitizeInputValidation(req.body.role)
  if (isInputValid) {
    return res.status(400).send({
      message: "Invalid Input Role!"
    });
  }
  Hospital.updateMeasureID(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Create Group System
exports.deleteGroupSystem = (req, res) => {

  Hospital.deleteGroupSystem(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// delete Measure System  
exports.deleteMeasureGroup = (req, res) => {
  
  Hospital.deleteMeasureGroup(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// delete Measure System  
exports.deleteMeasureID = (req, res) => {
 
  Hospital.deleteMeasureID(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Get MeasureGroupById
exports.getMeasureGroupById = (req, res) => {

  let isNumValidUser_Id = (isNumberValidation(req.body.User_Id));
  if (!isNumValidUser_Id) {
    return res.status(400).send({
      message: "Invalid User ID!"
    });
  }
  if (req.body.module_name) {
    let isValid = (isAlphaSpaceValidation(req.body.module_name));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid Input Module Name!"
      });
    }
  }
  let isNumValid = (isIntValidation(req.body.Insurance_Company_ID));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Insurance Company ID!"
    });
  }
  if (req.body.Facility_List_ID) {
    let isNumValid = (isNumberValidation(req.body.Facility_List_ID));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Facility ID!"
      });
    }
  }

  if (req.body.Measure_Group_List_ID) {
    let isNumValid = (isNumberValidation(req.body.Measure_Group_List_ID));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Measure Group ID!"
      });
    }
  }

  if (req.body.year) {
    let isYearValid = (isYearValidation(req.body.year));
    if (!isYearValid) {
      return res.status(400).send({
        message: "Invalid Year!"
      });
    }
  }

  Hospital.getMeasureGroupById(req.body, (err, hospitalResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(hospitalResult.status).json(hospitalResult);
    }
  });
};

// Update Facilty Measure Id Mapping
exports.faciltymeasureidmapping = (req, res) => {

  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  if (body.Facility_List_ID === undefined) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Hospital Facility_List_ID Not Found."
    });
  }
  if (body.Measure_Group_List_ID === undefined) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Hospital Measure_Group_List_ID Not Found."
    });
  }
  if (body.Measure_ID_List_ID === undefined) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Hospital Measure_ID_List_ID Not Found."
    });
  }
  Hospital.faciltymeasureidmapping(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};



function isNumberValidation(userId) {
  let isUserId = Number.isInteger(userId);
  if (isUserId) {
    return true;
  } else {
    console.log(userId, "false")
    return false;
  }
}

// Calculate Payout
exports.calculatePayout = (req, res) => {


  let isNumberValidinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumberValidinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Insurance Company ID!"
    });
  }

  let isNumberValidmeasure_group_id = (isNumberValidation(req.body.measure_group_id));
  if (!isNumberValidmeasure_group_id) {
    return res.status(400).send({
      message: "Invalid Measure Group ID!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Year!"
    });
  }

  let isValidbatchName = (isAlphaNumericSpaceValidation(req.body.batchName));
  if (!isValidbatchName) {
    return res.status(400).send({
      message: "Invalid Batch Name!"
    });
  }

  let isNumValidSystem_Performance_Score = (isDecimalValidation(req.body.System_Performance_Score));
  if (!isNumValidSystem_Performance_Score) {
    return res.status(400).send({
      message: "Invalid Performance Score!"
    });
  }
  if (req.body.System_Target_Score) {
    let isNumValid = (isDecimalValidation(req.body.System_Target_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Target Score!"
      });
    }
  }
  const fileObject = req.body.file;
  if(!fileObject[0]){
  let isValid = (isAlphaNumValidation(req.body.file));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid file!"
    });
  }
}
  
  let isNumValidallocation = (isDecimalValidation(req.body.allocation));
  if (!isNumValidallocation) {
    return res.status(400).send({
      message: "Invalid Allocation!"
    });
  }

  let isValidhospital_Name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValidhospital_Name) {
    return res.status(400).send({
      message: "Invalid Hospital Name!"
    });
  }
  let isNumValid = (isNumberValidation(req.body.hospital_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Hospital ID!"
    });
  }
  if (req.body.originalName) {
    let isValid = (isAlphaNumericSpaceValidation(req.body.originalName));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid originalName!"
      });
    }
  }

  let isValid = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Measure Group Name!"
    });
  }



  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.calculatePayout(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};
//Vaildate Scale Range Upload
exports.scaleRangeValidation = (req, res) => {
 

  if (!isNumberValid) {
    return res.status(400).send({
      message: "Invalid Insurance Company ID!"
    });
  }

  let isNumberValid = (isNumberValidation(req.body.measure_group_id));
  if (!isNumberValid) {
    return res.status(400).send({
      message: "Invalid Measure Group ID!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Year!"
    });
  }

  let isValidbatchName = (isAlphaNumericSpaceValidation(req.body.batchName));
  if (!isValidbatchName) {
    return res.status(400).send({
      message: "Invalid Batch Name!"
    });
  }

  let isNumValidSystem_Performance_Score = (isDecimalValidation(req.body.System_Performance_Score));
  if (!isNumValidSystem_Performance_Score) {
    return res.status(400).send({
      message: "Invalid Performance Score!"
    });
  }
  if (req.body.System_Target_Score) {
    let isNumValid = (isDecimalValidation(req.body.System_Target_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Target Score!"
      });
    }
  }
  const fileObject = req.body.file;
  if(!fileObject[0]){
  let isValid = (isAlphaNumValidation(req.body.file));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid file!"
    });
  }
}

  let isNumValidallocation = (isDecimalValidation(req.body.allocation));
  if (!isNumValidallocation) {
    return res.status(400).send({
      message: "Invalid Allocation!"
    });
  }

  let isValidhospital_Name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValidhospital_Name) {
    return res.status(400).send({
      message: "Invalid Hospital Name!"
    });
  }
  let isNumValid = (isNumberValidation(req.body.hospital_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Hospital ID!"
    });
  }
  if (req.body.originalName) {
    let isValid = (isAlphaNumericSpaceValidation(req.body.originalName));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid originalName!"
      });
    }
  }

  let isValid = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Measure Group Name!"
    });
  }



  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  Hospital.scaleRangeValidation(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// assign Measure ID wise allocation
exports.assignAllocation = (req, res) => {

  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  if (req.body.year.length > 4 || req.body.year.length < 4) {
    return res.status(400).send({
      'status': 400,
      'message': "Invalid Year 0"
    });
  }

  let isNumValidinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumValidinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }

  let isNumValidhospital_id = (isNumberValidation(req.body.hospital_id));
  if (!isNumValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Input Hospital ID!"
    });
  }
  let isValidMeasure_Group_Name = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
  if (!isValidMeasure_Group_Name) {
    return res.status(400).send({
      message: "Invalid Input Measure Group Name!"
    });
  }

  let isNumValidmeasure_group_id = (isNumberValidation(req.body.measure_group_id));
  if (!isNumValidmeasure_group_id) {
    return res.status(400).send({
      message: "Invalid Input Measure Ggroup ID!"
    });
  }

  let isValidbatchName = (isAlphaNumericSpaceParanValidation(req.body.batchName));
  if (!isValidbatchName) {
    return res.status(400).send({
      message: "Invalid Input BatchName!"
    });
  }

  let isNumValidallocation = (isDecimalValidation(req.body.allocation));
  if (!isNumValidallocation) {
    return res.status(400).send({
      message: "Invalid Input Allocation!"
    });
  }

  let isNumValid = (isDecimalValidation(req.body.System_Performance_Score));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input System Performance Score!"
    });
  }
  if (req.body.System_Target_Score) {
    let isNumValid = (isDecimalValidation(req.body.System_Target_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input System Target Score!"
      });
    }
  }

  let isValid = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input Hospital Name!"
    });
  }

  Hospital.assignAllocation(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// payoutDetailList
exports.getPayoutScreenDisplayDetails = (req, res) => {
  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isValidbatchName = (isAlphaNumericSpaceParanValidation(req.body.batchName));
  if (!isValidbatchName) {
    return res.status(400).send({
      message: "Invalid Batch Name!"
    });
  }
  if (req.body.originalName) {
    let isValid = (isAlphaNumericSpaceValidation(req.body.originalName));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid Input Original Name!"
      });
    }
  }
  const fileObject = req.body.file;
  if(!fileObject[0]){
  let isValid = (isAlphaNumericValidation(req.body.file));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Batch Name!"
    });
  }
}
  let isValidoriginalName = (sanitizeInputValidation(req.body.originalName));
  if (isValidoriginalName) {
    return res.status(400).send({
      message: "Invalid Batch Name!"
    });
  }
  let isNumValidhospital_id = (isNumberValidation(req.body.hospital_id));
  if (!isNumValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Hospital ID!"
    });
  }

  let isValidhospital_Name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValidhospital_Name) {
    return res.status(400).send({
      message: "Invalid Hospital Name!"
    });
  }

  let isNumValidmeasure_group_id = (isIntValidation(req.body.measure_group_id));
  if (!isNumValidmeasure_group_id) {
    return res.status(400).send({
      message: "Invalid Measure Group ID!"
    });
  }
  if (req.body.allocation) {
    let isNumValid = (isDecimalValidation(req.body.allocation));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Allocation!"
      });
    }
  }
  let isNumValid = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Insurance Company ID!"
    });
  }

  if (req.body.System_Performance_Score) {
    let isNumValid = (isDecimalValidation(req.body.System_Performance_Score));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid System Performance Score!"
      });
    }
  }
  let isValid = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Measure Group Name!"
    });
  }

  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Year!"
    });
  }

  if(req.body.System_Target_Score){
  let isNumValid = (isDecimalValidation(req.body.System_Target_Score));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input System Target Score!"
    });
  }
}

  Hospital.getPayoutScreenDisplayDetails(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// getPayoutDisplay
exports.getPayoutDisplay = (req, res) => {
  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  let isNumValiduser_id = (isNumberValidation(req.body.user_id));
  if (!isNumValiduser_id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }
  let isValidhospital_id = (isNumberValidation(req.body.hospital_id));
  if (!isValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Input Hospital ID!"
    });
  }

  if (req.body.measure_group_id) {
    let isNumValid = (isNumberValidation(req.body.measure_group_id));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input Measure Group ID!"
      });
    }
  }

  let isNumValid = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID!"
    });
  }
  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Input Year!"
    });
  }

  let isValid = (isAlphaNumericSpaceParanValidation(req.body.batchName));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input BatchName!"
    });
  }


  Hospital.getPayoutDisplay(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// payoutDetailList
exports.getFilesType = (req, res) => {
 
  let isNumValiduser_id = (isNumberValidation(req.body.user_id));
  if (!isNumValiduser_id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }

  let isNumValid = (isNumberValidation(req.body.insurance_company_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input Insurance company ID!"
    });
  }

  let isInputValid = sanitizeInputValidation(req.body.allocation)
  if (isInputValid) {
    return res.status(400).send({
      message: "Invalid Input Allocation!"
    });
  }

  Hospital.getFilesType(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Get Year
exports.getYear = (req, res) => {
  // validate request
  let isValidMeasure_Group_Name = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
  if (!isValidMeasure_Group_Name) {
    return res.status(400).send({
      message: "Invalid Input Measure Group Name!"
    });
  }
  let isNumValidallocation = (isAlphaNumericSpaceParanValidation(req.body.allocation));
  if (!isNumValidallocation) {
    return res.status(400).send({
      message: "Invalid Allocation!"
    });
  }
  let isValidhospital_Name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValidhospital_Name) {
    return res.status(400).send({
      message: "Invalid Hospital Name !"
    });
  }
  let isValidinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isValidinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Insurance Company ID!"
    });
  }
  let isValid = (isAlphaNumValidation(req.body.Measure_Group_Name));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Input Measure Group Name!"
    });
  }
  if (req.body.originalName) {
    let isValid = (isAlphaNumValidation(req.body.originalName));
    if (!isValid) {
      return res.status(400).send({
        message: "Invalid Input OriginalName!"
      });
    }
  }
  let isNumValid = (isNumberValidation(req.body.user_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Input User ID !"
    });
  }

  let isInputValid = sanitizeInputValidation(req.body.batchName)
  if (isInputValid) {
    return res.status(400).send({
      message: "Invalid Batch Name Request!"
    });
  }
  Hospital.getYear(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

//Get Years for Mapping and Upload
exports.getYears = (req, res) =>{


  Hospital.getYears(req, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
}

// Get Year
exports.getNationalPercentileYear = (req, res) => {
  // validate request
 
  Hospital.getNationalPercentileYear(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// Get Mapping.
exports.getMappedIDList = (req, res) => {
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }

  let isNumValidUser_Id = (isIntValidation(req.body.User_Id));
  if (!isNumValidUser_Id) {
    return res.status(400).send({
      message: "Invalid Input User ID!"
    });
  }
  let isNumValidInsurance_Company_ID = (isIntValidation(req.body.Insurance_Company_ID));
  if (!isNumValidInsurance_Company_ID) {
    return res.status(400).send({
      message: "Invalid Input Insurance Company ID !"
    });
  }
  if (req.body.permission) {
    let isPermissionValid = (isAlphaOnly(req.body.permission));
    if (!isPermissionValid) {
      return res.status(400).send({
        message: "Invalid Input Permission!"
      });
    }
  }

  if (req.body.Facility_List_ID != null) {
    let isNumValid = (isIntValidation(req.body.Facility_List_ID));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input Facility ID !"
      });
    }
  }

  if (req.body.Measure_Group_List_ID != null) {
    let isNumValid = (isIntValidation(req.body.Measure_Group_List_ID));
    if (!isNumValid) {
      return res.status(400).send({
        message: "Invalid Input Measure Group ID !"
      });
    }
  }
  if (req.body.year != null) {
    let isYearValid = (isYearValidation(req.body.year));
    if (!isYearValid) {
      return res.status(400).send({
        message: "Invalid Input Year !"
      });
    }
  }
  Hospital.getMappedIDList(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

function sanitizeInputValidation(input) {

  // Define the list of special characters to search for
  const specialChars = ['|', '&', ';', "'", '#', '/', '$'];
  let foundSpecialChar = false;

  specialChars.forEach(char => {
    const index = input.indexOf(char);
    // If the special character is found, remove everything after it
    if (index !== -1) {
      input = input.substring(0, index);
      foundSpecialChar = true;
    }
  });

  return foundSpecialChar
}
function isAlphaNumericSpaceValidation(data) {
  let myRegEx = /^[a-zA-Z0-9-\s!@#$%^&*()_/=><."'“”,]*(?:-[a-z\d]+)*$/;
  let isValid = (myRegEx.test(data));
  if (isValid) {
    console.log(isValid, "true")
    return true;
  } else {
    console.log(isValid, "false")
    return false;
  }
}

function isAlphaNumericSpaceParanValidation(data) {
  let myRegEx = /^[a-zA-Z0-9-\s!@#$%^&*()_/]*(?:-[a-z\d]+)*$/;
  let isValid = (myRegEx.test(data));
  if (isValid) {
    console.log(isValid, "true")
    return true;
  } else {
    console.log(isValid, "false")
    return false;
  }
}

function isAlphaNumericUnderscoreValidation(data) {
  
  let myRegEx = /^[a-zA-Z0-9-\s$%^_/]*(?:-[a-z\d]+)*$/;

  let isValid = (myRegEx.test(data));
  if (isValid) {
    console.log(isValid, "true")
    return true;
  } else {
    console.log(isValid, "false")
    return false;
  }
}

function isDecimalValidation(data) {
  let myRegEx = /^[0-9]\d*(\.\d+)?$/
  let isValid = (myRegEx.test(data));
  if (isValid) {
    return true;
  } else {
    return false;
  }
}

function isAlphanumericSpaceValidation(data) {
  let myRegEx = /^[A-Za-z0-9 _]+$/
  let isValid = (myRegEx.test(data));
  if (isValid) {
    return true;
  } else {
    return false;
  }
}


// modify Measure ID allocation
exports.modifyAllocation = (req, res) => {
  
  // validate request
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  
  let isNumValid = (isNumberValidation(req.body.r_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Body !"
    });
  }
 
  let isNumValiduser_id = (isNumberValidation(req.body.user_id));
  if (!isNumValiduser_id) {
    return res.status(400).send({
      message: "Invalid User !"
    });
  }
 
  let isNumValidmeasure_group_id = (isAlphaNumericUnderscoreValidation(req.body.measure_group_id[1]));
  if (!isNumValidmeasure_group_id) {
    return res.status(400).send({
      message: "Invalid Measure Group !"
    });
  }
 
  let isValidhospital_Name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValidhospital_Name) {
    return res.status(400).send({
      message: "Invalid Hospital Name !"
    });
  }
 
  let isValid = (isAlphaNumericSpaceValidation(req.body.performance_notes));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Performance Notes!"
    });
  }

  Hospital.modifyAllocation(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};


// modify Measure ID allocation CR
exports.modifyMeasureIDAllocation = (req, res) => {
 
  let body = req.body
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      'status': 400,
      'message': "Error! Request Parameter Can Not Be Empty!"
    });
  }
  let isNumValiduser_id = (isNumberValidation(req.body.user_id));
  if (!isNumValiduser_id) {
    return res.status(400).send({
      message: "Invalid User ID!"
    });
  }
  let isNumValid = (isNumberValidation(req.body.measure_group_id));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Measure Group ID!"
    });
  }
  let isValidhospital_Name = (isAlphaNumericSpaceParanValidation(req.body.hospital_Name));
  if (!isValidhospital_Name) {
    return res.status(400).send({
      message: "Invalid Hospital Name!"
    });
  }
  let isValidhospital_id = (isNumberValidation(req.body.hospital_id));
  if (!isValidhospital_id) {
    return res.status(400).send({
      message: "Invalid Hospital ID!"
    });
  }
  let isYearValid = (isYearValidation(req.body.year));
  if (!isYearValid) {
    return res.status(400).send({
      message: "Invalid Year!"
    });
  }
  let isValidinsurance_company_id = (isNumberValidation(req.body.insurance_company_id));
  if (!isValidinsurance_company_id) {
    return res.status(400).send({
      message: "Invalid Insurance Company ID!"
    });
  }
  let isValid = (isAlphaNumericSpaceParanValidation(req.body.batchName));
  if (!isValid) {
    return res.status(400).send({
      message: "Invalid Batch!"
    });
  }
  if (req.body.batchName === "") {
    return res.status(400).send({
      message: "Batch Name Cannot be Empty!"
    });
  }

  let areAllAllocationValid = true;
  req.body.measure_ids.forEach((mids) => {
    if (mids)
      if (mids.Allocation !== 'NULL')
        isValid = (isDecimalNumberValidation(mids.Allocation));
    if (!isValid) {
      areAllAllocationValid = false;
    }
  });
  if (!areAllAllocationValid) {
    return res.status(400).send({
      message: "Invalid Allocation!"
    });
  }


  Hospital.modifyMeasureIDAllocation(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

// At the top of the file, make sure you import or define your validation helpers:
// const { isNumberValidation, isIntValidation, isYearValidation } = require('../utils/validation');

exports.mappingUpdate = (req, res) => {
  //  Validate request body
  let body = req.body;
  if (Object.keys(body).length <= 0) {
    return res.status(400).send({
      status: 400,
      message: "Error! Request Parameter Can Not Be Empty!"
    });
  }

  //  Validate Facility_List_ID
  let facilityListValid = isNumberValidation(req.body.Facility_List_ID);
  if (!facilityListValid) {
    return res.status(400).send({ message: "Invalid Input Facility List ID!" });
  }

  //  Validate Insurance_Company_ID
  let insuranceCompanyValid = isIntValidation(req.body.Insurance_Company_ID);
  if (!insuranceCompanyValid) {
    return res.status(400).send({ message: "Invalid Input Insurance Company ID!" });
  }

  //  Validate each Measure_ID_List_ID in checkedIds
  const checkedIds = req.body.checkedIds || [];
  let measureIdListValid = checkedIds.every(entry => isIntValidation(entry.Measure_ID_List_ID));
  if (!measureIdListValid) {
    return res.status(400).send({ message: "Invalid Input Measure ID List ID!" });
  }

  //  Validate Measure_Group_List_ID
  let measureGroupListValid = isNumberValidation(req.body.Measure_Group_List_ID);
  if (!measureGroupListValid) {
    return res.status(400).send({ message: "Invalid Input Measure Group List ID!" });
  }

  //  Validate year
  let yearValid = isYearValidation(req.body.year);
  if (!yearValid) {
    return res.status(400).send({ message: "Invalid Input Year!" });
  }

  //  Validate User_Id
  let userIdValid = isNumberValidation(req.body.User_Id);
  if (!userIdValid) {
    return res.status(400).send({ message: "Invalid Input User ID!" });
  }

  //  Call the model
  Hospital.mappingUpdate(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};



exports.hospitalUpload = (req, res) => {

  Hospital.hospitalUpload(req.body, (err, resResult) => {
    if (err) {
      console.log(err);
      return res.status(err.status).send({
        status: err.status,
        message: err.message
      });
    } else {
      return res.status(resResult.status).json(resResult);
    }
  });
};

const LifespanFile = function (lifespanFile) {
 
  this.userid = lifespanFile.userid;
  this.fileurl = lifespanFile.fileurl;
  this.filetypeId = lifespanFile.filetypeId;
  this.year = lifespanFile.year;
  this.month = lifespanFile.month;
  this.fileName = lifespanFile.fileName;
  this.isUploaded = lifespanFile.isUploaded;
  this.execFile = lifespanFile.execFile;
  this.tableName = lifespanFile.tableName;
  this.folderPath = lifespanFile.folderPath;
};


exports.findLifespanDmaList = (req, res) => {

  LifespanFile.findLifespanDmaListById(req.body, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: err,
        });
      } else {
        res.status(500).send({
          message: "Error retrieving file with id " + req.params.customerId,
        });
      }
    } else res.json(data);
  });
};

LifespanFile.findLifespanDmaListById = (fileJson, result) => {
 
  sql.query(`select FC.Categories as Categories, Original_Name, Uploaded_On, Is_Uploaded as Status from Uploaded_Files_SR UP inner join File_Categories FC on UP.File_Categories_ID = FC.ID where User_ID=${fileJson.user_id} and Year='${fileJson.year}' order by Uploaded_On desc`, (err, res) => {

    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.recordset.length > 0) {
      console.log("found dma file: ", res);
      result(null, res.recordset);
      return;
    } else {
      console.log(res, "res...............");
      // not found User with the id
      result({
        kind: "not_found"
      }, null);
    }
  });
};

exports.fileUploadLifeSpan = function (req, res, callBack) {

  upload(req, res, function (err) {
  
    if (err) {
      res.status(500).send({
        message: "Some error occurred while uploading File."
      });
    } else {
      if (!req.body) {
        res.status(400).send({
          message: "Content can not be empty!"
        });
      }
      //Upload to Azure Storage
      Hospital.hospitalLifeSpanUpload(req.body, (err, resResult) => {
        if (err) {
          console.log(err);
          return res.status(err.status).send({
            status: err.status,
            message: err.message
          });
        } else {
          console.log('----lifespan -----')
          createLifespanDMARecord(req, res);
          return res.status(resResult.status).json(resResult);
        }
      });
      // insert status
      // res = createDMARecord(req, res);
    }
    return res;
  });
};

const createLifespanDMARecord = function (req, res) {

  let table_name = req.body.table_name
  let fileName = "" + `${table_name}_${req.body.year}.csv`;
  let year = "" + `${req.body.year}`;
  let user_id = "" + `${req.body.user_id}`;
  let Original_Name = "" + `${req.body.originalName}`;
  let measure_group_id = "" + `${req.body.measure_group_id}`;
  let tableName = "" + `${table_name}`;
  let initPath = config.con.temp;
  let folderPath = path
    .join(initPath, user_id, year, tableName)
    .replaceAll(/\\/g, "/");
  let filePath = path.join(folderPath, fileName).replaceAll(/\\/g, "/");
  const fileObject = {
    User_ID: user_id,
    File_Categories_ID: measure_group_id,
    Year: year,
    File_Name: fileName,
    Is_Uploaded: "Uploaded",
    File_URL: filePath,
    folderPath: folderPath,
    Original_Name: Original_Name,
    measure_group_id: measure_group_id
  };

  LifespanFile.create(fileObject, (err, data) => {
    if (err)
      return res.status(500).send({
        message: err.message || "Some error occurred while creating the User.",
      });

    // return res.status(201).json(data);
  });
  //AddExec will come here
};



LifespanFile.create = (hospitalObj, result) => {

  sql.query(`SELECT * FROM Uploaded_Files_SR WHERE User_ID = ${hospitalObj.User_ID} AND File_Categories_ID = ${hospitalObj.File_Categories_ID} AND Year = ${hospitalObj.Year}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
   
    if (res.recordset.length > 0) {
    
      sql.query(`UPDATE Uploaded_Files_SR SET User_ID ='${hospitalObj.User_ID}', Original_Name = '${hospitalObj.Original_Name}', File_Categories_ID ='${hospitalObj.File_Categories_ID}', Year = '${hospitalObj.Year}', File_Name ='${hospitalObj.File_Name}', Is_Uploaded ='${hospitalObj.Is_Uploaded}', File_URL ='${hospitalObj.File_URL}' WHERE  User_ID = ${hospitalObj.User_ID} AND File_Categories_ID = ${hospitalObj.File_Categories_ID} AND Year = ${hospitalObj.Year}`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(err, null);
          return;
        }
        
        result(null, res);
      });
    } else {
      
      sql.query(`INSERT INTO Uploaded_Files_SR (User_ID, File_Categories_ID,Year,File_Name,Is_Uploaded,File_URL,Original_Name) VALUES (${hospitalObj.User_ID},${hospitalObj.File_Categories_ID},${hospitalObj.Year},'${hospitalObj.File_Name}','${hospitalObj.Is_Uploaded}','${hospitalObj.File_URL}','${hospitalObj.Original_Name}')`, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(err, null);
          return;
        }
        result(null, res);
      });
    }
  });
};



let storage = multer.diskStorage({
  destination: function (req, file, callback) {
    let dir = `../../api/temp/${req.body.user_id}/${req.body.year}/LifeSpan`;
    let fullDir = path.join(__dirname, dir).replace(/\\/g, '/');
    // let fullDir = path.join(__dirname, dir).replace(/(\r\n|\n|\r)/gm, '/');
    // someText = someText.replace(/(\r\n|\n|\r)/gm, "");
   
    if (!fs.existsSync(fullDir)) {
      fs.mkdirSync(fullDir, {
        recursive: true
      });
    }
    callback(null, fullDir);
  },
  filename: function (req, file, callback) {
    // initialize filename with .csv
    let filename = `LifeSpan_${req.body.measure_group_id}_${req.body.measure_ID}_${req.body.year}.csv`;
    this.filename = `LifeSpan_${req.body.measure_group_id}_${req.body.measure_ID}_${req.body.year}.csv`;
    //checking for xlsx format
    if (file.originalname.split('.').pop() === "xlsx") {
      filename = `LifeSpan_${req.body.measure_group_id}_${req.body.measure_ID}_${req.body.year}.xlsx`;
      this.filename = `LifeSpan_${req.body.measure_group_id}_${req.body.measure_ID}_${req.body.year}.xlsx`;
    }
    //check if file extension is xls and change filename to .xls
    else if (file.originalname.split('.').pop() === "xls") {
      filename = `LifeSpan_${req.body.measure_group_id}_${req.body.measure_ID}_${req.body.year}.xls`;
      this.filename = `LifeSpan_${req.body.measure_group_id}_${req.body.measure_ID}_${req.body.year}.xls`;
    }
  
    callback(null, filename);
  }
});
let upload = multer({
  storage: storage
}).array('upload', 12);