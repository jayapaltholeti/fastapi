const multer = require("multer");
const multerS3 = require("multer-s3");
let logger = require("../logger.js")(__filename);
let fs = require("node:fs");
let os = require("node:os");
const process = require("node:process");
const path = require("node:path");
const spawn = require("node:child_process").spawn;
const XLSX = require('xlsx')


const CSVtoJSON = require("csvtojson");
const JSONtoCSV = require("json2csv").parse;
const moment = require("moment");

const timeStamp = moment().format("YYYY-MM-DDTHH:mm:ss.SSSSSSS");

const axios = require("axios");
const qs = require("qs");

const moveFile = require("move-file");

let config = require("../config");
const sql = require("../db.js");

const DmaFile = require("../models/dmaFileModel");
const Hospital = require("../models/hospitalModel");

const e = require("express");
const Json2csvParser = require("json2csv").Parser;
//API - /private/app/v1/debugProcess
exports.debugProcess = function (req, res, callBack) {
  let fileMonth = "" + `${req.body.fileMonth}`;
  let fileYear = "" + `${req.body.fileYear}`;
  let userId = "" + `${req.body.userId}`;

  let processData = {
    userId: userId,
    year: fileYear,
    month: fileMonth,
  };

  DmaFile.ExecuteLeadProcessor(processData, (err, data) => {
    if (err)
      return res.status(500).send({
        message: err.message || "Error with Processing the files.",
      });

    res.status(200).send({
      message: "Files imported Successfully!",
    });
  });
};

//API - /private/app/v1/process
exports.Process = function (req, res, callBack) {
  let fileMonth = "" + `${req.body.fileMonth}`;
  let fileYear = "" + `${req.body.fileYear}`;
  let userId = "" + `${req.body.userId}`;

  let processData = {
    userId: userId,
    year: fileYear,
    month: fileMonth,
  };
  // Save User in the database
  DmaFile.runProcess(processData, (err, data) => {
    if (err)
      return res.status(500).send({
        message: err.message || "Error with Processing the files.",
      });

    if (data) {
      res.status(200).send({
        message: "Processing done...",
      });
    }
  });

};

//API - /private/app/v1/importSFDC
exports.ImportSFDC = function (req, res, callBack) {
  if (os.platform().startsWith("linux")) {


    const ls = spawn("./import.sh", []);
    ls.stdout.on("data", (data) => {
    });
    ls.on("close", (code) => {
      let fileMonth = "" + `${req.body.fileMonth}`;
      let fileYear = "" + `${req.body.fileYear}`;
      let userId = "" + `${req.body.userId}`;
      let fileTypeId = "" + `${req.body.fileTypeId}`;
      let fileName = "Salesforce Leads";
      let tableName = "leads";
      const dmaFile = new DmaFile({
        userid: userId,
        fileurl: fileName,
        filetypeId: fileTypeId,
        year: fileYear,
        month: fileMonth,
        fileName: fileName,
        tableName: tableName,
        isUploaded: "Imported",
        execFile: false,
      });

      // Save User in the database
      DmaFile.create(dmaFile, (err, data) => {
        if (err)
          return res.status(500).send({
            message: err.message || "Some error occurred while creating the User.",
          });
        else return res.status(201).json(data);
      });
    });
  } else if (os.platform().startsWith("win")) {
    console.log("not implemented on Windows yet");
  }
};

//API - /private/app/v1/exportSFDC
exports.ExportSFDC = function (req, res, callBack) {
  let fileMonth = "" + `${req.body.fileMonth}`;
  let fileYear = "" + `${req.body.fileYear}`;
  let userId = "" + `${req.body.userId}`;
  let fileName = "Salesforce Leads";
  if (os.platform().startsWith("linux")) {
    // sql.query("SELECT * FROM `lead`", function (error, data, fields) {
    sql.query(
      "SELECT salesforce_id as Id,city as City,address_line1 as Street,state as State,country as Country,zip_code as PostalCode,first_name as FirstName,last_name as LastName,product_family_name as Company,phone as Phone, do_not_call as DoNotCall,member_email as Email,lead_source as LeadSource,sic as SICCode_c,STR_TO_DATE(dob, '%m-%d-%Y') as Date_of_Birthc,prospect_type as Prospect_typec,opportunity_record_type as Opportunity_Record_Typec,sales_channel as Sales_Channelc,enrollment_channel as Enrollment_Channelc,agein_type_rel as Age_In_Typec,closed_lost_reason as Closed_Lost_Reasonc,converted as Convertedc, STR_TO_DATE(effective_date, '%m-%d-%Y') as Effective_Datec, STR_TO_DATE(close_date, '%m-%d-%Y') as Close_Datec,product_name as Product_Namec, STR_TO_DATE(disenrollment_date, '%m-%d-%Y') as Disenrollment_Datec,disenrollment_reason as Disenrollment_Reasonc,last_activity as Last_Activityc,lead_record_type as Lead_Record_Typec,lead_sub_type as Lead_Subtypec,STR_TO_DATE(ma_effective_date, '%m-%d-%Y') as MA_Effective_Datec,opp_status as Opportunity_Statusc, STR_TO_DATE(opportunity_date, '%d-%m-%Y') as Opportunity_Datec , opportunity_id as Opportunity_Idc,opportunity_owner as Opportunity_Ownerc,GIC_Mbr_Flag as Flag_c FROM maleaddb3.salesforce_leads;",
      function (error, data, fields) {
        if (error) throw error;
        const jsonData = structuredClone(data);
        const json2csvParser = new Json2csvParser({
          header: true,
        });
        const csv = json2csvParser.parse(jsonData);
        fs.writeFile("/root/leadpoc/upload/lead.csv", csv, function (error) {
          if (error) throw error;
          const spawn = require("node:child_process").spawn;
          const ls = spawn("./export.sh", []);
          ls.stdout.on("data", (data) => {
          });

          ls.on("close", (code) => {
            sql.query(
              "UPDATE dmafile SET isSalesForcePush=1 WHERE userid = ? AND fileName = ? AND month = ? AND year = ?",
              [userId, fileName, fileMonth, fileYear],
              (err, res) => {
                if (err) {
                  console.log("error: ", err);
                  result(err, null);
                  return;
                }
                result(null, res);
              }
            );

            res.status(200).send({
              message: "export Successfully!",
            });
          });
        });
      }
    );
  } else if (os.platform().startsWith("win")) {
    console.log("not implemented on Windows yet");
  }
};

let storage = multer.diskStorage({
  destination: function (req, file, callback) {
    let table_name = req.body.Table_Name.replaceAll(/(\r\n|\n|\r)/gm, "");
    let dir = `../../api/temp/${req.body.user_id}/${req.body.year}/${table_name}`;
    let fullDir = path.join(__dirname, dir).replaceAll("\\", "/");
;
    if (!fs.existsSync(fullDir)) {
      fs.mkdirSync(fullDir, {
        recursive: true,
      });
    }
    callback(null, fullDir);
  },
  filename: function (req, file, callback) {
    let table_name = req.body.Table_Name.replaceAll(/(\r\n|\n|\r)/gm, "");
    // initialize filename with .csv
    let filename = `${table_name}_${req.body.year}.csv`;
    this.filename = `${table_name}_${req.body.year}.csv`;
    //check if file extension is xlsx and change filename to .xlsx
    if (file.originalname.split('.').pop() === "xlsx") {
      filename = `${table_name}_${req.body.year}.xlsx`;
      this.filename = `${table_name}_${req.body.year}.xlsx`;
    }
    //check if file extension is xls and change filename to .xls
    else if (file.originalname.split('.').pop() === "xls") {
      filename = `${table_name}_${req.body.year}.xls`;
      this.filename = `${table_name}_${req.body.year}.xls`;
    }
    //pass current filename to callback function
    callback(null, filename);
  },
});
let upload = multer({
  storage: storage,
}).array("upload", 12);

exports.getFileTypeList = (req, res) => {
  DmaFile.getFileTypeList(req, (err, data) => {
    if (err) {
      res.status(500).send({
        message: "Error retrieving upload file list",
      });
    } else res.json(data);
  });
};

//API - /private/dma/v1/user/importHealthChain
exports.ImportHealthChain = function (req, res) {
  let fileMonth = "" + `${req.body.fileMonth}`;
  let fileYear = "" + `${req.body.fileYear}`;
  let fileUserId = "" + `${req.body.userId}`;
  let fileTypeId = "" + `${req.body.fileTypeId}`;
  let tableName = "" + `${req.body.tableName}`;
  let fileName = "" + tableName + ".csv";

  try {
    let sourceFolderPath = config.con.internalSource;
    let sourceFilePath = path
      .join(__dirname, sourceFolderPath, fileName)
      .replaceAll('\\', "/");
    let destPath = config.con.temp;
    let destFolderPath = path
      .join(__dirname, destPath, fileUserId, fileYear, fileMonth)
      .replaceAll("\\", "/");
    let destFilePath = path.join(destFolderPath, fileName).replaceAll(/\\/g, "/");

    if (!fs.existsSync(sourceFilePath)) {
      let message = "Internal file not found for copy. Please check.";
      res.status(500).send({
        message: message,
      });

      return res;
    }

    if (!fs.existsSync(destFolderPath)) {
      fs.mkdirSync(destFolderPath, {
        recursive: true,
      });
    }

    fs.copyFile(sourceFilePath, destFilePath, function (err) {
      if (err) {
        res.status(500).send({
          message: "Error during internal file copy...",
        });
      } else {
        console.log("Successfully copied from internal to user folder!");

        req.body.fileName = fileName;
        req.body.fileTypeId = fileTypeId;
        req.body.tableName = tableName;
        // res = createDMARecord(req, res);
      }
    });
  } catch (err) {
    console.error(err);
    res.status(500).send({
      message: "Error: File processing failed!",
    });
  }
  return res;
};

const createDMARecord = function (req, res) {
  let table_name = req.body.Table_Name.replaceAll(/(\r\n|\n|\r)/gm, "");
  let fileName = "" + `${table_name}_${req.body.year}.csv`;
  let year = "" + `${req.body.year}`;
  let user_id = "" + `${req.body.user_id}`;
  let Original_Name = "" + `${req.body.originalName}`;
  let measure_group_id = "" + `${req.body.measure_group_id}`;
  let tableName = "" + `${table_name}`;
  let initPath = config.con.temp;
  let folderPath = path
    .join(initPath, user_id, year, tableName)
    .replaceAll('\\', "/");
  let filePath = path.join(folderPath, fileName).replaceAll('\\', "/");
  const fileObject = {
    User_ID: user_id,
    File_Categories_ID: measure_group_id,
    Year: year,
    File_Name: fileName,
    Is_Uploaded: "Uploaded",
    File_URL: filePath,
    folderPath: folderPath,
    Original_Name: Original_Name
  };
  DmaFile.create(fileObject, (err, data) => {
    if (err)
      return res.status(500).send({
        message: err.message || "Some error occurred while creating the User.",
      });
    return res.status(201).json(data);
  });
  //AddExec will come here
};


exports.uploadTest = function (req, res, callBack) {
  let filePath = `api/temp/1/2021/IPFQR_QualityMeasures_National/IPFQR_QualityMeasures_National_2021.csv`;
  let updatedFilePath = `api/temp/1/2021/IPFQR_QualityMeasures_National/IPFQR_QualityMeasures_National_2021.csv`;

  ReadFileNational(filePath)
    .then((Result) => {
      const newData = Result.filter(
        (row) =>
          row["Measure_ID"] !== "Start Date" &&
          row["Measure_ID"] !== "End Date" &&
          row["Measure_ID"] !== "FUH Measure Start Date" &&
          row["Measure_ID"] !== "FUH Measure End Date" &&
          row["Measure_ID"] !== "READM-30-IPF Start Date" &&
          row["Measure_ID"] !== "READM-30-IPF End Date" &&
          row["Measure_ID"] !== "Flu Season Start Date" &&
          row["Measure_ID"] !== "Flu Season End Date"
      );
      const csv = JSONtoCSV(newData);
      fs.writeFileSync(updatedFilePath, csv);
    })
    .catch((err) => {
      console.log("File Reading..!", err);
      return callBack({
        status: 500,
        message: "Error! File Reading Function Internal Server Error.",
      },
        null
      );
    });
};

async function ExcelToCsv(filePath, updatedFilePath) {
  const workBook = XLSX.readFile(filePath);
  XLSX.writeFileSync(workBook, updatedFilePath, {
    bookType: "csv"
  });
  console.log("====CSV file Created====");
}



exports.excelTest = async function (req, res, callBack) {
  const excelFilePath = `api/temp/1/2020/FUA/FUA_2020.xlsx`;
  const updatedFilePath = `api/temp/1/2020/FUA/FUA_2020.csv`;

  try {
    await ExcelToCsv(excelFilePath, updatedFilePath);
  } catch (error) {
    console.log("error", error);
    return callBack(
      {
        status: 500,
        message: "Error! File Reading Function Internal Server Error.",
      },
      null
    );
  }
};


function escapeNExp(str) {
  if (str.charAt(0) === 'N' && str.charAt(1) === ' ') {
    return str.substring(2);
  }
  return str;
}



async function ReadFileNational(filePath) {
  const result = await CSVtoJSON().fromFile(filePath);
  // creating the desired json output
  let data = [];
  for (const element of result) {
    for (const key in element) {
      const jsonData = {
        "Start Date": element["Start Date"],
        "End Date": element["End Date"],
        "FUH Measure Start Date": element["FUH Measure Start Date"],
        "FUH Measure End Date": element["FUH Measure End Date"],
        "READM-30-IPF Start Date": element["READM-30-IPF Start Date"],
        "READM-30-IPF End Date": element["READM-30-IPF End Date"],
        "Flu Season Start Date": element["Flu Season Start Date"],
        "Flu Season End Date": element["Flu Season End Date"],
        Measure_ID: escapeNExp(key),
        Score: element[key],
      };
      data.push(jsonData);
    }
  }
  return data;
}


function isMonthValidation(fileMonth) {
  return Number.isInteger(fileMonth) && fileMonth >= 1 && fileMonth <= 12;
}


function isYearValidation(fileYear) {
  if (fileYear) {
    if (fileYear.toString().length === 4) {
      let myRegEx = /^(0|[1-9]\d*)$/
      let isValid = (myRegEx.test(fileYear));
      if (isValid) {
        console.log(isValid, "true")
        return true;
      } else {
        console.log(isValid, "false")
        return false;
      }
    } else {
      console.log(fileYear, "false")
      return false;
    }
  } else {
    console.log(fileYear, "false")
    return false;
  }
}

function isUserIdValidation(userId) {
  let isUserId = Number.isInteger(userId);
  if (isUserId) {
    return true;
  } else {
    console.log(userId, "false")
    return false;
  }
}

function isIntValidation(data) {
  const myRegEx = /^(0|[1-9]\d*)$/;
  return myRegEx.test(data);
}


//API - /private/dma/v1/user/fileUpload
exports.fileUpload = function (req, res, callBack) {
  upload(req, res, function (err) {
    if (err) {
      res.status(500).send({
        message: "Some error occurred while uploading File.",
      });
    } else {
      if (!req.body) {
        res.status(400).send({
          message: "Content can not be empty!",
        });
      }
      let isYearValid = (isYearValidation(req.body.year));
      if (!isYearValid) {
        return res.status(400).send({
          message: "Invalid Input Year!"
        });
      }
      let isUserIdValid = (isIntValidation(req.body.user_id));
      if (!isUserIdValid) {
        return res.status(400).send({
          message: "Invalid Input User ID!"
        });
      }

      let isNumValid = (isIntValidation(req.body.measure_group_id));
      if (!isNumValid) {
        return res.status(400).send({
          message: "Invalid Input Measure Group ID!"
        });
      }

      let isValid = (isAlphaNumericSpaceParanValidation(req.body.Measure_Group_Name));
      if (!isValid) {
        return res.status(400).send({
          message: "Invalid Input Measure Group Name!"
        });
      }

      let isValid1 = (isAlphaNumericUnderscoreValidation(req.body.Table_Name));
      if (!isValid1) {
        return res.status(400).send({
          message: "Invalid Input Table Name!"
        });
      }

      //Upload to Azure Storage
      Hospital.hospitalUpload(req.body, (err, resResult) => {
        if (err) {
          console.log(err);
          return res.status(err.status).send({
            status: err.status,
            message: err.message,
          });
        } else {
          createDMARecord(req, res);
        }
      });
      // insert status
      // res = createDMARecord(req, res);
    }
    return res;
  });
};


exports.getFileType = (req, res) => {
  DmaFile.findById(req.params.customerId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found file with id ${req.params.customerId}.`,
        });
      } else {
        res.status(500).send({
          message: "Error retrieving file with id " + req.params.customerId,
        });
      }
    } else res.json(data);
  });
};

exports.getSalesforceFileList = (req, res) => {
  DmaFile.findById(req.body, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found data with id ${req.body.userId}.`,
        });
      } else {
        res.status(500).send({
          message: "Error retrieving data with id " + req.body.userId,
        });
      }
    } else res.json(data);
  });
};


function isAlphaNumericSpaceParanValidation(data) {
  const myRegEx = /^[a-zA-Z0-9\s_().-]*$/;
  return myRegEx.test(data);
}

function isNumberValidation(data) {
  return Number.isInteger(data);
}

function isAlphaNumericUnderscoreValidation(data) {
  const myRegEx = /^[a-z][a-z\d]*(?:_[a-z\d]+)*$/i;
  return myRegEx.test(data);
}

exports.findDmaList = (req, res) => {
  const { user_id, year, Measure_Group_Name, measure_group_id, originalName, Table_Name } = req.body;

  const validations = [
    { value: user_id, check: isNumberValidation, message: "Invalid User ID!" },
    { value: year, check: isYearValidation, message: "Invalid Year!", optional: true },
    { value: Measure_Group_Name, check: isAlphaNumericSpaceParanValidation, message: "Invalid Measure Group Name!", optional: true },
    { value: measure_group_id, check: isNumberValidation, message: "Invalid Measure Group ID!", optional: true },
    { value: originalName, check: isAlphaNumericSpaceParanValidation, message: "Invalid originalName!", optional: true },
    { value: Table_Name, check: isAlphaNumericSpaceParanValidation, message: "Invalid originalName!", optional: true }
  ];

  for (const rule of validations) {
    if (rule.optional && rule.value == null) {
      continue;
    }
    if (!rule.check(rule.value)) {
      return res.status(400).send({ message: rule.message });
    }
  }

  DmaFile.findDmaListById(req.body, (err, data) => {
    if (err) {
      const status = err.kind === "not_found" ? 404 : 500;
      const message =
        err.kind === "not_found"
          ? "File Not Found"
          : "Error retrieving file with id " + req.params.customerId;

      return res.status(status).send({ message });
    }

    res.json(data);
  });
};


exports.moveFiles = (req, res) => {
  const files = fs.readdirSync(`api/temp/${req.body.month}-${req.body.year}/`);

  let dir = `api/uploads/${req.body.month}-${req.body.year}`;
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir);
  }

  let result = [];
  for (const file of files) {
    (async () => {
      try {
        await moveFile(
          `api/temp/${req.body.month}-${req.body.year}/${file}`,
          `api/uploads/${req.body.month}-${req.body.year}/${file}`
        );
        result.push(file);
        if (result.length === files.length) {
          console.log("All Files Moved Successfully.....");
          const dmaFile = new DmaFile({
            userid: req.body.userId,
            year: req.body.year,
            month: req.body.month,
            isUploaded: "Submitted",
          });
          // Save User in the database
          DmaFile.updateById(dmaFile, (err, data) => {
            if (err)
              return res.status(500).send({
                message: err.message || "Some error occurred while creating the User.",
              });
            else
              return res.status(201).send({
                message: "Success: All Files Are Uploaded Successfully..!",
              });
          });
          //----
        }
      } catch (err) {
        // Handle failure
        console.error(err);
        res.status(500).send({
          message: "Error: File Upload Failed.!",
        });
      }
    })();
  }
};

// Get Integrated Table Details..
exports.getTableIntegrated = (req, res) => {
  // sql.query(`select * FRom maleads_integrated WHERE for_month = ? AND for_year = ?` , [req.body.fileMonth, req.body.fileYear], (err, data) => {
  sql.query(`select * FRom maleads_integrated`, (err, data) => {
    if (err) {
      console.log("error: ", err);
      return res.status(500).send({
        message: err,
      });
    }
    if (data.length <= 0) {
      return res.status(200).send({
        message: "No data Found !",
      });
    }
    return res.status(201).json(data);
  });
};

function buildTable(data) {
  let dataArray = [];
  data.forEach(function (tableData) {
    console.log(tableData.COLUMN_NAME);
    let dataObject = {
      COLUMN_NAME: tableData.COLUMN_NAME,
      ORDINAL_POSITION: tableData.ORDINAL_POSITION,
    };

    if (
      tableData.COLUMN_NAME !== "for_month" &&
      tableData.COLUMN_NAME !== "for_year"
    ) {
      dataArray.push(dataObject);
    }

  });
  return dataArray;
}

// Get datatable Pagination API.
exports.getDataTablePagination = (req, res) => {
  let length = req.body.length; //lenght
  let start = req.body.start;
  let limit = start + "," + length;
  let column = req.body.order[0].column;
  if (req.body.order[0].column === 0) {
    column = 1;
  }
  let state = "" + req.body.dateObject.state;
  let city = "" + req.body.dateObject.city;
  let zipcode = "" + req.body.dateObject.zipcode;
  let income = "" + req.body.dateObject.income;
  let score = req.body.dateObject.score;

  let isChecked = req.body.dateObject.isChecked;

  let dir = req.body.order[0].dir;
  let filterquery = "";
  // sql.query(`SELECT count(*) as numRows FROM  maleads_integrated where (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and
  //  for_month  = ${req.body.dateObject.fileMonth} and for_year = ${req.body.dateObject.fileYear}`, function (err, rows, fields) {

  let sqlquery = `SELECT count(*) as numRows FROM  maleads_integrated where (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and 
    for_month  = ${req.body.dateObject.fileMonth} and for_year = ${req.body.dateObject.fileYear} `;

  if (isChecked === true) {
    console.log(isChecked, "true.......................................");
    filterquery = ` and salesforce_id is null and integreted_id not in (SELECT integreted_id FROM saleaforce_pushed_data WHERE for_month= ${req.body.dateObject.fileMonth} and for_year = ${req.body.dateObject.fileYear} and status='pushed')`;
  }

  if (req.body.dateObject.state.length > 0) {
    let stateArr = state.split(",");
    const stateFinal = stateArr.map((c) => `'${c}'`).join(", ");
    filterquery = ` and state in (${stateFinal})`;
  }
  if (req.body.dateObject.city.length > 0) {
    let cityArr = city.split(",");
    const cityFinal = cityArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and city in (${cityFinal})`;
  }
  if (req.body.dateObject.zipcode.length > 0) {
    let zipcodeArr = zipcode.split(",");
    const zipcodeFinal = zipcodeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and zip_code in (${zipcodeFinal})`;
  }
  if (req.body.dateObject.income.length > 0) {
    console.log(income, "income");

    let incomeArr = income.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
    const incomeFinal = incomeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and income in (${incomeFinal})`;
  }

  if (req.body.dateObject.score) {

    let scoreArray = [];
    for (let i = 0; i < score.length; i++) {
      if (score[i].ischecked) {
        const ids = score[i].id;
        const scoreArr = ids.split("t");
        scoreArray.push(scoreArr[0], scoreArr[1]);
      }

    }

    if (scoreArray.length > 0) {
      let scoreMax = Math.max(...scoreArray);
      let scoreMin = Math.min(...scoreArray);
      filterquery =
        filterquery +
        ` and prediction_score BETWEEN  ${scoreMin} AND  ${scoreMax} `;
    }
  }

  if (req.body.dateObject.age) {
    filterquery =
      filterquery +
      ` and TIMESTAMPDIFF(YEAR, STR_TO_DATE(dob,'%m-%d-%Y'), CURDATE()) BETWEEN  ${req.body.dateObject.age.min} AND ${req.body.dateObject.age.max}`;
  }

  if (filterquery !== "") {
    sqlquery = sqlquery + filterquery;
  }

  sql.query(sqlquery, function (err, rows, fields) {
    if (err) {
      console.log("error: ", err);
      return res.status(500).send({
        message: err,
      });
    } else {
      let numRows = rows[0].numRows;
      // sql.query(`SELECT * FROM  maleads_integrated WHERE (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and for_month  = ${req.body.dateObject.fileMonth} and for_year = ${req.body.dateObject.fileYear}  ORDER BY ${column} ${dir} LIMIT ${limit}`, function (err, rows, fields) {

      let disquery = `SELECT *, TIMESTAMPDIFF(YEAR, STR_TO_DATE(dob,'%m-%d-%Y'), CURDATE()) as age, STR_TO_DATE(dob,'%m-%d-%Y') AS dobview  FROM  maleads_integrated WHERE (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and for_month  = ${req.body.dateObject.fileMonth} and for_year = ${req.body.dateObject.fileYear}`;

      if (filterquery !== "") {
        disquery = disquery + filterquery;
      }

      sql.query(
        disquery + `  ORDER BY ${column} ${dir} LIMIT ${limit}`,
        function (err, rows, fields) {
          if (err) {
            console.log("error: ", err);
            return res.status(500).send({
              message: err,
            });
          } else {
            let data = {
              data: rows,
              draw: req.body.draw,
              recordsFiltered: numRows,
              recordsTotal: numRows,
            };
            return res.status(201).json(data);
          }
        }
      );
    }
  });
};

exports.getSalesforcePushedData = (req, res) => {
  sql.query(
    `SELECT MAD_ID,city,address_line1,state,country,zip_code,first_name,last_name,product_family_name,phone,created_date,middle_initial,do_not_call,member_email,last_modified,lead_owner,lead_source,sic,dob,prospect_type,opportunity_record_type,sales_channel,enrollment_channel,agein_type_rel,closed_lost_reason,converted,effective_date,close_date,product_name,disenrollment_date,disenrollment_reason,last_activity,lead_record_type,lead_sub_type,ma_effective_date,opp_status,opportunity_date,opportunity_id,opportunity_owner,GIC_Mbr_Flag FROM  maleads_integrated INNER JOIN saleaforce_pushed_data on saleaforce_pushed_data.integreted_id= maleads_integrated.integreted_id WHERE (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and maleads_integrated.for_month  = ${req.body.fileMonth} and maleads_integrated.for_year = ${req.body.fileYear}`,
    function (err, data, fields) {
      if (err) {
        console.log("error: ", err);
        return res.status(500).send({
          message: err,
        });
      }
      if (data.length <= 0) {
        return res.status(200).send({
          message: "No data Found !",
        });
      }
      return res.status(201).json(data);
    }
  );
};

exports.getCityData = (req, res) => {
  let state = "" + req.body.state;
  let city = "" + req.body.city;
  let zipcode = "" + req.body.zipcode;

  let filterquery = "";

  if (req.body.state.length > 0) {
    let stateArr = state.split(",");
    const stateFinal = stateArr.map((c) => `'${c}'`).join(", ");
    filterquery = ` and state in (${stateFinal})`;
  }
  if (req.body.city.length > 0) {
    let cityArr = city.split(",");
    const cityFinal = cityArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and city in (${cityFinal})`;
  }
  if (req.body.zipcode.length > 0) {
    let zipcodeArr = zipcode.split(",");
    const zipcodeFinal = zipcodeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and zip_code in (${zipcodeFinal})`;
  }

  let disquery = `SELECT @rownum := @rownum + 1 AS item_id, table1.city as item_text FROM (SELECT DISTINCT city
          FROM   maleads_integrated where for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}`;

  if (filterquery !== "") {
    disquery = disquery + filterquery;
  }
  sql.query(
    disquery +
    `) table1
  JOIN (SELECT @rownum := 0) r`,
    "",
    (err, data) => {
      if (err) {
        console.log("error: ", err);
        return res.status(500).send({
          message: err,
        });
      }
      if (data.length <= 0) {
        return res.status(404).send({
          message: "No data Found !",
        });
      }
      return res.status(201).json(data);
    }
  );
};
exports.getStateData = (req, res) => {
  //   sql.query(`SELECT @rownum := @rownum + 1 AS item_id, table1.state as item_text FROM   (SELECT DISTINCT state FROM   maleads_integrated where for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}) table1
  //   JOIN (SELECT @rownum := 0) r`, function (err, data, fields) {

  let state = "" + req.body.state;
  let city = "" + req.body.city;
  let zipcode = "" + req.body.zipcode;

  let filterquery = "";

  if (req.body.state.length > 0) {
    let stateArr = state.split(",");
    const stateFinal = stateArr.map((c) => `'${c}'`).join(", ");
    filterquery = ` and state in (${stateFinal})`;
  }
  if (req.body.city.length > 0) {
    let cityArr = city.split(",");
    const cityFinal = cityArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and city in (${cityFinal})`;
  }
  if (req.body.zipcode.length > 0) {
    let zipcodeArr = zipcode.split(",");
    const zipcodeFinal = zipcodeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and zip_code in (${zipcodeFinal})`;
  }

  let disquery = `SELECT @rownum := @rownum + 1 AS item_id, table1.state as item_text FROM   (SELECT DISTINCT state FROM   maleads_integrated where for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}`;

  if (filterquery !== "") {
    disquery = disquery + filterquery;
  }
  sql.query(
    disquery + `) table1 JOIN (SELECT @rownum := 0) r`,
    "",
    (err, data) => {
      if (err) {
        console.log("error: ", err);
        return res.status(500).send({
          message: err,
        });
      }
      if (data.length <= 0) {
        return res.status(404).send({
          message: "No data Found !",
        });
      }
      return res.status(201).json(data);
    }
  );
};

exports.getZipcodeData = (req, res) => {
  // sql.query(`SELECT @rownum := @rownum + 1 AS item_id, table1.zip_code as item_text FROM   (SELECT DISTINCT zip_code FROM   maleads_integrated where for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}) table1
  // JOIN (SELECT @rownum := 0) r`, function (err, data, fields) {
  let state = "" + req.body.state;
  let city = "" + req.body.city;
  let zipcode = "" + req.body.zipcode;

  let filterquery = "";

  if (req.body.state.length > 0) {
    let stateArr = state.split(",");
    const stateFinal = stateArr.map((c) => `'${c}'`).join(", ");
    filterquery = ` and state in (${stateFinal})`;
  }
  if (req.body.city.length > 0) {
    let cityArr = city.split(",");
    const cityFinal = cityArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and city in (${cityFinal})`;
  }
  if (req.body.zipcode.length > 0) {
    let zipcodeArr = zipcode.split(",");
    const zipcodeFinal = zipcodeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and zip_code in (${zipcodeFinal})`;
  }
  let disquery = `SELECT @rownum := @rownum + 1 AS item_id, table1.zip_code as item_text FROM (SELECT DISTINCT zip_code FROM   maleads_integrated where for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}`;

  if (filterquery !== "") {
    disquery = disquery + filterquery;
  }

  sql.query(
    disquery + `) table1 JOIN (SELECT @rownum := 0) r`,
    "",
    (err, data) => {
      if (err) {
        console.log("error: ", err);
        return res.status(500).send({
          message: err,
        });
      }
      if (data.length <= 0) {
        return res.status(404).send({
          message: "No data Found !",
        });
      }
      return res.status(201).json(data);
    }
  );
};

exports.getIncomeData = (req, res) => {
  sql.query(
    `SELECT @rownum := @rownum + 1 AS item_id,
  table1.income as item_text
FROM   (SELECT DISTINCT income
   FROM   maleads_integrated where for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}) table1
  JOIN (SELECT @rownum := 0) r`,
    function (err, data, fields) {
      if (err) {
        console.log("error: ", err);
        return res.status(500).send({
          message: err,
        });
      }
      if (data.length <= 0) {
        return res.status(404).send({
          message: "No data Found !",
        });
      }
      return res.status(201).json(data);
    }
  );
};
exports.getAgeData = (req, res) => {
  sql.query(
    `SELECT @rownum := @rownum + 1 AS item_id,
  table1.age as item_text
FROM   (SELECT DISTINCT TIMESTAMPDIFF(YEAR, STR_TO_DATE(dob,'%m-%d-%Y'), CURDATE()) as age
  FROM   maleads_integrated where for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}) table1
 JOIN (SELECT @rownum := 0) r`,
    function (err, data, fields) {
      if (err) {
        console.log("error: ", err);
        return res.status(500).send({
          message: err,
        });
      }
      if (data.length <= 0) {
        return res.status(404).send({
          message: "No data Found !",
        });
      }
      return res.status(201).json(data);
    }
  );
};

exports.selectAllRow = (req, res) => {
  let state = "" + req.body.state;
  let city = "" + req.body.city;
  let zipcode = "" + req.body.zipcode;
  let income = "" + req.body.income;
  let isChecked = req.body.isChecked;
  let score = req.body.score;
  let filterquery = "";
  let sqlquery = `SELECT count(*) as numRows FROM  maleads_integrated where (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and 
    for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear} `;
  if (isChecked === true) {

    filterquery = ` and integreted_id not in (SELECT integreted_id FROM saleaforce_pushed_data WHERE for_month= ${req.body.fileMonth} and for_year = ${req.body.fileYear} and status='pushed')`;
  }
  if (req.body.state.length > 0) {
    let stateArr = state.split(",");
    const stateFinal = stateArr.map((c) => `'${c}'`).join(", ");
    filterquery = ` and state in (${stateFinal})`;
  }
  if (req.body.city.length > 0) {
    let cityArr = city.split(",");
    const cityFinal = cityArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and city in (${cityFinal})`;
  }
  if (req.body.zipcode.length > 0) {
    let zipcodeArr = zipcode.split(",");
    const zipcodeFinal = zipcodeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and zip_code in (${zipcodeFinal})`;
  }
  if (req.body.income.length > 0) {
    let incomeArr = income.split(",");
    const incomeFinal = incomeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and income in (${incomeFinal})`;
  }

  if (req.body.score) {
    let scoreArray = [];
    for (let i = 0; i < score.length; i++) {
      if (score[i].ischecked) {
        let ids = score[i].id;
        let scoreArr = ids.split("t");
       scoreArray.push(scoreArr[0], scoreArr[1]);

      }
    }

    if (scoreArray.length > 0) {
      let scoreMax = Math.max(...scoreArray);
      let scoreMin = Math.min(...scoreArray);
      filterquery =
        filterquery +
        ` and prediction_score BETWEEN  ${scoreMin} AND  ${scoreMax} `;
    }
  }

  if (req.body.age) {
    filterquery =
      filterquery +
      ` and TIMESTAMPDIFF(YEAR, STR_TO_DATE(dob,'%m-%d-%Y'), CURDATE()) BETWEEN  ${req.body.age.min} AND ${req.body.age.max}`;
  }
  if (filterquery !== "") {
    sqlquery = sqlquery + filterquery;
  }

  sql.query(sqlquery, function (err, rows, fields) {
    if (err) {
      console.log("error: ", err);
      return res.status(500).send({
        message: err,
      });
    } else {
      let disquery = `SELECT integreted_id FROM  maleads_integrated WHERE (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}`;
      if (filterquery !== "") {
        disquery = disquery + filterquery;
      }
      sql.query(disquery, function (err, rows, fields) {
        if (err) {
          console.log("error: ", err);
          return res.status(500).send({
            message: err,
          });
        } else {
          let data = {
            data: rows,
          };
          return res.status(201).json(data);
        }
      });
    }
  });
};

exports.getSalesforcePulledData = (req, res) => {
  sql.query(
    `SELECT * FROM sdfc_leads_source_hist where for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear}`,
    function (err, data, fields) {
      if (err) {
        console.log("error: ", err);
        return res.status(500).send({
          message: err,
        });
      }
      if (data.length <= 0) {
        return res.status(200).send({
          message: "No data Found !",
        });
      }
      return res.status(201).json(data);
    }
  );
};


exports.InsertSalesforcePushedData = (req, res) => {
  let state = "" + req.body.state;
  let city = "" + req.body.city;
  let zipcode = "" + req.body.zipcode;
  let income = "" + req.body.income;
  let fileMonth = "" + `${req.body.fileMonth}`;
  let fileYear = "" + `${req.body.fileYear}`;
  let userId = "" + `${req.body.userId}`;
  let fileName = "Salesforce Leads";
  let isCheckedLeadsAll = `${req.body.isCheckedLeadsAll}`;
  let integratedLead = "" + req.body.integratedLead;

  let filterquery = "";

  if (isCheckedLeadsAll) {
    filterquery = ` and integreted_id not in (SELECT integreted_id FROM saleaforce_pushed_data WHERE for_month= ${req.body.fileMonth} and for_year = ${req.body.fileYear} and status='pushed')`;
  }

  if (req.body.state.length > 0) {
    let stateArr = state.split(",");
    const stateFinal = stateArr.map((c) => `'${c}'`).join(", ");
    filterquery = ` and state in (${stateFinal})`;
  }
  if (req.body.city.length > 0) {
    let cityArr = city.split(",");
    const cityFinal = cityArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and city in (${cityFinal})`;
  }
  if (req.body.zipcode.length > 0) {
    let zipcodeArr = zipcode.split(",");
    const zipcodeFinal = zipcodeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and zip_code in (${zipcodeFinal})`;
  }
  if (req.body.income.length > 0) {
    let incomeArr = income.split(",");
    const incomeFinal = incomeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and income in (${incomeFinal})`;
  }

  if (req.body.age) {
    filterquery =
      filterquery +
      ` and TIMESTAMPDIFF(YEAR, STR_TO_DATE(dob,'%m-%d-%Y'), CURDATE()) BETWEEN  ${req.body.age.min} AND ${req.body.age.max}`;
  }

  if (req.body.integratedLead.length > 0) {
    let integratedLeadArr = integratedLead.split(",");
    const integratedLeadFinal = integratedLeadArr
      .map((c) => `'${c}'`)
      .join(", ");
    filterquery =
      filterquery + ` and integreted_id in (${integratedLeadFinal})`;
  }

  let disquery = `INSERT INTO saleaforce_pushed_data (integreted_id,for_month,for_year,user_id) SELECT integreted_id,for_month,for_year,1 as user_id FROM  maleads_integrated WHERE (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear} `;
  // let disquery=`INSERT INTO saleaforce_pushed_data (integreted_id,for_month,for_year,user_id) SELECT integreted_id,for_month,for_year,1 as user_id FROM  maleads_integrated `

  if (filterquery !== "") {
    disquery = disquery + filterquery;
  }
  sql.query(disquery, "", (err, result) => {
    // sql.query("INSERT INTO saleaforce_pushed_data (integreted_id,for_month,for_year,user_id) SELECT integreted_id,for_month,for_year,1 as user_id FROM  maleads_integrated WHERE do_not_call=0 or do_not_call is null and  disenrollment_reason!='Death' or disenrollment_reason is null and sfdc_sales_id=0 and edr_id=0 limit 10",'', (err, res) => {
    // sql.query(resquery, rows, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return;
    }

    if (os.platform().startsWith("linux")) {
      // sql.query("SELECT * FROM `lead`", function (error, data, fields) {
      sql.query(
        `SELECT salesforce_id as Id,city as City,address_line1 as Street,state as State,country as Country,zip_code as PostalCode,first_name as FirstName,last_name as LastName,product_family_name as Company,phone as Phone, do_not_call as DoNotCall,member_email as Email,lead_source as LeadSource,sic as SICCode__c,STR_TO_DATE(dob, '%m-%d-%Y') as Date_of_Birth__c,prospect_type as Prospect_type__c,opportunity_record_type as Opportunity_Record_Type__c,sales_channel as Sales_Channel__c,enrollment_channel as Enrollment_Channel__c,agein_type_rel as Age_In_Type__c,closed_lost_reason as Closed_Lost_Reason__c,converted as Converted__c, STR_TO_DATE(effective_date, '%m-%d-%Y') as Effective_Date__c, STR_TO_DATE(close_date, '%m-%d-%Y') as Close_Date__c,product_name as Product_Name__c, STR_TO_DATE(disenrollment_date, '%m-%d-%Y') as Disenrollment_Date__c,disenrollment_reason as Disenrollment_Reason__c,last_activity as Last_Activity__c,lead_record_type as Lead_Record_Type__c,lead_sub_type as Lead_Subtype__c,STR_TO_DATE(ma_effective_date, '%m-%d-%Y') as MA_Effective_Date__c,opp_status as Opportunity_Status__c, STR_TO_DATE(opportunity_date, '%d-%m-%Y') as Opportunity_Date__c , opportunity_id as Opportunity_Id__c,opportunity_owner as Opportunity_Owner__c,GIC_Mbr_Flag as Flag__c FROM maleaddb3.salesforce_leads where integreted_id in (SELECT integreted_id FROM saleaforce_pushed_data WHERE for_month= ${req.body.fileMonth} and for_year = ${req.body.fileYear} and status is null);`,
        function (error, data, fields) {
          if (error) throw error;
          const jsonData = structuredClone(data);
          console.log("jsonData", jsonData);
          const json2csvParser = new Json2csvParser({
            header: true,
          });
          const csv = json2csvParser.parse(jsonData);
          fs.writeFile("/root/leadpoc/upload/lead.csv", csv, function (error) {
            //  fs.writeFile("lead.csv", csv, function (error) {
            if (error) throw error;
            const spawn = require("node:child_process").spawn;
            const ls = spawn("./export.sh", []);


            ls.on("close", (code) => {
              sql.query(
                "UPDATE dmafile SET isSalesForcePush=1 WHERE userid = ? AND fileName = ? AND month = ? AND year = ?",
                [userId, fileName, fileMonth, fileYear],
                (err, res) => {
                  if (err) {
                    console.log("error: ", err);
                  }

                  sql.query(
                    "UPDATE saleaforce_pushed_data SET status='pushed' WHERE user_id = ? AND for_month = ? AND for_year = ?",
                    [userId, fileMonth, fileYear],
                    (err, res) => {
                      if (err) {
                        console.log("error: ", err);

                      }
                    }
                  );
                }
              );

              res.status(200).send({
                message: "export Successfully!",
              });
            });
            console.log("lead.csv successfully Created !");
          });
        }
      );
    } else if (os.platform().startsWith("win")) {
      console.log("not implemented on Windows yet");
    }
  });
};

exports.UpdatePrediction = (req, res) => {
  let state = "" + req.body.state;
  let city = "" + req.body.city;
  let zipcode = "" + req.body.zipcode;
  let income = "" + req.body.income;
  let isCheckedLeadsAll = `${req.body.isCheckedLeadsAll}`;
  let integratedLead = "" + req.body.integratedLead;
  let filterquery = "";

  if (isCheckedLeadsAll) {
    filterquery = ` and integreted_id not in (SELECT integreted_id FROM saleaforce_pushed_data WHERE for_month= ${req.body.fileMonth} and for_year = ${req.body.fileYear} and status='pushed')`;
  }
  if (req.body.state.length > 0) {
    let stateArr = state.split(",");
    const stateFinal = stateArr.map((c) => `'${c}'`).join(", ");
    filterquery = ` and state in (${stateFinal})`;
  }
  if (req.body.city.length > 0) {
    let cityArr = city.split(",");
    const cityFinal = cityArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and city in (${cityFinal})`;
  }
  if (req.body.zipcode.length > 0) {
    let zipcodeArr = zipcode.split(",");
    const zipcodeFinal = zipcodeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and zip_code in (${zipcodeFinal})`;
  }
  if (req.body.income.length > 0) {
    let incomeArr = income.split(",");
    const incomeFinal = incomeArr.map((c) => `'${c}'`).join(", ");
    filterquery = filterquery + ` and income in (${incomeFinal})`;
  }
  if (req.body.age) {
    filterquery =
      filterquery +
      ` and TIMESTAMPDIFF(YEAR, STR_TO_DATE(dob,'%m-%d-%Y'), CURDATE()) BETWEEN  ${req.body.age.min} AND ${req.body.age.max}`;
  }
  if (req.body.integratedLead.length > 0) {
    let integratedLeadArr = integratedLead.split(",");
    const integratedLeadFinal = integratedLeadArr
      .map((c) => `'${c}'`)
      .join(", ");
    filterquery =
      filterquery + ` and integreted_id in (${integratedLeadFinal})`;
  }

  let disquery = `SELECT MAD_ID as unique_id, TIMESTAMPDIFF(YEAR, STR_TO_DATE(dob,'%m-%d-%Y'), CURDATE()) as age, for_month as month , 'M' as gender, income , education ,married, ethnicity, personicx FROM  maleads_integrated WHERE (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear} `;

  //let disquery = `INSERT INTO saleaforce_pushed_data (integreted_id,for_month,for_year,user_id) SELECT integreted_id,for_month,for_year,1 as user_id FROM  maleads_integrated WHERE (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0 and for_month  = ${req.body.fileMonth} and for_year = ${req.body.fileYear} `

  if (filterquery !== "") {
    disquery = disquery + filterquery;
  }
  sql.query(disquery, "", (err, result) => {
    if (err) {
      console.log("error: ", err);
      return;
    }
    return res.status(200).json(result);
  });
};

exports.updatePredictionScore = (req, res) => {
  let axios = require("axios");
  let disquery = `SELECT MAD_ID as unique_id, TIMESTAMPDIFF(YEAR, STR_TO_DATE(dob,'%m-%d-%Y'), CURDATE()) as age, for_month as month , 'M' as gender, income , education ,married, ethnicity, personicx FROM  maleads_integrated WHERE (do_not_call=0 or do_not_call is null) and  (disenrollment_reason!='Death' or disenrollment_reason is null) and sfdc_sales_id=0 and edr_id=0`;
  sql.query(disquery, "", (err, result) => {
    if (err) {
      console.log("error: ", err);
      return;
    }
    let reqdata = JSON.stringify(result);
    let config = {
      method: "post",
      url: "http://164.52.194.25:8017/predict-sale",
      headers: {
        "Content-Type": "application/json",
      },
      data: reqdata,
    };

    axios(config)
      .then(function (predctionUrlResponse) {
        let scores = predctionUrlResponse.data;
        let requests = scores.map((id) => {
          return new Promise((resolve, reject) => {
            let requestQuery = `UPDATE maleads_integrated SET prediction_score=${id.sale_probability} WHERE MAD_ID = ${id.unique_id};`;
            sql.query(requestQuery, function (err, data, result) {
              if (err) {
                console.log("sql access error: ", err);
                reject(err);
              } else {
                resolve(result);
              }
            });
          });
        });
        Promise.all(requests)
          .then((body) => {
            return res.status(200).send({
              message: "Updated Successfully.!",
            });
          })
          .catch((err) => console.log(err));
      })
      .catch((error) => {
        console.log("Prediction  error.", error);
      });
  });
};

exports.UpdateSalesforcePushedData = (req, res) => {
  const leaddata = new DmaFile({
    user_id: req.body.userId,
    for_year: req.body.year,
    for_month: req.body.month,
    status: req.body.status,
  });
  // Save User in the database
  DmaFile.updateleadsById(leaddata, (err, data) => {
    if (err)
      return res.status(500).send({
        message: err.message ||
          "Some error occurred while updating the pushed salesforce lead data status.",
      });
    else
      return res.status(201).send({
        message: "Success: Status is updated in all records Successfully..!",
      });
  });
};

exports.getSPProgressStatus = (req, res) => {
  sql.query(
    `SELECT * FROM SP_Progress left join SP_Names on SP_Names.id=SP_Names_id where formonth  = ${req.body.procfileMonth} and foryear = ${req.body.procfileYear} and iscompleted=1`,
    function (err, data, fields) {
      // sql.query(`SELECT * FROM SP_Progress left join SP_Names on SP_Names.id=SP_Names_id where iscompleted=1`, function (err, data, fields) {

      if (err) {
        console.log("error: ", err);
        return res.status(500).send({
          message: err,
        });
      }
      if (data.length <= 0) {
        return res.status(200).send({
          message: "No data Found !",
        });
      }
      return res.status(201).json(data);
    }
  );
};

// get table field type...
exports.getTableField = (req, res) => {
  let dataArray;
  if (req.body.Table_Name === "HAI_National") {
    dataArray = [{
      COLUMN_NAME: "Measure ID",
      ORDINAL_POSITION: 1,
    },
    {
      COLUMN_NAME: "Measure Name",
      ORDINAL_POSITION: 2,
    },
    {
      COLUMN_NAME: "Score",
      ORDINAL_POSITION: 3,
    },
    {
      COLUMN_NAME: "Footnote",
      ORDINAL_POSITION: 4,
    },
    {
      COLUMN_NAME: "Start Date",
      ORDINAL_POSITION: 5,
    },
    {
      COLUMN_NAME: "End Date",
      ORDINAL_POSITION: 6,
    },
    ];
  }
  return res.status(201).json(dataArray);

};