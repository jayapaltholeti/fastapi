const User = require("../models/userModel");

const axios = require('axios');
const qs = require('qs');
const jwtDecode = require('jwt-decode');



exports.debugUserAPI = (req, res) => {
  res.status(200).send({
    message: "Successfully Tested.."
  });
};



// Create and Save a new User
exports.create = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  const emailvalidator = require("email-validator");
  if (!emailvalidator.validate(req.body.Email)) {
    return res.status(400).send({
      message: "Invalid Email"
    });
  }
  let isNumValidFirst_Name = (isAlphaSpaceValidation(req.body.First_Name));
  if (!isNumValidFirst_Name) {
    return res.status(400).send({
      message: "Invalid Input Hospital ID !"
    });
  }
  let isNumValidLast_Name = (isAlphaSpaceValidation(req.body.Last_Name));
  if (!isNumValidLast_Name) {
    return res.status(400).send({
      message: "Invalid Input Measure Group ID!"
    });
  }
  let isNumValid = (isIntValidation(req.body.Roles_ID));
  if (!isNumValid) {
    return res.status(400).send({
      message: "Invalid Roles ID!"
    });
  }

  // Create a User
  const user = new User({
    email: req.body.Email,
    firstname: req.body.First_Name,
    lastname: req.body.Last_Name,
    apassword: req.body.apassword,
    role: req.body.Roles_ID
  });

  // Save User in the database
  User.create(user, (err, data) => {
    if (err)
      if (err.kind === "already_exist") {
        res.status(409).send({
          message: " The username already exists. Please use a different username"
        });
      } else {
        return res.status(500).send({
          message: err.message || "Some error occurred while creating the User."
        });
      }
    else return res.status(201).json(data);
  });
};


function isAlphaSpaceValidation(data) {
  let myRegEx = /^[a-zA-Z ]*$/;
  let isValid = (myRegEx.test(data));
  return !!(isValid);
}

function isIntValidation(data) {
  let myRegEx = /^(0|[1-9]\d*)$/
  let isValid = (myRegEx.test(data));
  return !!(isValid);
}

// Create and Save a new User
exports.signIn = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  const emailvalidator = require("email-validator");
  if (!emailvalidator.validate(req.body.email)) {
    return res.status(400).send({
      message: "Invalid Email"
    });
  }

  const user = new User({
    email: req.body.email,
    apassword: req.body.apassword
  });
  // User SignIn
  User.signIn(user, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: "Invalid credentials"
        });
      } else {
        res.status(500).send({
          message: "Some error occurred while SignIn user" + req.body.email
        });
      }
    } else return res.status(201).json(data);
  });

};

// SSO
exports.signInSSO = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  const emailvalidator = require("email-validator");
  if (!emailvalidator.validate(req.body.email)) {
    return res.status(400).send({
      message: "Invalid Email"
    });
  }
  const user = new User({
    email: req.body.email,
    apassword: req.body.apassword
  });
  //----------------------------------------------------------------------------------------------
  User.checkAdminUser(user, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        //SSO Client Details.
        const APP_ID = '7b81ab7b-c9b4-4724-9c24-30d7403828b0';
        const APP_SECERET = '4Mz8Q~38up5CsThi2-k3nW6ppz_kBQQg9gRSta7r';
        const TOKEN_ENDPOINT = 'https://login.microsoftonline.com/2c93d3cb-f285-49c4-8265-fba1bd1fe468/oauth2/v2.0/token';
        const MS_GRAPH_SCOPE = 'https://graph.microsoft.com/.default';

        const postData = {
          client_id: APP_ID,
          scope: MS_GRAPH_SCOPE,
          client_secret: APP_SECERET,
          grant_type: 'password',
          username: req.body.email,
          password: req.body.apassword
        };

       

        axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
        axios
          .post(TOKEN_ENDPOINT, qs.stringify(postData))
          .then(token_response => {
        
            let decodedToken = jwtDecode(token_response.data.access_token);
   
            const user = new User({
              email: decodedToken.upn,
              apassword: req.body.apassword,
              token: token_response.data.access_token,
              firstname: decodedToken.given_name,
              lastname: decodedToken.name,
            });
            User.signIn(user, (err, data) => {
              if (err) {
                if (err.kind === "not_found") {
                  res.status(404).send({
                    message: "The user account does not exist! please Contact to HQM Admin!"
                  });
                } else {
                  res.status(500).send({
                    message: "Some error occurred while SignIn user" + req.body.email
                  });
                }
              } else return res.status(200).json(data);
            });
          }).catch(error => {
          
            if (error.response.data) {
              if (error.response.data.error_codes[0] === '50034') {
                return res.status(404).send({
                  message: "The user account {EmailHidden} does not exist in the Azure Account please Contact Azure Account Admin!"
                });
              } else if (error.response.data.error_codes[0] === '50126') {
                return res.status(401).send({
                  message: "Invalid Credentials!"
                });
              } else {
                return res.status(400).send({
                  message: "Invalid Credentials!" + JSON.stringify(error.response.data)
                });
              }
            } else {
              return res.status(400).send({
                message: "Invalid Credentials! " + JSON.stringify(error)
              });
            }
          });
      } else {
        res.status(500).send({
          message: "Some error occurred while SignIn user" + req.body.email
        });
      }
    } else {
      // User SignIn
      User.signInWithCred(user, (err, data) => {
        if (err) {
          if (err.kind === "not_found") {
            res.status(404).send({
              message: "Invalid credentials"
            });
          } else {
            res.status(500).send({
              message: "Some error occurred while SignIn user" + req.body.email
            });
          }
        } else return res.status(201).json(data);
      });
    }
  });
};

exports.createSSO = (req, res) => {
  // Validate request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
  const emailvalidator = require("email-validator");
  if (!emailvalidator.validate(req.body.email)) {
    return res.status(400).send({
      message: "Invalid Email"
    });
  }
  //SSO Client Details.
  const APP_ID = '7b81ab7b-c9b4-4724-9c24-30d7403828b0';
  const APP_SECERET = '4Mz8Q~38up5CsThi2-k3nW6ppz_kBQQg9gRSta7r';
  const TOKEN_ENDPOINT = 'https://login.microsoftonline.com/2c93d3cb-f285-49c4-8265-fba1bd1fe468/oauth2/v2.0/token';
  const MS_GRAPH_SCOPE = 'https://graph.microsoft.com/.default';

  const postData = {
    client_id: APP_ID,
    scope: MS_GRAPH_SCOPE,
    client_secret: APP_SECERET,
    grant_type: 'password',
    username: req.body.email,
    password: req.body.apassword
  };

  axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
  axios
    .post(TOKEN_ENDPOINT, qs.stringify(postData))
    .then(token_response => {   

      // Create a User
      const user = new User({
        email: req.body.email,
        firstname: req.body.firstname,
        lastname: req.body.lastname,
        apassword: req.body.apassword
      });

      // Save User in the database
      User.create(user, (err, data) => {
        if (err)
          if (err.kind === "already_exist") {
            res.status(409).send({
              message: " The username already exists. Please use a different username"
            });
          } else {
            return res.status(500).send({
              message: err.message || "Some error occurred while creating the User."
            });
          }
        else return res.status(201).json(data);
      });

    }).catch(error => {
      if (error.response.data) {
        if (error.response.data.error_codes[0] === '50034') {
          return res.status(404).send({
            message: "The user account {EmailHidden} does not exist in the Azure Account please Contact Azure Account Admin!"
          });
        } else if (error.response.data.error_codes[0] === '50126') {
          return res.status(401).send({
            message: "Invalid Credentials!"
          });
        } else {
          return res.status(400).send({
            message: "Invalid Credentials!"
          });
        }
      } else {
        return res.status(400).send({
          message: "Invalid Credentials!"
        });
      }
    });
};


// Retrieve all users from the database.
exports.findAll = (req, res) => {
  User.getAll((err, data) => {
    if (err)
      res.status(500).send({
        message: err.message || "Some error occurred while retrieving users."
      });
    else res.send(data);
  });
};

// Find a single User with a customerId
exports.findOne = (req, res) => {
  User.findById(req.params.customerId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found User with id ${req.params.customerId}.`
        });
      } else {
        res.status(500).send({
          message: "Error retrieving User with id " + req.params.customerId
        });
      }
    } else res.send(data);
  });
};

// Update a User identified by the customerId in the request
exports.update = (req, res) => {
  // Validate Request
  if (!req.body) {
    res.status(400).send({
      message: "Content can not be empty!"
    });
  }
 
  User.updateById(
    req.params.customerId,
    new User(req.body),
    (err, data) => {
      if (err) {
        if (err.kind === "not_found") {
          res.status(404).send({
            message: `Not found User with id ${req.params.customerId}.`
          });
        } else {
          res.status(500).send({
            message: "Error updating User with id " + req.params.customerId
          });
        }
      } else res.send(data);
    }
  );
};

// Delete a User with the specified customerId in the request
exports.delete = (req, res) => {
  User.remove(req.params.customerId, (err, data) => {
    if (err) {
      if (err.kind === "not_found") {
        res.status(404).send({
          message: `Not found User with id ${req.params.customerId}.`
        });
      } else {
        res.status(500).send({
          message: "Could not delete User with id " + req.params.customerId
        });
      }
    } else res.send({
      message: `User was deleted successfully!`
    });
  });
};

// Delete all Customers from the database.
exports.deleteAll = (req, res) => {
  User.removeAll((err, data) => {
    if (err)
      res.status(500).send({
        message: err.message || "Some error occurred while removing all customers."
      });
    else res.send({
      message: `All users were deleted successfully!`
    });
  });
};