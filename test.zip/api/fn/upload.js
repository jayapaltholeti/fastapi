const util = require("node:util");
const path = require("node:path");
const multer = require("multer");

let storage = multer.diskStorage({
  destination: (req, file, callback) => {
    callback(null, path.join(`${__dirname}/../../upload`));
  },
  filename: (req, file, callback) => {
    const match = ["image/png", "image/jpeg"];

    if (!match.includes(file.mimetype)) {
      let message = `<strong>${file.originalname}</strong> is invalid. Only accept png/jpeg.`;
      return callback(message, null);
    }

    let filename = `${Date.now()}-bezkoder-${file.originalname}`;
    callback(null, filename);
  }
});

let uploadFiles = multer({ storage: storage }).array("multi-files", 10);
let uploadFilesMiddleware = util.promisify(uploadFiles);
module.exports = uploadFilesMiddleware;