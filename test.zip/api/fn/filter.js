let JWT = require('../fn/JWT');
const sql = require("../db.js");

module.exports = {
    authFilter: function (isCheck) {
        return (req, res, next) => {
            const authHeader = req.headers.authorization;
            if (authHeader) {
                const token = authHeader.split(' ')[1];
                JWT.getPayload(token)
                    .then(function (result) {
                        if (isCheck) {
                            console.log(result, "API Authonticated Successfully..");
                            let RoleQuery = `SELECT r.Role,rm.Module_Name,rm.Access FROM Users u INNER JOIN Roles r ON r.ID = u.Role_ID INNER JOIN Roles_Mapping rm ON rm.Role_ID = r.ID WHERE u.ID = ${result.ID}`
                            // let RoleQuery = `SELECT * FROM Users WHERE Email ='${userdata.email}' AND Is_Active == '1'`
                            sql.query(RoleQuery, (err, roleRes) => {
                                if (err) {
                                    console.log("error: ", err);
                                    result(err, null);
                                    return;
                                }
                                console.log("roleRes..", roleRes)
                                if (roleRes.recordset.length === 0) {
                                    result({
                                        kind: "not_found"
                                    }, null);
                                } else {
                                    const jsonObject = {
                                        'user': result.ID,
                                        'role': req.body.role,
                                        'module_name': req.body.module_name,
                                        'permission': req.body.permission,
                                    };
                                    let isAttribute = (checkAttributeStatus(roleRes.recordset, jsonObject));
                                    if (isAttribute.status) {
                                        req.user = result;
                                        next();
                                    } else {
                                        res.status(403).json({
                                            'status': 403,
                                            'message': "User Do Not Have Permission!"
                                        });
                                    }
                                }
                            });
                        } else {
                            req.user = result;
                            next();
                        }
                    }).catch(function (error) {
                        res.status(401).json({
                            'status': 401,
                            'message': "Your session is expired please login again."
                        });
                    });
            } else {
                return res.status(400).json({
                    'status': 400,
                    'message': "Token not found"
                });
            }
        }
    }
};

function checkAttributeStatus(rolesResult, jsonObject) {
    let found = {
        'data': null,
        'status': false
    };
    rolesResult.forEach(att => {
        if (att.Role === jsonObject.role && att.Module_Name === jsonObject.module_name && att.Access === jsonObject.permission) {
            found = {
                'data': jsonObject,
                'status': true
            };
        }
    });
    return found;
}