module.exports = {
  msg: {
    loggedIn: "Success! You have successfully logged in!"
  }
};
