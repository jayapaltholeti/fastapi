let env = process.env.NODE_ENV;
if (env === 'prod') {
  console.log = function () {};
  module.exports = {
    'con': {
      'conName': 'dev',
      'host': '',
      'user': '',
      'password': '',
      'port': 1433,
      'db': '',
      'internalSource': '../healthchain',
      'StorageConStr': ''
    },
  };
} else {
  module.exports = {
    con: {
      'conName': process.env.CON_NAME,
      'managedClientId': process.env.MANAGED_CLIENT_ID,
      'tenantId': process.env.TENANT_ID,
      'appId': process.env.APP_ID,
      'appSecret': process.env.APP_SECRET,
      'subscriptionId': process.env.SUBSCRIPTION_ID,
      'resourceGroup': process.env.RESOURCE_GROUP,
      'factoryName': process.env.FACTORY_NAME,
      
      'host': process.env.HOST,
      'database': process.env.DATABASE,
      
      'port': process.env.PORT,
      'internalSource': process.env.INTERNAL_SOURCE || '../healthchain',
      'options': {
        'encrypt': process.env.OPTIONS_ENCRYPT,
        'trustServerCertificate': process.env.OPTIONS_TRUST_CERT,
      },
      'StorageConStr': process.env.STORAGE_CON_STR
      }
  };
}