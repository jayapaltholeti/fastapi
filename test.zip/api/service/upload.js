const util = require("node:util");
const path = require("node:path");
const multer = require("multer");

let storage = multer.diskStorage({
  destination: (req, file, callback) => {
    callback(null, path.join(`${__dirname}/../../upload`));
  },
//   filename: (req, file, callback) => {
//       console.log(file,"file........");
//     const match = ["image/png", "image/jpeg"];
});

let uploadFiles = multer({ storage: storage }).array("multi-files", 10);
let uploadFilesMiddleware = util.promisify(uploadFiles);
module.exports = uploadFilesMiddleware;