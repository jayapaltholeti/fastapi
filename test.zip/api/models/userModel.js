const sql = require("../db.js");
let bcrypt = require('bcryptjs');
let salt = bcrypt.genSaltSync(7);
let JWT = require('../fn/JWT');

// constructor
const User = function (user) {
  this.email = user.email;
  this.firstname = user.firstname;
  this.lastname = user.lastname;
  this.apassword = user.apassword;
  this.role = user.role;
  this.token = user.token;

};


User.create = (newCustomer, result) => {
  console.log("inside create model", newCustomer);
  let selectQuery = `SELECT * FROM Users WHERE Email = '${newCustomer.email}'`
  sql.query(selectQuery, (err, res) => {
    console.log(selectQuery, "selectQuery")
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.recordset.length > 0) {
      console.log(res.recordset.length, "res.recordset.length")
      console.log(res.recordset, "res")
      result({
        kind: "already_exist"
      }, null);
    } else {
      // let password = newCustomer.apassword
      // console.log(password, "password")
      // bcrypt.hash(password, 10, function (err, hash) {
      let insertQuery = `INSERT INTO Users (First_Name,Last_Name,Email,Role_ID,Insurance_Company_ID) values(
         '${newCustomer.firstname}','${newCustomer.lastname}','${newCustomer.email}','${newCustomer.role}',1
       )`
      sql.query(insertQuery, (err, res) => {
        if (err) {
          console.log("error: ", err);
          result(err, null);
          return;
        }
        result(null, {
          id: res.insertId,
          ...newCustomer
        });
      });
      // })
    }
  });
};

// SSO modification
User.signIn = (userdata, result) => {
  // Adding below if condition code to check the `'` and replace
  if (userdata.email.includes(`'`)) {
    userdata.email = userdata.email.replaceAll("'", "''");
  }
  let selectQuery = `SELECT * FROM Users WHERE Email ='${userdata.email}' AND Is_Active = '1'`
  sql.query(selectQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    console.log(res, "response.....");
    if (res.recordset.length === 0) {
      console.log("Email does not exist")
      result({
        kind: "not_found"
      }, null);
    } else {
      let RoleQuery = `SELECT r.Role,rm.Module_Name,rm.Access FROM Users u INNER JOIN Roles r ON r.ID = u.Role_ID INNER JOIN Roles_Mapping rm ON rm.Role_ID = r.ID WHERE u.ID = ${res.recordset[0].ID}`
      // let RoleQuery = `SELECT * FROM Users WHERE Email ='${userdata.email}' AND Is_Active == '1'`
      sql.query(RoleQuery, (err, roleRes) => {
        if (err) {
          console.log("error: ", err);
          result(err, null);
          return;
        }
        console.log("roleRes..", roleRes)
        if (roleRes.recordset.length === 0) {
          result({
            kind: "not_found"
          }, null);
        } else {
          console.log("sucess")
          let userObj = {
            ID: res.recordset[0].ID,
            First_Name: res.recordset[0].First_Name,
            Last_Name: res.recordset[0].Last_Name,
            Email: res.recordset[0].Email,
            Logo: res.recordset[0].Logo,
            Insurance_Company_ID: res.recordset[0].Insurance_Company_ID,
            rols: roleRes.recordset,
          }
          console.log("user", userObj)
          let studentObject = {
            user: userObj,
            // token: userdata.token
            token: JWT.issue(userObj)
          }
          result(null, studentObject);
        }
      });
    }
  });
};

// cREDENTIAL LOGINS
User.signInWithCred = (userdata, result) => {
  // Escape single quotes in email
  if (userdata.email.includes("'")) {
    userdata.email = userdata.email.replace("'", "''");
  }

  const selectQuery = `
    SELECT * FROM Users 
    WHERE Email = '${userdata.email}' 
      AND Is_Active = '1'
  `;

  sql.query(selectQuery, (err, res) => {
    if (err) {
      console.log("error:", err);
      return result(err, null);
    }

    console.log(res, "response.....");

    if (res.recordset.length === 0) {
      console.log("Email does not exist");
      return result({ kind: "not_found" }, null);
    }

    const userId = res.recordset[0].ID;

    const roleQuery = `
      SELECT r.Role, rm.Module_Name, rm.Access
      FROM Users u
      INNER JOIN Roles r ON r.ID = u.Role_ID
      INNER JOIN Roles_Mapping rm ON rm.Role_ID = r.ID
      WHERE u.ID = ${userId}
    `;

    sql.query(roleQuery, (err, roleRes) => {
      if (err) {
        console.log("error:", err);
        return result(err, null);
      }

      console.log("roleRes..", roleRes);

      if (roleRes.recordset.length === 0) {
        return result({ kind: "not_found" }, null);
      }

      const passwordMatches = bcrypt.compareSync(
        userdata.apassword,
        res.recordset[0].Password
      );

      console.log(userdata.apassword);
      console.log(res.recordset[0].Password);
      console.log(passwordMatches);

      if (!passwordMatches) {
        console.log("Email and password does not match");
        return result({ kind: "not_found" }, null);
      }

      console.log("success");

      const userObj = {
        ID: res.recordset[0].ID,
        First_Name: res.recordset[0].First_Name,
        Last_Name: res.recordset[0].Last_Name,
        Email: res.recordset[0].Email,
        Logo: res.recordset[0].Logo,
        Insurance_Company_ID: res.recordset[0].Insurance_Company_ID,
        rols: roleRes.recordset,
      };

      console.log("user", userObj);

      const studentObject = {
        user: userObj,
        token: JWT.issue(userObj),
      };

      return result(null, studentObject);
    });
  });
};



// check user type
User.checkAdminUser = (userdata, result) => {
  console.log("Inside checkAdminUser in Function.", userdata);

  if (userdata.email.includes(`'`)) {
    userdata.email = userdata.email.replaceAll("'", "''");
  }

  let selectQuery = `SELECT * FROM Users WHERE Email ='${userdata.email}' AND Password IS NOT NULL AND Is_Active = '1'`
  sql.query(selectQuery, (err, res) => {
    if (err) {
      console.log("error:", err);
      return result(err, null);
    }

    console.log(res, "response.....");

    if (res.recordset.length === 0) {
      console.log("Email does not exist");
      return result({ kind: "not_found" }, null);
    }

    console.log("success");
    return result(null, {});
  });

};

User.findById = (customerId, result) => {
  sql.query(`SELECT * FROM Users WHERE ID = ${customerId}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }

    if (res.length) {
      console.log("found user: ", res[0]);
      result(null, res[0]);
      return;
    }

    // not found User with the id
    result({
      kind: "not_found"
    }, null);
  });
};

User.getAll = result => {
  sql.query("SELECT * FROM Users", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log("user: ", res);
    result(null, res);
  });
};

User.updateById = (id, user, result) => {
  sql.query(
    "UPDATE Users SET email = ?, name = ?, active = ? WHERE id = ?",
    [user.email, user.name, user.active, id],
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        result(null, err);
        return;
      }

      if (res.affectedRows === 0) {
        // not found User with the id
        result({
          kind: "not_found"
        }, null);
        return;
      }

      console.log("updated user: ", {
        id: id,
        ...user
      });
      result(null, {
        id: id,
        ...user
      });
    }
  );
};

User.remove = (id, result) => {
  sql.query("DELETE FROM Users WHERE id = ?", id, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    if (res.affectedRows === 0) {
      // not found User with the id
      result({
        kind: "not_found"
      }, null);
      return;
    }

    console.log("deleted user with id: ", id);
    result(null, res);
  });
};

User.removeAll = result => {
  sql.query("DELETE FROM Users", (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(null, err);
      return;
    }

    console.log(`deleted ${res.affectedRows} user`);
    result(null, res);
  });
};



module.exports = User;