const sql = require('../db.js');
const config = require('../config.js')
const child_process = require('node:child_process');
const process = require('node:process')
const fs = require('node:fs')
const path = require('node:path');
const {
    DateTime
} = require('mssql');
const shBeginLine = "#!/bin/sh";




// // constructor
const DmaFile = function (dmaFile) {
    this.userid = dmaFile.userid;
    this.fileurl = dmaFile.fileurl;
    this.filetypeId = dmaFile.filetypeId;
    this.year = dmaFile.year;
    this.month = dmaFile.month;
    this.fileName = dmaFile.fileName;
    this.isUploaded = dmaFile.isUploaded;
    this.execFile = dmaFile.execFile;
    this.tableName = dmaFile.tableName;
    this.folderPath = dmaFile.folderPath;
};

DmaFile.runProcess = (processData, result) => {

  

    try {
        //Run the import Batch prepared earlier during import
        processFiles(processData);
    } catch (err) {
        result(err, null);
        return;
    }
};

 const processFiles = function (processData) {
    let oSys = process.platform;



    let processCommand = GetProcessorQuery(processData);
    let execFileName = config.con.importExecS;
    let cleanUpCommand = processCommand + "\n\n" + "rm *";

    if (oSys === "win32") {
        execFileName = config.con.importExecB;
        cleanUpCommand = processCommand + "\n\n" + "del /q *.*";
    }

    const processPath = config.con.temp;

    let fullPath = path.join(__dirname, processPath, processData.userId, processData.year, processData.month);
    let fullExecFilePath = path.join(fullPath, execFileName).replaceAll("\\", "/");
;


    try {
        if (fs.existsSync(fullExecFilePath)) {

            if (oSys === "linux") {
               
                fs.chmodSync(fullExecFilePath, 0o755);
            };


            //add clean up code before running the batch file.
            fs.appendFile(fullExecFilePath, cleanUpCommand, err => {
                if (err) {
                    console.error(err)
                    return
                }
           

                const outFile = fs.openSync('./outFile.log', 'a');
                const errFile = fs.openSync('./errFile.log', 'a');

                //Now run the batch/shell file to import the data
                const ls = child_process.spawn(fullExecFilePath, [], {
                    detached: true,
                    stdio: ['ignore', outFile, errFile],
                    cwd: fullPath,
                    windowsHide: true
                });

                ls.unref();

                //ls.stdout.on('data', (data) => {
                //    console.log(data);
                //});
                //ls.on('close', (code) => {

                //console.log("exit code :" + code," changing to base path after exec");
                //process.chdir(basePath) ;
                //});
                let fileData = {
                    isUploaded: "imported",
                    userid: processData.userId,
                    month: processData.month,
                    year: processData.year
                };

                DmaFile.updateById(fileData);




            });

        } 
    } catch (err) {
        console.error("Failed to process files:", err);
        throw err;
    }

};

const GetProcessorQuery = function (data) {

    let process = "call All_SP_Processing('{{month}}','{{year}}',false)"
    let procStr = `mysql -u{{user}} -p{{password}} --database={{dbname}} -e "${process}"`
    let fullStr = replaceTextWithinFile(procStr, data);

    return fullStr;

}

DmaFile.ExecuteLeadProcessor = function (fileData, result) {

 
    sql.query("call All_SP_Processing(?,?,?)", [fileData.fileMonth, fileData.fileYear, false], function (err, res) {

        if (err) {
            console.log("error: ", err);
            result(err, null);
        } else {
            console.log("results:", res);
        }

    });

};

DmaFile.create = (hospitalObj, result) => {
   
    sql.query(`SELECT * FROM Uploaded_Files WHERE User_ID = ${hospitalObj.User_ID} AND File_Categories_ID = ${hospitalObj.File_Categories_ID} AND Year = ${hospitalObj.Year}`, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
    
        if (res.recordset.length > 0) {
       
            sql.query(`UPDATE Uploaded_Files SET User_ID ='${hospitalObj.User_ID}', Original_Name = '${hospitalObj.Original_Name}', File_Categories_ID ='${hospitalObj.File_Categories_ID}', Year = '${hospitalObj.Year}', File_Name ='${hospitalObj.File_Name}', Is_Uploaded ='${hospitalObj.Is_Uploaded}', File_URL ='${hospitalObj.File_URL}' WHERE  User_ID = ${hospitalObj.User_ID} AND File_Categories_ID = ${hospitalObj.File_Categories_ID} AND Year = ${hospitalObj.Year}`, (err, res) => {
                if (err) {
                    console.log("error: ", err);
                    result(err, null);
                    return;
                }
               
                result(null, res);
            });
        } else {
       
            sql.query(`INSERT INTO Uploaded_Files (User_ID, File_Categories_ID,Year,File_Name,Is_Uploaded,File_URL,Original_Name) VALUES (${hospitalObj.User_ID},${hospitalObj.File_Categories_ID},${hospitalObj.Year},'${hospitalObj.File_Name}','${hospitalObj.Is_Uploaded}','${hospitalObj.File_URL}','${hospitalObj.Original_Name}')`, (err, res) => {
                if (err) {
                    console.log("error: ", err);
                    result(err, null);
                    return;
                }
                result(null, res);
            });
        }
    });
    //Create the batch files required to import the data
    // if (fileData.execFile) {
    // DmaFile.createExecFile(hospitalObj);
    // }
    //-------
};

DmaFile.createExecFile = function (fileData, result) {
    let oSys = process.platform;
    let execFileName = config.con.importExecS;
    let importTemplate = "../../importTemplateL.txt";
    let beginLine = shBeginLine + "\n";
    if (oSys === "win32") {
        execFileName = config.con.importExecB;
        importTemplate = "../../importTemplateB.txt";
        beginLine = "@echo off" + "\n";
    }

    let templatePath = path.join(__dirname, importTemplate).replaceAll("\\", "/");
    let fullExecFilePath = path.join(__dirname, fileData.folderPath, execFileName).replaceAll("\\", "/");
    try {
        if (fs.existsSync(fullExecFilePath)) {
            fs.readFile(templatePath, 'utf8', (err, data) => {
                if (err) {
                    console.error(err)
                    return;
                }
             
             
                let content = replaceTextWithinFile(data, fileData);
                fs.appendFile(fullExecFilePath, content, err => {
                    if (err) {
                        console.error(err)
                    }
                
                })
            });
        } else {
            fs.readFile(templatePath, 'utf8', (err, data) => {
                if (err) {
                    console.error(err)
                    return;
                }
              
        
                let content = beginLine + replaceTextWithinFile(data, fileData);
                fs.writeFile(fullExecFilePath, content, err => {
                    if (err) {
                        console.error(err)
                    }
                
                })
            });
        }
    } catch (err) {
        console.error(err)
    } 
};

 const replaceTextWithinFile = function (input, fileData, resultCallback) {
  const db_user = config.con.user;
  const db_password = config.con.password;
  const db_name = config.con.db;

  const replacements = new Map([
    ["{{user}}", db_user],
    ["{{password}}", db_password],
    ["{{dbname}}", db_name],
    ["{{filename}}", fileData.File_Name],
    ["{{tablename}}", fileData.File_Name],
    ["{{year}}", fileData.Year]
  ]);

  const output = input.replaceAll(/{{[^}]+}}/g, m => replacements.get(m) || m);

  return output;
};



DmaFile.insertleaddata = function (leaddata, result) {
  
    // sql.query("INSERT INTO saleaforce_pushed_data SET ?", leaddata, (err, res) => {
    let resquery = "INSERT INTO saleaforce_pushed_data (integreted_id,for_month,for_year,user_id) VALUES ?";
    sql.query(resquery, [leaddata], (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        result(null, res);
    });
}

DmaFile.getFileTypeList = (req, result) => {

    //sql.query(`SELECT id, filetype, tablename, Operation FROM filetype where id not in (SELECT filetypeId from dmafile where userid=? and month=? and year=?);`, [userId, month, year] ,(err, res) => {
    sql.query(`SELECT id, filetype, tablename, Operation FROM filetype;`, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }

        if (res.length > 0) {
         
            result(null, res);
        }

    });
};

DmaFile.findById = (fileJson, result) => {

    sql.query(`SELECT * FROM dmafile where userid=${fileJson.userId} and isSalesForce=1 and fileName='Salesforce Leads'`, (err, res) => {
        // sql.query(`SELECT * FROM dmafile where userId=${fileJson.userId}`, (err, res) => {
        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }

        if (res.length > 0) {
           
            result(null, res);
        }
    });
};

DmaFile.findDmaListById = (fileJson, result) => {
       // sql.query(`select ft.filetype, fileName, UploadedOn, IsUploaded as Status from dmafile dm inner join filetype ft on dm.filetypeId = ft.id where userid=${fileJson.userId} and month='${fileJson.fileMonth}' and year='${fileJson.fileYear}' order by uploadedOn desc`, (err, res) => {
    sql.query(`select FC.Categories as Categories, Original_Name, Uploaded_On, Is_Uploaded as Status from Uploaded_Files UP inner join File_Categories FC on UP.File_Categories_ID = FC.ID where User_ID=${fileJson.user_id} and Year='${fileJson.year}' order by Uploaded_On desc`, (err, res) => {

        if (err) {
            console.log("error: ", err);
            result(err, null);
            return;
        }
        if (res.recordset.length > 0) {
        
            result(null, res.recordset);
        } else {
         
            // not found User with the id
            result({
                kind: "not_found"
            }, null);
        }
    });
};

DmaFile.updateById = (fileData, result) => {
    sql.query(
        "UPDATE dmafile SET isUploaded = ? WHERE userid = ? AND month = ? AND year = ? ",
        [fileData.isUploaded, fileData.userid, fileData.month, fileData.year],
        (err, res) => {
            if (err) {
                console.log("error: ", err);
                result(null, err);
                return;
            }

            if (res.affectedRows === 0) {
                // not found User with the id
                result({
                    kind: "not_found"
                }, null);
            }

        }
    );
};

DmaFile.updateleadsById = (fileData, result) => {
    sql.query(
        "UPDATE saleaforce_pushed_data SET status = ? WHERE user_id = ? AND for_month = ? AND for_year = ? ",
        [fileData.status, fileData.user_id, fileData.for_month, fileData.for_year],
        (err, res) => {
            if (err) {
                console.log("error: ", err);
                result(null, err);
                return;
            }

            if (res.affectedRows === 0) {
                // not found User with the id
                result({
                    kind: "not_found"
                }, null);
            }

        }
    );
};
module.exports = DmaFile;