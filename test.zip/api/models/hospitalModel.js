const sql = require("../db.js");
let bcrypt = require("bcryptjs");
let salt = bcrypt.genSaltSync(7);
let JWT = require("../fn/JWT");
let fs = require("node:fs");
const XLSX = require('xlsx')
const dbConfig = require("../config");




const CSVtoJSON = require("csvtojson");
const JSONtoCSV = require("json2csv").parse;
const moment = require("moment");

const { Engine } = require("json-rules-engine");
const employeesalary = require("../Sample.json");

const { BlobServiceClient } = require("@azure/storage-blob");
const { hospitalPagination } = require("../controllers/hospitalController.js");

// Get All Hospital
exports.getAllHospital = function (hospitalObj, callBack) {
  sql.query(`SELECT Facility_List.ID,Facility_Name,Facility_ID,Hospital_Group_ID,Facility_List.Insurance_Company_ID,Hospital_Group.Group_Name FROM Facility_List left join Hospital_Group on Hospital_Group.ID = Facility_List.Hospital_Group_ID`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get payoutHospital
exports.payoutHospital = function (hospitalObj, callBack) {
  sql.query(`SELECT fl.ID,fl.Facility_Name, fl.Facility_ID,fl.Hospital_Group_ID,fl.Insurance_Company_ID,hg.Group_Name from Facility_List fl INNER JOIN Hospital_Group hg ON hg.ID = fl.Hospital_Group_ID WHERE fl.ID IN (SELECT DISTINCT(Facility_List_ID) FROM Facilty_Measure_Mapping WHERE Year = '${hospitalObj.year}' AND fl.Is_Active = 'true')`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get patoutMeasureGroupList
exports.patoutMeasureGroupList = function (hospitalObj, callBack) {
  sql.query(`SELECT mgl.ID, mgl.Measure_Group_Name, mgl.Is_Manual FROM Measure_Group_List mgl WHERE mgl.ID IN (SELECT DISTINCT(Measure_Group_List_ID) FROM Facilty_Measure_Mapping WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.hospital_id}' AND mgl.Is_Active = 'true')`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get scaleMeasureGroupList
exports.scaleMeasureGroupList = function (hospitalObj, callBack) {
  sql.query(`SELECT mgl.ID, mgl.Measure_Group_Name, mgl.Is_Manual FROM Measure_Group_List mgl WHERE mgl.ID IN (SELECT DISTINCT(Measure_Group_List_ID) FROM Facilty_Measure_Mapping WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '9' AND mgl.Is_Active = 'true')`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Scale Range Measure Group Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get getScaleRangeDetails
exports.getScaleRangeDetails = function (hospitalObj, callBack) {
  sql.query(`select Score, Payout from Scale_Range where year = '${hospitalObj.year}' and Measure_Group_List_ID = '${hospitalObj.measure_group_id}' and  Measure_ID_List_ID = '${hospitalObj.measure_ID}'`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Scale Range Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get getCriteria
exports.getCriteria = function (hospitalObj, callBack) {

  sql.query(`SELECT Criteria, Measure_IDs, Payout_Category ,Grouping FROM Payout_Criteria WHERE Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.hospital_id}' ORDER BY ID`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

// Group Syatem Pagination
exports.getGroupSystemPagination = function (reqObject, callBack) {
  let length = reqObject.length; //lenght
  let start = reqObject.start;
  let column = reqObject.order[0].column;
  if (reqObject.order[0].column === 0) {
    column = 1;
  }
  let dir = reqObject.order[0].dir;
  let filterquery = "";
  let sqlquery = `SELECT count(*) as numRows FROM  Hospital_Group`;
  if (filterquery !== "") {
    sqlquery = sqlquery + filterquery;
  }
  sql.query(sqlquery, function (err, rows, fields) {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    } else {

      let numRows = rows.recordset[0].numRows;
      let disquery = `SELECT * FROM  Hospital_Group`;
      if (filterquery !== "") {
        disquery = disquery + filterquery;
      }
      sql.query(
        disquery +
        `  ORDER BY ${column} ${dir}  OFFSET ${start} ROWS FETCH NEXT ${length} ROWS ONLY`,
        function (err, rows, fields) {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! Internal Server Error.",
            },
              null
            );
          } else {
            let data = {
              data: rows.recordsets,
              draw: reqObject.draw,
              recordsFiltered: numRows,
              recordsTotal: numRows,
            };

            return callBack(null, {
              status: 200,
              data: data,
            });
          }
        }
      );
    }
  });
};

// Measure Group Syatem Pagination
exports.getMeasureGroupPagination = function (reqObject, callBack) {

  let length = reqObject.length; //lenght
  let start = reqObject.start;
  let column = reqObject.order[0].column;
  if (reqObject.order[0].column === 0) {
    column = 1;
  }
  let dir = reqObject.order[0].dir;
  let filterquery = "";
  let sqlquery = `SELECT count(*) as numRows FROM  Measure_Group_List`;
  if (filterquery !== "") {
    sqlquery = sqlquery + filterquery;
  }
  sql.query(sqlquery, function (err, rows, fields) {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    } else {

      let numRows = rows.recordset[0].numRows;
      let disquery = `SELECT * FROM  Measure_Group_List`;
      if (filterquery !== "") {
        disquery = disquery + filterquery;
      }
      sql.query(
        disquery +
        `  ORDER BY ${column} ${dir}  OFFSET ${start} ROWS FETCH NEXT ${length} ROWS ONLY`,
        function (err, rows, fields) {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! Internal Server Error.",
            },
              null
            );
          } else {
            let data = {
              data: rows.recordsets,
              draw: reqObject.draw,
              recordsFiltered: numRows,
              recordsTotal: numRows,
            };

            return callBack(null, {
              status: 200,
              data: data,
            });
          }
        }
      );
    }
  });
};

//  hospital Pagination
exports.hospitalPagination = function (reqObject, callBack) {

  let length = reqObject.length; //lenght
  let start = reqObject.start;
  let column = reqObject.order[0].column;
  if (reqObject.order[0].column === 0) {
    column = 1;
  }
  let dir = reqObject.order[0].dir;
  let filterquery = "";
  let sqlquery = `SELECT count(*) as numRows FROM  Facility_List`;
  if (filterquery !== "") {
    sqlquery = sqlquery + filterquery;
  }
  sql.query(sqlquery, function (err, rows, fields) {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    } else {
      let numRows = rows.recordset[0].numRows;
      let disquery = `SELECT Facility_List.ID as Facility_List_ID, Facility_List.Facility_ID , Facility_List.Facility_Name , Hospital_Group.Group_Name, Facility_List.Hospital_Group_ID, Facility_List.Is_Active   FROM Facility_List LEFT JOIN Hospital_Group ON Facility_List.Hospital_Group_ID = Hospital_Group.ID`;
      if (filterquery !== "") {
        disquery = disquery + filterquery;
      }
      sql.query(
        disquery +
        `  ORDER BY ${column} ${dir}  OFFSET ${start} ROWS FETCH NEXT ${length} ROWS ONLY`,
        function (err, rows, fields) {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! Internal Server Error.",
            },
              null
            );
          } else {
            let data = {
              data: rows.recordsets,
              draw: reqObject.draw,
              recordsFiltered: numRows,
              recordsTotal: numRows,
            };

            return callBack(null, {
              status: 200,
              data: data,
            });
          }
        }
      );
    }
  });
};

exports.userPagination = function (reqObject, callBack) {
  let length = reqObject.length; //lenght
  let start = reqObject.start;
  let column = reqObject.order[0].column;
  if (reqObject.order[0].column === 0) {
    column = 1;
  }
  let dir = reqObject.order[0].dir;
  let filterquery = "";
  let sqlquery = `SELECT count(*) as numRows FROM  Users WHERE Users.ID NOT IN ('${reqObject.dateObject.user}')`;
  if (filterquery !== "") {
    sqlquery = sqlquery + filterquery;
  }
  sql.query(sqlquery, function (err, rows, fields) {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    } else {

      let numRows = rows.recordset[0].numRows;
      let disquery = `SELECT Users.ID as User_ID,  Roles.ID as  Roles_ID, Roles.Role, Users.First_Name,Users.Last_Name, Users.Email, Users.Is_Active FROM Users LEFT JOIN Roles ON Users.Role_ID = Roles.ID`;
      if (filterquery !== "") {
        disquery = disquery + filterquery;
      }
      sql.query(
        disquery +
        `  ORDER BY ${column} ${dir}  OFFSET ${start} ROWS FETCH NEXT ${length} ROWS ONLY`,
        function (err, rows, fields) {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! Internal Server Error.",
            },
              null
            );
          } else {
            let data = {
              data: rows.recordsets,
              draw: reqObject.draw,
              recordsFiltered: numRows,
              recordsTotal: numRows,
            };

            return callBack(null, {
              status: 200,
              data: data,
            });
          }
        }
      );
    }
  });
};
// Measure ID Pagination
exports.getMeasureIDPagination = function (reqObject, callBack) {

  let length = reqObject.length; //lenght
  let start = reqObject.start;
  let column = reqObject.order[0].column;
  if (reqObject.order[0].column === 0) {
    column = 1;
  }
  let dir = reqObject.order[0].dir;
  let filterquery = "";
  let sqlquery = `SELECT count(*) as numRows FROM  Measure_ID_List`;
  if (filterquery !== "") {
    sqlquery = sqlquery + filterquery;
  }
  sql.query(sqlquery, function (err, rows, fields) {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    } else {

      let numRows = rows.recordset[0].numRows;
      let disquery = `SELECT Measure_ID_List.ID as Measure_ID_List_ID, Measure_Group_List.Measure_Group_Name , Measure_ID_List.Measure_ID_Name , Measure_ID_List.Measure_ID ,Measure_ID_List.Measure_Group_List_ID ,Measure_ID_List.Is_Active  FROM Measure_ID_List LEFT JOIN Measure_Group_List ON Measure_ID_List.Measure_Group_List_ID = Measure_Group_List.ID`;
      if (filterquery !== "") {
        disquery = disquery + filterquery;
      }
      sql.query(
        disquery +
        `  ORDER BY ${column} ${dir}  OFFSET ${start} ROWS FETCH NEXT ${length} ROWS ONLY`,
        function (err, rows, fields) {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! Internal Server Error.",
            },
              null
            );
          } else {
            let data = {
              data: rows.recordsets,
              draw: reqObject.draw,
              recordsFiltered: numRows,
              recordsTotal: numRows,
            };

            return callBack(null, {
              status: 200,
              data: data,
            });
          }
        }
      );
    }
  });
};
// Get All InsuranceCompany
exports.getAllInsuranceCompany = function (hospitalObj, callBack) {
  sql.query("SELECT * FROM Insurance_Company", (err, hospitalResult) => {
    if (err) {
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    }
    if (hospitalResult.recordset) {
      return callBack(null, {
        status: 200,
        data: hospitalResult.recordset,
      });
    } else {
      return callBack({
        status: 404,
        message: "Error! Hospital Not Found.",
      },
        null
      );
    }
  });
};

exports.getMearureIDs = function (hospitalObj, callBack) {
  sql.query(
    ` SELECT  L.Measure_ID_Name,L.ID, L.Measure_ID FROM Facilty_Measure_Mapping M left join Measure_ID_List L on L.ID =M.Measure_ID_List_ID WHERE M.Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND M.Year = '${hospitalObj.year}' AND M.Facility_List_ID = '${hospitalObj.hospital_id}'`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

exports.getNationalPercentileMeasureIDs = function (hospitalObj, callBack) {

  sql.query(
    `SELECT DISTINCT N.Measure_ID_List_ID, Measure_ID_List.Measure_ID_Name FROM National_Percentile_Mapping N left join Measure_ID_List on Measure_ID_List.ID = N.Measure_ID_List_ID WHERE N.Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND N.Year = '${hospitalObj.year}' AND N.Applicable = 1;`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

exports.getNationalPercentileMeasureGroup = function (hospitalObj, callBack) {

  sql.query(
    `SELECT DISTINCT N.Measure_Group_List_ID, Measure_Group_List.Measure_Group_Name FROM National_Percentile_Mapping N left join Measure_Group_List on Measure_Group_List.ID = N.Measure_Group_List_ID WHERE N.Year = '${hospitalObj.year}' AND N.Applicable = 1;`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

exports.getBothScore = function (hospitalObj, callBack) {

  sql.query(
    `SELECT DISTINCT System_Performance_Score, System_Target_Score FROM ${hospitalObj.table_name}  WHERE Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND Year = '${hospitalObj.year}'  AND Measure_ID_List_ID = '${hospitalObj.measure_ID}'`,
    (err, hospitalResult) => {
      if (err) {
        console.log("err  .", err);
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }

      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

// Delete Batch
exports.deleteBatch = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM Results Where Batch_Name = '${hospitalObj.batchName}'`,
    (err, hospitalResult) => {
      if (err) {
        console.log("err  .", err);
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }

      if (hospitalResult.recordset.length > 0) {
        //==== 
        // return callBack(null, {
        //   status: 200,
        //   data: "Batch Deleted Successfully!",
        // });

        sql.query(
          `DELETE FROM Results WHERE Batch_Name = '${hospitalObj.batchName}'`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return callBack({
                status: 500,
                message: "Error! Internal Server Error.",
              },
                null
              );
            }
            return callBack(null, {
              status: 200,
              data: "Batch Deleted Successfully!",
            });
          }
        );
        //===
      } else {
        return callBack({
          status: 404,
          message: "Error! Batch Not Found.",
        },
          null
        );
      }
    }
  );
};


exports.getTableName = function (hospitalObj, callBack) {
  sql.query(
    `SELECT * FROM LifeSpan_Mapping`,
    (err, hospitalResult) => {
      if (err) {
        console.log("err  .", err);
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

exports.getMearureAllocation = function (hospitalObj, callBack) {
  sql.query(
    `SELECT Measure_Group_Allocation_Percentage, Measure_Group_List_ID FROM Facilty_Measure_Mapping WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.hospital_id}' AND Measure_Group_List_ID = '${hospitalObj.measure_group_id}' GROUP BY Measure_Group_List_ID, Measure_Group_Allocation_Percentage`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};
// Create Measure ID List
exports.createMeasureIDList = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM Measure_ID_List WHERE Measure_ID_Name = '${hospitalObj.Measure_ID_Name}'`,
    (err, res) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (res.recordset.length > 0) {
        return callBack({
          status: 409,
          message: "Error! Hospital Measure Group Already Exist.",
        },
          null
        );
      }
      sql.query(
        `INSERT INTO Measure_ID_List (Measure_ID_Name,Measure_Description,Measure_Group_List_ID,Measure_ID, Insurance_Company_ID) VALUES
    ('${hospitalObj.Measure_ID_Name}','${hospitalObj.Measure_Description}','${hospitalObj.Measure_Group_List_ID}',
    '${hospitalObj.Measure_ID}',  '${hospitalObj.Insurance_Company_ID}')`,
        (err, res) => {
          if (err) {
            return callBack({
              status: 500,
              message: "Error! MSSQL Internal Server Error.",
            },
              null
            );
          }
          return callBack(null, {
            status: 201,
            message: "Success! Hospital Measure Group Created Successfully.",
          });
        }
      );
    }
  );
};

// Get Hospital By ID
exports.getHospitalById = function (hospitalObj, callBack) {
  sql.query(
    `select Facility_List.ID, Facility_Name,Facility_ID,Is_Active,Hospital_Group_ID,Hospital_Group.Group_Name,Facility_List.Insurance_Company_ID,Insurance_Company.Insurance_Company_Name  from Facility_List
left join Insurance_Company on Insurance_Company.ID =Facility_List.Insurance_Company_ID
left join Hospital_Group on Hospital_Group.ID =Facility_List.Hospital_Group_ID where Facility_List.ID = ${hospitalObj.ID}`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get Report List
exports.getReportList = function (hospitalObj, callBack) {
  sql.query(
    `SELECT * FROM HAI_Hospital where ID = ${hospitalObj.ID}`,
    (err, reportListResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (reportListResult) {
        return callBack(null, {
          status: 200,
          data: reportListResult,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get Measure Group List
exports.getMeasureGroupList = function (hospitalObj, callBack) {
  sql.query(
    `SELECT * FROM Measure_Group_List WHERE Is_Active ='1'`,
    (err, measureGroupListResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (measureGroupListResult) {
        return callBack(null, {
          status: 200,
          data: measureGroupListResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! MeasureGroup List Not Found.",
        },
          null
        );
      }
    }
  );
};
// Get Measure Group List
exports.getMeasureIDList = function (hospitalObj, callBack) {
  sql.query(
    `SELECT M.Measure_Description, M.Measure_ID_Name,M.Measure_ID,M.Measure_Group_List_ID,Measure_Group_List.ID,Measure_Group_List.Measure_Group_Name
     FROM Measure_ID_List M
    left join Measure_Group_List on Measure_Group_List.ID =M.Measure_Group_List_ID`,
    (err, measureGroupListResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (measureGroupListResult) {
        return callBack(null, {
          status: 200,
          data: measureGroupListResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! MeasureGroup List Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get Hospital Group List
exports.getHospitalGroupList = function (hospitalObj, callBack) {

  sql.query(`SELECT * FROM Hospital_Group  WHERE Is_Active ='1'`, (err, HospitalGroupListResult) => {
    if (err) {
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    }
    if (HospitalGroupListResult) {
      return callBack(null, {
        status: 200,
        data: HospitalGroupListResult.recordset,
      });
    } else {
      return callBack({
        status: 404,
        message: "Error! Hospital Group List List Not Found.",
      },
        null
      );
    }
  });
};
exports.getRoleList = function (hospitalObj, callBack) {

  sql.query(`SELECT * FROM Roles`, (err, HospitalGroupListResult) => {
    if (err) {
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    }
    if (HospitalGroupListResult) {
      return callBack(null, {
        status: 200,
        data: HospitalGroupListResult.recordset,
      });
    } else {
      return callBack({
        status: 404,
        message: "Error! Role List Not Found.",
      },
        null
      );
    }
  });
};

// Get Files
exports.getFilesType = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM File_Categories order by File_Order`,
    (err, FileTypeResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (FileTypeResult) {
        return callBack(null, {
          status: 200,
          data: FileTypeResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! File Categories Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get Year
exports.getYear = function (hospitalObj, callBack) {
  sql.query(
    `SELECT DISTINCT Year FROM Facilty_Measure_Mapping;`,
    (err, yearResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (yearResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: yearResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Year Not Found.",
        },
          null
        );
      }
    }
  );
};
// Get Years
exports.getYears = function (hospitalObj, callBack) {
  sql.query(
    `SELECT DISTINCT Year FROM Years;`,
    (err, yearResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (yearResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: yearResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Year Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get getNationalPercentileYear
exports.getNationalPercentileYear = function (hospitalObj, callBack) {
  sql.query(
    `SELECT DISTINCT Year FROM National_Percentile_Mapping WHERE Applicable = 1;`,
    (err, yearResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (yearResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: yearResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Year Not Found.",
        },
          null
        );
      }
    }
  );
};

// Get Mapped ID list
exports.getMappedIDList = function (hospitalObj, callBack) {

  sql.query(
    `SELECT fmm.Measure_ID_List_ID FROM Measure_ID_List mil INNER JOIN Facilty_Measure_Mapping fmm ON mil.ID = fmm.Measure_ID_List_ID WHERE Facility_List_ID ='${hospitalObj.Facility_List_ID}' AND fmm.Measure_Group_List_ID = '${hospitalObj.Measure_Group_List_ID}' AND fmm.Insurance_Company_ID ='${hospitalObj.Insurance_Company_ID}' AND fmm.Year = '${hospitalObj.year}'`,
    (err, MappedResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (MappedResult) {
        return callBack(null, {
          status: 200,
          data: MappedResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! File Categories Not Found.",
        },
          null
        );
      }
    }
  );
};

async function ReadFile(filePath) {
  const result = await CSVtoJSON().fromFile(filePath);
  // creating the desired json output
  let data = [];
  for (const row of result) {
    const baseData = {
      "Facility ID": row["Facility ID"],
      "Facility Name": row["Facility Name"],
      Address: row["Address"],
      City: row["City"],
      State: row["State"],
      "ZIP Code": row["ZIP Code"],
      "County Name": row["County Name"],
      "Start Date": row["Start Date"],
      "End Date": row["End Date"],
      "READM-30-IPF Start Date": row["READM-30-IPF Start Date"],
      "READM-30-IPF End Date": row["READM-30-IPF End Date"],
      "Flu Season Start Date": row["Flu Season Start Date"],
      "Flu Season End Date": row["Flu Season End Date"],
      "MedCoPsy Measure Start Date": row["MedCoPsy Measure Start Date"],
      "MedCoPsy Measure End Date": row["MedCoPsy Measure End Date"],
    };

    Object.keys(row).forEach(key => {
      if (!baseData.hasOwnProperty(key)) {
        data.push({
          ...baseData,
          "Measure ID": key,
          Score: row[key]
        });
      }
    });
  }

  return data;
}
async function ReadFileNational(filePath) {

  const result = await CSVtoJSON().fromFile(filePath);
  // creating the desired json output

  let data = [];
  for (const row of result) {
    const baseData = {
      "Start Date": row["Start Date"],
      "End Date": row["End Date"],
      "FUH Measure Start Date": row["FUH Measure Start Date"],
      "FUH Measure End Date": row["FUH Measure End Date"],
      "READM-30-IPF Start Date": row["READM-30-IPF Start Date"],
      "READM-30-IPF End Date": row["READM-30-IPF End Date"],
      "Flu Season Start Date": row["Flu Season Start Date"],
      "Flu Season End Date": row["Flu Season End Date"],
    };

    Object.keys(row).forEach(key => {
      // Skip static fields — only process dynamic measure keys
      if (key in baseData) {
        return;
      }

      data.push({
        ...baseData,
        "Measure ID": escapeNExp(key),
        Score: row[key]
      });
    });
  }

  return data;
}

// code for converting xlsx format into csv
async function ExcelToCsv(filePath, updatedFilePath) {
  return await new Promise(resolve => {
    resolve(XLSX.writeFile(XLSX.readFile(filePath), updatedFilePath, {
      bookType: "csv"
    }));

  })
}
//removing leading N from measure id
function escapeNExp(string) {
  if (string.charAt(0) === 'N' && string.charAt(1) === ' ') {
    return string.substring(2)
  } else {
    return string
  }
}

// Hospital Data Upload
exports.hospitalUpload = function (hospitalObj, callBack) {

  let table_name = hospitalObj.Table_Name.replace(/(\r\n|\n|\r)/gm, "");

  let fileExtension = hospitalObj.fileName.split('.').pop()
  //local code

  //define excel path based on file extension
  let excelFilePath = `/apps/hqm-be/hqmbe/api/temp/${hospitalObj.user_id}/${hospitalObj.year}/${table_name}/${table_name}_${hospitalObj.year}.xlsx`;
  if (fileExtension === 'xls') {
    excelFilePath = `/apps/hqm-be/hqmbe/api/temp/${hospitalObj.user_id}/${hospitalObj.year}/${table_name}/${table_name}_${hospitalObj.year}.xls`;
  }

  let filePath = `/apps/hqm-be/hqmbe/api/temp/${hospitalObj.user_id}/${hospitalObj.year}/${table_name}/${table_name}_${hospitalObj.year}.csv`;
  let updatedFilePath = `/apps/hqm-be/hqmbe/api/temp/${hospitalObj.user_id}/${hospitalObj.year}/${table_name}/${table_name}_${hospitalObj.year}.csv`;


  // checking if file is xlsx or xls and converting into csv
  if (fileExtension === 'xlsx' || fileExtension === 'xls') {
    try {

      ExcelToCsv(excelFilePath, updatedFilePath)

    } catch (err) {

      console.log(err)
    }
  }
  if (hospitalObj.Measure_Group_Name === "IPFQR_QualityMeasures_Facility") {
    ReadFile(filePath)
      .then((Result) => {

        const newData = Result.filter(
          (row) =>
            row["Measure ID"] !== "Facility ID" &&
            row["Measure ID"] !== "Facility Name" &&
            row["Measure ID"] !== "Address" &&
            row["Measure ID"] !== "City" &&
            row["Measure ID"] !== "State" &&
            row["Measure ID"] !== "ZIP Code" &&
            row["Measure ID"] !== "County Name" &&
            row["Measure ID"] !== "Start Date" &&
            row["Measure ID"] !== "End Date" &&
            row["Measure ID"] !== "READM-30-IPF Start Date" &&
            row["Measure ID"] !== "READM-30-IPF End Date" &&
            row["Measure ID"] !== "Flu Season Start Date" &&
            row["Measure ID"] !== "Flu Season End Date" &&
            row["Measure ID"] !== "MedCoPsy Measure Start Date" &&
            row["Measure ID"] !== "MedCoPsy Measure End Date"
        );
        const csv = JSONtoCSV(newData);
        fs.writeFileSync(updatedFilePath, csv);
        insertStorage();
      })
      .catch((err) => {

        return callBack({
          status: 500,
          message: "Error! File Reading Function Internal Server Error.",
        },
          null
        );
      });
  } else if (
    hospitalObj.Measure_Group_Name === "IPFQR_QualityMeasures_National"
  ) {
    ReadFileNational(filePath)
      .then((Result) => {

        const newData = Result.filter(
          (row) =>
            row["Measure ID"] !== "Start Date" &&
            row["Measure ID"] !== "End Date" &&
            row["Measure ID"] !== "FUH Measure Start Date" &&
            row["Measure ID"] !== "FUH Measure End Date" &&
            row["Measure ID"] !== "READM-30-IPF Start Date" &&
            row["Measure ID"] !== "READM-30-IPF End Date" &&
            row["Measure ID"] !== "Flu Season Start Date" &&
            row["Measure ID"] !== "Flu Season End Date"
        );
        const csv = JSONtoCSV(newData);
        fs.writeFileSync(updatedFilePath, csv);
        insertStorage();

      })
      .catch((err) => {

        return callBack({
          status: 500,
          message: "Error! File Reading Function Internal Server Error.",
        },
          null
        );
      });
  } else {
    insertStorage();
  }
  //

  function insertStorage() {
  

    // BlockBlobClient.uploadFile()
    return callBack(null, {
      status: 200,
      data: "File Uploaded Successfully",
    });
  }
};


// Hospital Data Upload
exports.hospitalLifeSpanUpload = function (hospitalObj, callBack) {


  let fileExtension = hospitalObj.fileName.split('.').pop()
  //local code

  let excelFilePath = `/apps/hqm-be/hqmbe/api/temp/${hospitalObj.user_id}/${hospitalObj.year}/LifeSpan/LifeSpan_${hospitalObj.measure_group_id}_${hospitalObj.measure_ID}_${hospitalObj.year}.xlsx`;
  if (fileExtension === 'xls') {
    excelFilePath = `/apps/hqm-be/hqmbe/api/temp/${hospitalObj.user_id}/${hospitalObj.year}/LifeSpan/LifeSpan_${hospitalObj.measure_group_id}_${hospitalObj.measure_ID}_${hospitalObj.year}.xls`;
  }

  let updatedFilePath = `/apps/hqm-be/hqmbe/api/temp/${hospitalObj.user_id}/${hospitalObj.year}/LifeSpan/LifeSpan_${hospitalObj.measure_group_id}_${hospitalObj.measure_ID}_${hospitalObj.year}.csv`;

  if (fileExtension === 'xlsx' || fileExtension === 'xls') {
    try {

      ExcelToCsv(excelFilePath, updatedFilePath)

    } catch (err) {

      console.log(err)
    }
  }




  // BlockBlobClient.uploadFile()
  return callBack(null, {
    status: 200,
    data: "File Uploaded Successfully",
  });
};

// Mapping Update
exports.mappingUpdate = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM Facilty_Measure_Mapping WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.Facility_List_ID}' AND  Measure_Group_List_ID = '${hospitalObj.Measure_Group_List_ID}' AND  Insurance_Company_ID = '${hospitalObj.Insurance_Company_ID}'`,
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }

      if (res.recordset.length > 0) {
        sql.query(
          `DELETE FROM Facilty_Measure_Mapping WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.Facility_List_ID}' AND  Measure_Group_List_ID = '${hospitalObj.Measure_Group_List_ID}' AND  Insurance_Company_ID = '${hospitalObj.Insurance_Company_ID}'`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return callBack({
                status: 500,
                message: "Error! Internal Server Error.",
              },
                null
              );
            }
            insertMapping(hospitalObj);
          }
        );
      } else {
        insertMapping(hospitalObj);
      }
    }
  );

  function insertMapping(hospitalObj) {

    let requests = hospitalObj.checkedIds.map((id) => {
      return new Promise((resolve, reject) => {
        let request = new sql.Request();
        request.query(
          `INSERT INTO Facilty_Measure_Mapping (Year, Facility_List_ID,Measure_Group_List_ID, Measure_ID_List_ID,Insurance_Company_ID) VALUES ('${hospitalObj.year}','${hospitalObj.Facility_List_ID}','${hospitalObj.Measure_Group_List_ID}','${id.Measure_ID_List_ID}','${hospitalObj.Insurance_Company_ID}')`,
          (err, result) => {
            if (err) {

              reject(err);
            } else {
              resolve(result);
            }
          }
        );
      });
    });
    Promise.all(requests)
      .then((body) => {

        return callBack(null, {
          status: 200,
          message: "Success! Updated Successfully.",
        });
      })
      .catch((err) => {

        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      });
  }
};

// Create Hspital Group
exports.createHospitalGroup = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM Hospital_Group WHERE Group_Name = '${hospitalObj.Group_Name}'`,
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }

      if (res.recordset.length > 0) {
        return callBack({
          status: 409,
          message: "Error! Hospital Group Already Exist.",
        },
          null
        );
      }
      sql.query(
        `INSERT INTO Hospital_Group (Group_ID, Group_Name,Insurance_Company_ID) VALUES ('${hospitalObj.Group_ID}','${hospitalObj.Group_Name}','${hospitalObj.Insurance_Company_ID}')`,
        (err, res) => {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! MSSQL Internal Server Error.",
            },
              null
            );
          }
          return callBack(null, {
            status: 201,
            message: "Success! Hospital Group Created Successfully.",
          });
        }
      );
    }
  );
};

// Create Hspital Measure Group
exports.createHospitalMeasureGroup = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM Measure_Group_List WHERE Measure_Group_Name = '${hospitalObj.Measure_Group_Name}'`,
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }

      if (res.recordset.length > 0) {
        return callBack({
          status: 409,
          message: "Error! Hospital Measure Group Already Exist.",
        },
          null
        );
      }
      sql.query(
        `INSERT INTO Measure_Group_List (Measure_Group_Name,Insurance_Company_ID) VALUES ('${hospitalObj.Measure_Group_Name}','${hospitalObj.Insurance_Company_ID}')`,
        (err, res) => {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! MSSQL Internal Server Error.",
            },
              null
            );
          }
          return callBack(null, {
            status: 201,
            message: "Success! Hospital Measure Group Created Successfully.",
          });
        }
      );
    }
  );
};

// Create Hospital
exports.createHospital = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM Facility_List WHERE Facility_Name = '${hospitalObj.Facility_Name}'`,
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }

      if (res.recordset.length > 0) {
        return callBack({
          status: 409,
          message: "Error! Hospital Already Exist.",
        },
          null
        );
      }
      sql.query(
        `INSERT INTO Facility_List (Facility_Name, Facility_ID, Hospital_Group_ID,Insurance_Company_ID) VALUES
     ('${hospitalObj.Facility_Name}','${hospitalObj.Facility_ID}','${hospitalObj.Hospital_Group_ID}',
     ${hospitalObj.Insurance_Company_ID})`,
        (err, res) => {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! MSSQL Internal Server Error.",
            },
              null
            );
          }
          return callBack(null, {
            status: 201,
            message: "Success! Hospital Created Successfully.",
          });
        }
      );
    }
  );
};

// Delete Hospital
exports.deleteHospital = function (hospitalObj, callBack) {

  let query = `UPDATE Facility_List SET Is_Active ='${hospitalObj.Is_Active}' WHERE ID = ${hospitalObj.ID}`;

  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! Hospital Deleted Successfully.",
    });
  });
};

// Delete User
exports.deleteUser = function (userObj, callBack) {

  let query = `UPDATE Users SET Is_Active ='${userObj.Is_Active}' WHERE ID = ${userObj.ID}`;

  sql.query(query, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! User Deleted Successfully.",
    });
  });
};


// Update Hospital
exports.updateHospital = function (hospitalObj, callBack) {

  let updateQuery = `UPDATE Facility_List SET Facility_Name= '${hospitalObj.Facility_Name}',Facility_ID ='${hospitalObj.Facility_ID}', Hospital_Group_ID = '${hospitalObj.Hospital_Group_ID}',
  Insurance_Company_ID='${hospitalObj.Insurance_Company_ID}' WHERE ID = '${hospitalObj.ID}'`;
  sql.query(updateQuery, (err, res) => {
    if (err) {
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! Hospital Updated Successfully.",
    });
  });
};


// Update User
exports.updateUser = function (userObj, callBack) {

  let updateQuery = `UPDATE Users SET First_Name = '${userObj.First_Name}',Last_Name ='${userObj.Last_Name}', Email = '${userObj.Email}' , Role_ID = '${userObj.Role_ID}' WHERE ID = '${userObj.ID}'`;

  sql.query(updateQuery, (err, res) => {
    if (err) {
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! User Updated Successfully.",
    });
  });
};


// Delete updateGroupSystem
exports.deleteGroupSystem = function (hospitalObj, callBack) {

  let updateQuery = `UPDATE Hospital_Group SET Is_Active ='${hospitalObj.Is_Active}' WHERE ID  ='${hospitalObj.ID}'`;
  let updateQuery2 = `UPDATE Facility_List SET Is_Active = '${hospitalObj.Is_Active}' WHERE Hospital_Group_ID = '${hospitalObj.ID}' `;

  sql.query(updateQuery2, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
  });
  sql.query(updateQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! Group System Deleted Successfully.",
    });
  });
};

// Delete Measure Group
exports.deleteMeasureGroup = function (hospitalObj, callBack) {

  let updateQuery = `UPDATE Measure_Group_List SET Is_Active ='${hospitalObj.Is_Active}' WHERE ID  ='${hospitalObj.ID}'`;
  let updateQuery2 = `UPDATE Measure_ID_List SET Is_Active = '${hospitalObj.Is_Active}' WHERE Measure_Group_List_ID = '${hospitalObj.ID}' `;

  sql.query(updateQuery2, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
  });
  sql.query(updateQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! Measure Group Deleted Successfully.",
    });
  });
};

// Delete deleteMeasureID
exports.deleteMeasureID = function (hospitalObj, callBack) {

  let updateQuery = `UPDATE Measure_ID_List SET Is_Active ='${hospitalObj.Is_Active}' WHERE ID  ='${hospitalObj.ID}'`;

  sql.query(updateQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! Measure ID Deleted Successfully.",
    });
  });
};

// Update updateGroupSystem
exports.updateGroupSystem = function (hospitalObj, callBack) {

  let updateQuery = `UPDATE Hospital_Group SET Group_Name = '${hospitalObj.Group_Name}',Group_ID ='${hospitalObj.Group_ID}' WHERE ID  ='${hospitalObj.ID}' `;

  sql.query(updateQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! Group System Updated Successfully.",
    });
  });
};

// Update updateMeasureGroup.
exports.updateMeasureGroup = function (hospitalObj, callBack) {

  let updateQuery = `UPDATE Measure_Group_List SET Measure_Group_Name = '${hospitalObj.Measure_Group_Name}' WHERE ID  ='${hospitalObj.ID} '`;

  sql.query(updateQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! Measure Group Updated Successfully.",
    });
  });
};

// Update updateMeasureID.
exports.updateMeasureID = function (hospitalObj, callBack) {

  let updateQuery = `UPDATE Measure_ID_List SET Measure_ID_Name = '${hospitalObj.Measure_ID_Name}', Measure_ID = '${hospitalObj.Measure_ID}' , Measure_Description = '${hospitalObj.Measure_Description}' , Measure_Group_List_ID = '${hospitalObj.Measure_Group_List_ID}' WHERE ID  ='${hospitalObj.ID}'`;

  sql.query(updateQuery, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! MSSQL Internal Server Error.",
      },
        null
      );
    }
    return callBack(null, {
      status: 200,
      message: "Success! Measure ID Updated Successfully.",
    });
  });
};

//Mapping
exports.getMeasureGroupById = function (hospitalObj, callBack) {
  sql.query(
    `select * from Measure_ID_List WHERE Measure_Group_List_ID = '${hospitalObj.Measure_Group_List_ID}' `,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

// Update Facilty Measure Id Mapping
exports.faciltymeasureidmapping = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM Facility_List WHERE Facility_Name = '${hospitalObj.Measure_Group_Name}'`,
    (err, res) => {
      if (err) {
        console.log("error: ", err);
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (res.recordset.length > 0) {
        return callBack({
          status: 409,
          message: "Error! Hospital Already Exist.",
        },
          null
        );
      }
      sql.query(
        `INSERT INTO Facility_List (Facility_Name, Facility_ID, Hospital_Group_ID) VALUES ('${hospitalObj.Facility_Name}','${hospitalObj.Facility_ID}','${hospitalObj.Hospital_Group_ID}')`,
        (err, res) => {
          if (err) {
            console.log("error: ", err);
            return callBack({
              status: 500,
              message: "Error! MSSQL Internal Server Error.",
            },
              null
            );
          }
          return callBack(null, {
            status: 201,
            message: "Success! Hospital Created Successfully.",
          });
        }
      );
    }
  );
};
// Create Mapping
exports.createMapping = function (hospitalObj, callBack) {
  sql.query(`SELECT * FROM Users`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    }

    let Insurance_Company_ID = res.recordset[0].Insurance_Company_ID;

    sql.query(
      `INSERT INTO Facility_Measure_Group_Mapping (Year,Facility_List_ID,Measure_Group_List_ID,Allocation_Percentage,Insurance_Company_ID) VALUES
     ('${hospitalObj.Year}','${hospitalObj.Facility_List_ID}','${hospitalObj.Measure_Group_List_ID
      }','${""}','${Insurance_Company_ID}')`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
        }
      }
    );
  });

};

//res.hospital_params.Compared_to_National != undefined

// Calculate Payout
exports.calculatePayout = function (hospitalObj, callBack) {

  if (hospitalObj.Is_Manual) {
    function AddPayValuesForManual(res, pay, measure_contribution) {
      let measureGroup = res;
      async function insertResult(id, hospitalObj) {
        const request = new sql.Request();

        const query = `
    INSERT INTO Results(
      Facility_List_ID, 
      Measure_ID_List_ID,
      Allocation_Percentage,
      Year,
      Insurance_Company_ID, 
      Batch_Name, 
      User_ID, 
      Measure_Group_List_ID
    )
    SELECT 
      '${id.hospital_id}', 
      '${id.measure_id}',
      '${id.hospital_params.Measure_ID_Allocation_Percentage}', 
      '${id.year}',
      '${id.insurance_company_id}',
      '${hospitalObj.batchName}',
      '${hospitalObj.user_id}',
      '${hospitalObj.measure_group_id}'
  `;

        return request.query(query);
      }

      const requests = measureGroup.map((id) => insertResult(id, hospitalObj));
      Promise.all(requests)
        .then((body) => {
          return callBack(null, {
            status: 201,
            message: "Payout Calculated & Saved Successfully !",
          });
        })
        .catch((err) => {

          return callBack({
            status: 500,
            message: "Error!Internal Server Error.",
          },
            null
          );
        });
    }

    /// --

    const hqmObject2 = {
      hospital_id: hospitalObj.hospital_id,
      measure_group_id: hospitalObj.measure_group_id,
      insurance_company_id: hospitalObj.insurance_company_id,
      year: hospitalObj.year,
      batchName: hospitalObj.batchName,
      user_id: hospitalObj.user_id,
    };

    let isexist = false;
    checkIfBatchExist(hqmObject2)
      .then((batchResult) => {
        if (batchResult.length > 0) {
          if (
            batchResult[0].Batch_Name === hqmObject2.batchName &&
            batchResult[0].Facility_List_ID === hqmObject2.hospital_id + ""
          ) {
            isexist = true;
          } else {
            isexist = false;
            return callBack({
              status: 409,
              message: "Error! Batch Already Exist for the Hospital !",
            },
              null
            );
          }
        } else {
          isexist = true;
        }
        if (isexist) {
          checkIfMeasureContCalculated(hqmObject2)
            .then((countResult) => {
              if (countResult.length > 0) {
                return callBack({
                  status: 409,
                  message: "Error! Measure Contribution Already calculated.!",
                },
                  null
                );
              } else {
                getAllMeasureIds(
                  hqmObject2.hospital_id,
                  hqmObject2.measure_group_id,
                  hqmObject2.year,
                  hqmObject2.insurance_company_id
                )
                  .then((getAllMeasureIdsResult) => {
                    if (getAllMeasureIdsResult.length === 0) {
                      return callBack({
                        status: 404,
                        message: "Error! Please complete the Allocation Distribution process.",
                      },
                        null
                      );
                    }
                    getAllParams(
                      hqmObject2.hospital_id,
                      getAllMeasureIdsResult,
                      hqmObject2.year,
                      hqmObject2.insurance_company_id
                    );
                  })
                  .catch((err) => {

                    return callBack({
                      status: 500,
                      message: "Error! Get Params Function Internal Server Error.",
                    },
                      null
                    );
                  });
              }
            })
            .catch((err) => {

              return callBack({
                status: 500,
                message: "Error! Get Params Function Internal Server Error.",
              },
                null
              );
            });
        }
      })
      .catch((err) => {

        return callBack({
          status: 500,
          message: "Error! Get Params Function Internal Server Error.",
        },
          null
        );
      });



    // Get All MeasureIds
    function getAllMeasureIds(
      hospital_id,
      measure_group_id,
      year,
      insurance_company_id
    ) {
      return new Promise(function (resolve, reject) {
        // sql.query(`SELECT fmid.Measure_ID_List_ID, q.Get_All_Param_Query FROM [dbo].[Facilty_Measure_Mapping] fmid INNER JOIN [dbo].[Get_All_Params_Queries_Mapping] qm ON qm.Facility_List_ID = fmid.Facility_List_ID AND qm.Measure_Group_List_ID = fmid.Measure_Group_List_ID AND qm.Measure_ID_List_ID = fmid.Measure_ID_List_ID INNER JOIN [dbo].[Queries] q ON q.ID = qm.Queries_ID WHERE fmid.Facility_List_ID = '${hospital_id}' AND fmid.Measure_Group_List_ID = '${measure_group_id}' AND fmid.Year = '${year}' AND fmid.Insurance_Company_ID = '${insurance_company_id}' AND fmid.Measure_ID_Allocation_Percentage IS NOT NULL`, (err, res) => {
        sql.query(
          `SELECT fmid.Measure_ID_List_ID, q.Get_All_Param_Query FROM [dbo].[Facilty_Measure_Mapping] fmid INNER JOIN [dbo].[Get_All_Params_Queries_Mapping] qm ON qm.Facility_List_ID = fmid.Facility_List_ID AND qm.Measure_Group_List_ID = fmid.Measure_Group_List_ID AND qm.Measure_ID_List_ID = fmid.Measure_ID_List_ID AND qm.Year = fmid.Year INNER JOIN [dbo].[Queries] q ON q.ID = qm.Queries_ID WHERE fmid.Facility_List_ID = '${hospital_id}' AND fmid.Measure_Group_List_ID = '${measure_group_id}' AND fmid.Year = '${year}' AND fmid.Insurance_Company_ID = '${insurance_company_id}'`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return reject(err);
            }
            const vals = res.recordset;
            return resolve(vals);
          }
        );
      });
    }

    // check If batch exist
    function checkIfBatchExist(paramData) {
      return new Promise(function (resolve, reject) {
        sql.query(
          `SELECT Batch_Name, Facility_List_ID FROM Results WHERE Batch_Name ='${paramData.batchName}'  GROUP BY Batch_Name ,Facility_List_ID`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return reject(err);
            }
            const vals = res.recordset;
            return resolve(vals);
          }
        );
      });
    }

    // checkIfMeasureContCalculated
    function checkIfMeasureContCalculated(paramData) {
      return new Promise(function (resolve, reject) {
        sql.query(
          `select Batch_Name from Results WHERE Facility_List_ID = '${paramData.hospital_id}' AND Year = '${paramData.year}' AND Batch_Name = '${paramData.batchName}' AND Measure_Group_List_ID = '${paramData.measure_group_id}' AND Insurance_Company_ID = '${paramData.insurance_company_id}'`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return reject(err);
            }
            const vals = res.recordset;
            return resolve(vals);
          }
        );
      });
    }

    function getAllParams(hospital_id, mids, year, insurance_company_id) {
      let requests = mids.map((id) => {
        return new Promise((resolve, reject) => {
          let request = new sql.Request();


          let requestQuery = id.Get_All_Param_Query.replaceAll(
            '+hospital_id+',
            hospital_id
          )
            .replaceAll(/\+id.Measure_ID_List_ID\+/g, id.Measure_ID_List_ID)
            .replaceAll(/\+year\+/g, year);

          request.query(requestQuery, (err, result) => {
            if (err) {

              reject(err);
            } else {
              const resultSet = {
                data: result.recordset,
                measure_id: id.Measure_ID_List_ID,
              };
              resolve(resultSet);
            }
          });
        });
      });
      Promise.all(requests)
        .then((body) => {

          let measureGroupData = [];
          body.forEach((res) => {

            if (res)
              measureGroupData.push({
                hospital_id: hospital_id,
                measure_id: res.measure_id,
                insurance_company_id: insurance_company_id,
                year: year,
                hospital_params: res.data[0],
              });
          });

          AddPayValuesForManual(measureGroupData, 0, 0);
        })
        .catch((err) => {

          reject(err);
        });
    }
  } else {

    let hqmObject1 = {
      hospital_id: hospitalObj.hospital_id,
      measure_group_id: hospitalObj.measure_group_id,
      insurance_company_id: hospitalObj.insurance_company_id,
      year: hospitalObj.year,
      batchName: hospitalObj.batchName,
      user_id: hospitalObj.user_id,
    };

    let isexist = false;
    checkIfBatchExist(hqmObject1)
      .then((batchResult) => {
        if (batchResult.length > 0) {
          if (
            batchResult[0].Batch_Name === hqmObject1.batchName &&
            batchResult[0].Facility_List_ID === hqmObject1.hospital_id + ""
          ) {
            isexist = true;
          } else {
            isexist = false;
            return callBack({
              status: 409,
              message: "Error! Batch Already Exist for the Hospital !",
            },
              null
            );
          }
        } else {
          isexist = true;
        }
        if (isexist) {
          checkIfMeasureContCalculated(hqmObject1)
            .then((countResult) => {
              if (countResult.length > 0) {
                return callBack({
                  status: 409,
                  message: "Error! Measure Contribution Already calculated.!",
                },
                  null
                );
              } else {
                getAllMeasureIds(
                  hqmObject1.hospital_id,
                  hqmObject1.measure_group_id,
                  hqmObject1.year,
                  hqmObject1.insurance_company_id
                )
                  .then((getAllMeasureIdsResult) => {
                    // console.log("getAllMeasureIdsResul..!");
                    if (getAllMeasureIdsResult.length === 0) {
                      return callBack({
                        status: 404,
                        message: "Error! Please complete the Allocation Distribution process.",
                      },
                        null
                      );
                    }
                    getAllParams(
                      hqmObject1.hospital_id,
                      getAllMeasureIdsResult,
                      hqmObject1.year,
                      hqmObject1.insurance_company_id
                    );
                  })
                  .catch((err) => {

                    return callBack({
                      status: 500,
                      message: "Error! Get Params Function Internal Server Error.",
                    },
                      null
                    );
                  });
              }
            })
            .catch((err) => {

              return callBack({
                status: 500,
                message: "Error! Get Params Function Internal Server Error.",
              },
                null
              );
            });
        }
      })
      .catch((err) => {

        return callBack({
          status: 500,
          message: "Error! Get Params Function Internal Server Error.",
        },
          null
        );
      });

    // Rule Engine Process
    function processEngine(facts, decisions) {
      return new Promise(function (resolve, reject) {
        const engine = new Engine(decisions);
        // Pass the inputs to engine
        return engine
          .run(facts)
          .then((results) => {
            return resolve(results.events);
          })
          .catch((err) => {
            return reject(err);
          });
      });
    }

    // Get All MeasureIds
    function getAllMeasureIds(
      hospital_id,
      measure_group_id,
      year,
      insurance_company_id
    ) {
      return new Promise(function (resolve, reject) {
        // sql.query(`SELECT fmid.Measure_ID_List_ID, q.Get_All_Param_Query FROM [dbo].[Facilty_Measure_Mapping] fmid INNER JOIN [dbo].[Get_All_Params_Queries_Mapping] qm ON qm.Facility_List_ID = fmid.Facility_List_ID AND qm.Measure_Group_List_ID = fmid.Measure_Group_List_ID AND qm.Measure_ID_List_ID = fmid.Measure_ID_List_ID INNER JOIN [dbo].[Queries] q ON q.ID = qm.Queries_ID WHERE fmid.Facility_List_ID = '${hospital_id}' AND fmid.Measure_Group_List_ID = '${measure_group_id}' AND fmid.Year = '${year}' AND fmid.Insurance_Company_ID = '${insurance_company_id}' AND fmid.Measure_ID_Allocation_Percentage IS NOT NULL`, (err, res) => {
        sql.query(
          `SELECT fmid.Measure_ID_List_ID, q.Get_All_Param_Query FROM [dbo].[Facilty_Measure_Mapping] fmid INNER JOIN [dbo].[Get_All_Params_Queries_Mapping] qm ON qm.Facility_List_ID = fmid.Facility_List_ID AND qm.Measure_Group_List_ID = fmid.Measure_Group_List_ID AND qm.Measure_ID_List_ID = fmid.Measure_ID_List_ID AND qm.Year = fmid.Year  INNER JOIN [dbo].[Queries] q ON q.ID = qm.Queries_ID WHERE fmid.Facility_List_ID = '${hospital_id}' AND fmid.Measure_Group_List_ID = '${measure_group_id}' AND fmid.Year = '${year}' AND fmid.Insurance_Company_ID = '${insurance_company_id}'`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return reject(err);
            }
            const vals = res.recordset;
            return resolve(vals);
          }
        );
      });
    }

    // check If batch exist
    function checkIfBatchExist(paramData) {
      return new Promise(function (resolve, reject) {
        sql.query(
          `SELECT Batch_Name, Facility_List_ID FROM Results WHERE Batch_Name ='${paramData.batchName}'  GROUP BY Batch_Name ,Facility_List_ID`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return reject(err);
            }
            const vals = res.recordset;
            return resolve(vals);
          }
        );
      });
    }

    // checkIfMeasureContCalculated
    function checkIfMeasureContCalculated(paramData) {
      return new Promise(function (resolve, reject) {
        sql.query(
          `select Batch_Name from Results WHERE Facility_List_ID = '${paramData.hospital_id}' AND Year = '${paramData.year}' AND Batch_Name = '${paramData.batchName}' AND Measure_Group_List_ID = '${paramData.measure_group_id}' AND Insurance_Company_ID = '${paramData.insurance_company_id}'`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return reject(err);
            }
            const vals = res.recordset;
            return resolve(vals);
          }
        );
      });
    }

    function getAllParams(hospital_id, mids, year, insurance_company_id) {

      let requests = mids.map((id) => {
        return new Promise((resolve, reject) => {
          let request = new sql.Request();
          let requestQuery = id.Get_All_Param_Query.replaceAll(
            '+hospital_id+',
            hospital_id
          )
            .replaceAll(/\+id.Measure_ID_List_ID\+/g, id.Measure_ID_List_ID)
            .replaceAll('+year+', year);

          request.query(requestQuery, (err, result) => {
            if (err) {
              console.log("sql access error: ", err);
              reject(err);
            } else {
              const resultSet = {
                data: result.recordset,
                measure_id: id.Measure_ID_List_ID,
              };
              resolve(resultSet);
            }
          });
        });
      });
      Promise.all(requests)
        .then((body) => {
          let measureGroupData = [];
          body.forEach((res) => {
            if (res)
              measureGroupData.push({
                hospital_id: hospital_id,
                measure_id: res.measure_id,
                insurance_company_id: insurance_company_id,
                year: year,
                hospital_params: res.data[0],
              });
          });

          if (hospital_id === 9) {
            getlLifeSpanHospitalRules(measureGroupData);
          } else {
            getRules(measureGroupData);
          }
        })
        .catch((err) => {

          reject(err);
        });
    }

    function getlLifeSpanHospitalRules(measureGroupData) {
      let measureGroup = measureGroupData;

      let requests = measureGroup.map((id) => {
        return new Promise((resolve, reject) => {
          let request = new sql.Request();
          let requestQuery = `SELECT S.Measure_Group_List_ID, S.Measure_ID_List_ID, S.Score , S.Payout, C.Cal_Operator, C.is_Lower  FROM Scale_Range S LEFT JOIN Cal_Operators C ON S.Measure_Group_List_ID = C.Measure_Group_List_ID  WHERE S.Year ='${id.hospital_params.Year}' AND S.Measure_Group_List_ID = '${id.hospital_params.Measure_Group_List_ID}' AND  S.Measure_ID_List_ID = '${id.hospital_params.Measure_ID_List_ID}' AND C.Year = '${id.hospital_params.Year}'`;
          request.query(requestQuery, (err, result) => {
            if (err) {

              reject(err);
            } else {
              id.rule = result.recordset;
              let payoutPer = 0;
              let sps = id.hospital_params.System_Performance_Score;
              let miap = id.hospital_params.Measure_ID_Allocation_Percentage;
              let hpr;
              if (id.hospital_params.Hospital_Percent_Rank !== null) {
                hpr = id.hospital_params.Hospital_Percent_Rank;
              }

              // Added below block to get National Percentile for Nearest Percentile calculation
              getNationalPercentileQuery(id.hospital_params.Year, id.hospital_params.Measure_Group_List_ID, id.hospital_params.Measure_ID_List_ID)
                .then((nationalPersontileQueryResult) => {

                  let requestQuery = nationalPersontileQueryResult.recordset[0].Query
                    .replace("+Measure_ID_List_ID+", id.hospital_params.Measure_ID_List_ID)
                    .replace("+Measure_Group_List_ID+", id.hospital_params.Measure_Group_List_ID)
                    .replace("+year+", id.hospital_params.Year);

                  sql.query(requestQuery, function (err, value) {
                    if (err) {
                      console.log("error: ", err);
                      return callBack({
                        status: 500,
                        message: "Error! Internal Server Error.",
                      },
                        null
                      );
                    } else {
                      console.log(value);
                      let data = value.recordset[0]
                      const percentiles = Object.keys(data).reduce((acc, key) => {
                        if (key.startsWith('Percentile')) {
                          acc[key] = data[key];
                        }
                        return acc;
                      }, {});
                      id.percentileValues = percentiles
                      payoutPer = (isPayout(result.recordset, sps, id.percentileValues, hpr));
                      id.hospital_params.payout = payoutPer;
                      let measure_contribution = miap * (payoutPer / 100);
                      id.hospital_params.Measure_Contribution = measure_contribution;
                      resolve(id);
                    }
                  })

                })
                .catch(reject);
            }
          });
        });
      });
      Promise.all(requests)
        .then((body) => {
          let len = body.length;
          body.forEach((res) => {
            addLifespanToResult(res, hqmObject1)
              .then((addLifespanToResultResult) => {
                len--;
                if (len === 0) {
                  return callBack(null, {
                    status: 201,
                    message: "Payout Calculated & Saved Successfully !",
                  });
                }
              })
              .catch((err) => {

                return callBack({
                  status: 500,
                  message: "Error! Add PayValues Function Internal Server Error.",
                },
                  null
                );
              });
          });
        })
        .catch((err) => {

          return callBack({
            status: 500,
            message: "Error! Rule Engine Internal Server Error.",
          },
            null
          );
        });
    }
    // });
    // console.log("hospital obj", hospitalObj)

    // }

    function isPayout(data, sps, percentileValues, hpr) {
      let payoutPer = 0;
      let unsatisfied = 0;
      for (const item of data) {
        const op = item.Cal_Operator;
        const sc = item.Score;

        let cal;

        if (item.is_Lower === 0) {
          cal = eval(sps + op + sc);
        } else {

          payoutPer = 100;
          cal = eval(sc + op + sps);
        }

        if (cal) {
          payoutPer = item.Payout;
          if (item.is_Lower) {
            return payoutPer;
          }
        } else {
          unsatisfied++;
        }
      }

      // Added below block to calculate Nearest Percentile
      if (data.length !== 0) {
        if (payoutPer === 0 && data[0].Measure_Group_List_ID !== 1 && data[0].Measure_Group_List_ID !== 2) {
          const percentiles = Object.entries(percentileValues)
            .map(([key, value]) => ({ key, value: Number.parseFloat(value) }))
            .filter(({ value }) => !Number.isNaN(value))
            .sort((a, b) => a.value - b.value);


          let nearestPercentile;
          let minDifference = Infinity;
          for (const percentile of percentiles) {

            const difference = Math.abs(percentile.value - sps);
            if (difference < minDifference) {
              nearestPercentile = percentile;
              minDifference = difference;
            }
          }

          payoutPer = nearestPercentile.key.replace('Percentile_', '')
        } else if (payoutPer === 100 && data[0].is_Lower && unsatisfied > 0 && (data[0].Measure_Group_List_ID === 3 || data[0].Measure_Group_List_ID === 49)) {
          payoutPer = hpr * 100;
        }
      }
      console.log("Alloted payout " + payoutPer)
      return payoutPer;
    }

    function addLifespanToResult(res, hqmObject1) {
      return new Promise(function (resolve, reject) {
        sql.query(
          `INSERT INTO Results(Facility_List_ID, Measure_ID_List_ID,Allocation_Percentage,Payout,Year,Insurance_Company_ID, 
            Measure_Contribution, Batch_Name, User_ID, Measure_Group_List_ID, Hospital_Group_ID, National_Average, Rounded_Expected, 
            Sum_Actual, Sum_Expected, System_Performance_Score, System_Target, System_Target_Score, System_Visits, System_Discharges, Major_Teaching, Beds_100_199, System_Denominator, System_Score_Readm, System_Base_Score, System_Numerator,	System_Score_Rate) SELECT '${res.hospital_id}', 
            '${res.measure_id}','${res.hospital_params.Measure_ID_Allocation_Percentage}','${res.hospital_params.payout}', '${res.year}',
            '${res.insurance_company_id}' , '${res.hospital_params.Measure_Contribution}','${hqmObject1.batchName}','${hqmObject1.user_id}',
            '${hqmObject1.measure_group_id}', '${res.hospital_params.Hospital_Group_ID}', '${res.hospital_params.National_Average}', 
            '${res.hospital_params.Rounded_Expected}', '${res.hospital_params.Sum_Actual}', '${res.hospital_params.Sum_Expected}', 
            '${res.hospital_params.System_Performance_Score}', '${res.hospital_params.System_Target_Score}', 
            '${res.hospital_params.System_Target_Score}', '${res.hospital_params.System_Visits}', '${res.hospital_params.System_Discharges}', '${res.hospital_params.Major_Teaching}', '${res.hospital_params.Beds_100_199}', '${res.hospital_params.System_Denominator}', '${res.hospital_params.System_Score_Readm}', '${res.hospital_params.System_Base_Score}','${res.hospital_params.System_Numerator}','${res.hospital_params.System_Score_Rate}'`,
          (err, res) => {
            if (err) {
              console.log("error: ", err);
              return reject(err);
            }
            return resolve(res);
          }
        );
      });
    }

    function getRules(measureGroupData) {
      let measureGroup = measureGroupData;
      let requests = measureGroup.map((id) => {
        return new Promise((resolve, reject) => {
          let request = new sql.Request();
          let requestQuery = `SELECT r.Payout_Calculation_Rule FROM Rules r INNER JOIN Rules_Mapping rm ON r.ID = rm.Rules_ID WHERE rm.Facility_List_ID = '${id.hospital_id}' AND rm.Measure_ID_List_ID = '${id.measure_id}' AND rm.Year = '${id.year}' AND rm.Insurance_Company_ID = '${id.insurance_company_id}'`;
          request.query(requestQuery, (err, result) => {
            if (err) {

              reject(err);
            } else {
              id.rule = result.recordset[0];
              resolve(id);
            }
          });
        });
      });
      Promise.all(requests)
        .then((body) => {
          let attributesDB;
          let len = body.length;
          body.forEach((res) => {
            if (res) attributesDB = res.hospital_params;

            let keys = Object.keys(attributesDB);
            let attributes = JSON.parse(
              res.rule.Payout_Calculation_Rule
            ).attributes;
            let factObject = {};
            for (const key of keys) {
              for (const attr of attributes) {
                if (attr.name + "" === key + "") {
                  const value =
                    attr.name === "Compared_to_National"
                      ? attributesDB[key]
                      : Number(attributesDB[key]);

                  Object.assign(factObject, { [attr.name]: value });
                }
              }
            }

            processEngine(
              factObject,
              JSON.parse(res.rule.Payout_Calculation_Rule).decisions
            )
              .then((payoutResult) => {
                let pay = "";
                let performance_notes = "";
                if (structuredClone(payoutResult)[0] === undefined || structuredClone(payoutResult)[0] === null) {
                  pay = 0;
                } else {
                  let paytemp = "";
                  if (payoutResult[0].params.Pay === '-1') {
                    const percentiles = Object.keys(attributesDB).reduce((acc, key) => {
                      if (key.startsWith('Percentile')) {
                        acc[key] = attributesDB[key];
                      }
                      return acc;
                    }, {});
                    const percentilesValues = Object.entries(percentiles)
                      .map(([key, value]) => ({ key, value: Number.parseFloat(value) }))
                      .filter(({ value }) => !Number.isNaN(value))
                      .sort((a, b) => a.value - b.value);

                    let nearestPercentile;
                    let minDifference = Infinity;
                    for (const percentile of percentilesValues) {

                      const difference = Math.abs(percentile.value - attributesDB.Score);
                      if (difference < minDifference) {
                        nearestPercentile = percentile;
                        minDifference = difference;
                      }
                    }

                    pay = nearestPercentile.key.replace('Percentile_', '').replaceAll(/[^\d]/g, '');
                    performance_notes = 'Dynamic';
                  }
                  else if (payoutResult.length > 1) {
                    payoutResult.forEach((pays) => {
                      if (paytemp === "") {
                        if (Number.isNaN(pays.params.Pay)) {
                          paytemp = Number(factObject[pays.params.Pay]);
                          performance_notes = 'Dynamic'
                        } else {
                          paytemp = pays.params.Pay;
                          performance_notes = paytemp;
                        }
                      } else if (Number.isNaN(pays.params.Pay)) {
                          if (Number(paytemp) < Number(factObject[pays.params.Pay])) {
                            paytemp = factObject[pays.params.Pay];
                            performance_notes = 'Dynamic';
                          }
                        } else {
                          if (Number(paytemp) < Number(pays.params.Pay)) {
                            paytemp = pays.params.Pay;
                            performance_notes = paytemp;
                          }
                        }
                    });
                    pay = paytemp;
                  } else {
                    if (Number.isNaN(structuredClone(payoutResult)[0].params.Pay)) {
                      pay = factObject[structuredClone(payoutResult)[0].params.Pay];
                      performance_notes = 'Dynamic';
                    } else {
                      pay = structuredClone(payoutResult)[0].params.Pay;
                      performance_notes = pay;
                    }
                  }
                }
                let measure_contribution =
                  (res.hospital_params.Measure_ID_Allocation_Percentage * pay) /
                  100;

                AddPayValues(res, pay, measure_contribution, performance_notes)
                  .then((AddPayValuesResult) => {
                    len--;
                    if (len === 0) {
                      return callBack(null, {
                        status: 201,
                        message: "Payout Calculated & Saved Successfully !",
                      });
                    }
                  })
                  .catch((err) => {

                    return callBack({
                      status: 500,
                      message: "Error! Add PayValues Function Internal Server Error.",
                    },
                      null
                    );
                  });
              })
              .catch((err) => {

                return callBack({
                  status: 500,
                  message: "Error! Rule Engine Internal Server Error.",
                },
                  null
                );
              });
          });
        })
        .catch((err) => {

          return callBack({
            status: 500,
            message: "Error! Rule Engine Internal Server Error.",
          },
            null
          );
        });
    }

    //  Add PayValues
    function AddPayValues(res, pay, measure_contribution, performance_notes) {
      return new Promise(function (resolve, reject) {
        if (res.hospital_params.Compared_to_National === undefined) {
          sql.query(
            `IF EXISTS (SELECT Measure_ID_Allocation_Percentage FROM Facilty_Measure_Mapping WHERE Facility_List_ID = '${res.hospital_id}' AND Measure_Group_List_ID = '${hqmObject1.measure_group_id}' AND Year = '${res.year}' AND Insurance_Company_ID ='${res.insurance_company_id}' AND Measure_ID_List_ID = '${res.measure_id}' AND Measure_ID_Allocation_Percentage IS NOT NULL) BEGIN IF EXISTS (SELECT Criteria FROM Payout_Criteria_Performance_Notes WHERE Payout_Category = '${performance_notes}' AND Facility_List_ID = '${res.hospital_id}' AND Measure_Group_List_ID = '${hqmObject1.measure_group_id}' AND Year = '${res.year}' AND Insurance_Company_ID ='${res.insurance_company_id}' AND Measure_ID_List_ID = '${res.measure_id}' ) BEGIN  INSERT INTO Results(Facility_List_ID, Measure_ID_List_ID,Allocation_Percentage,Score,Baseline_Score,Payout,Year,Insurance_Company_ID, Measure_Contribution, Batch_Name, User_ID, Measure_Group_List_ID, HPR_Final_Score, National_Average, Performance_Notes) SELECT '${res.hospital_id}', '${res.measure_id}','${res.hospital_params.Measure_ID_Allocation_Percentage}','${res.hospital_params.Score}' , '${res.hospital_params.Baseline_Score}','${pay}', '${res.year}','${res.insurance_company_id}' , '${measure_contribution}','${hqmObject1.batchName}','${hqmObject1.user_id}','${hqmObject1.measure_group_id}','${res.hospital_params.HPR_Final_Score}','${res.hospital_params.National_Average}', Criteria FROM Payout_Criteria_Performance_Notes WHERE Payout_Category = '${performance_notes}' AND Facility_List_ID = '${res.hospital_id}' AND Measure_Group_List_ID = '${hqmObject1.measure_group_id}' AND Year = '${res.year}' AND Insurance_Company_ID ='${res.insurance_company_id}' AND Measure_ID_List_ID = '${res.measure_id}'  END ELSE BEGIN  INSERT INTO Results(Facility_List_ID, Measure_ID_List_ID,Allocation_Percentage,Score,Baseline_Score,Payout,Year,Insurance_Company_ID, Measure_Contribution, Batch_Name, User_ID, Measure_Group_List_ID, Performance_Notes, HPR_Final_Score, National_Average) SELECT '${res.hospital_id}', '${res.measure_id}','${res.hospital_params.Measure_ID_Allocation_Percentage}','${res.hospital_params.Score}' , '${res.hospital_params.Baseline_Score}','${pay}', '${res.year}','${res.insurance_company_id}' , '${measure_contribution}','${hqmObject1.batchName}','${hqmObject1.user_id}','${hqmObject1.measure_group_id}', 'Payout Criteria Not Found','${res.hospital_params.HPR_Final_Score}','${res.hospital_params.National_Average}' END END ELSE BEGIN INSERT INTO Results(Facility_List_ID, Measure_ID_List_ID,Allocation_Percentage,Score,Baseline_Score,Payout,Year,Insurance_Company_ID, Measure_Contribution, Batch_Name, User_ID, Measure_Group_List_ID, National_Average) SELECT '${res.hospital_id}', '${res.measure_id}','${res.hospital_params.Measure_ID_Allocation_Percentage}','${res.hospital_params.Score}' , '${res.hospital_params.Baseline_Score}','${pay}', '${res.year}','${res.insurance_company_id}' , '${measure_contribution}','${hqmObject1.batchName}','${hqmObject1.user_id}','${hqmObject1.measure_group_id}','${res.hospital_params.National_Average}' END`,
            (err, res) => {

              if (err) {
                console.log("error: ", err);
                return reject(err);
              }
              return resolve(res);
            }
          );
        } else {
          sql.query(
            `IF EXISTS (SELECT Measure_ID_Allocation_Percentage FROM Facilty_Measure_Mapping WHERE Facility_List_ID = '${res.hospital_id}' AND Measure_Group_List_ID = '${hqmObject1.measure_group_id}' AND Year = '${res.year}' AND Insurance_Company_ID ='${res.insurance_company_id}' AND Measure_ID_List_ID = '${res.measure_id}' AND Measure_ID_Allocation_Percentage IS NOT NULL) BEGIN	IF EXISTS (SELECT Criteria FROM Payout_Criteria_Performance_Notes WHERE Payout_Category = '${performance_notes}' AND Facility_List_ID = '${res.hospital_id}' AND Measure_Group_List_ID = '${hqmObject1.measure_group_id}' AND Year = '${res.year}' AND Insurance_Company_ID ='${res.insurance_company_id}' AND Measure_ID_List_ID = '${res.measure_id}' ) BEGIN  INSERT INTO Results(Facility_List_ID, Measure_ID_List_ID,Allocation_Percentage,Score,Baseline_Score,Payout,Year,Insurance_Company_ID, Measure_Contribution, Batch_Name, User_ID, Measure_Group_List_ID, Compared_to_National, HPR_Final_Score, National_Average, Performance_Notes) SELECT '${res.hospital_id}', '${res.measure_id}','${res.hospital_params.Measure_ID_Allocation_Percentage}','${res.hospital_params.Score}' , '${res.hospital_params.Baseline_Score}','${pay}', '${res.year}','${res.insurance_company_id}' , '${measure_contribution}','${hqmObject1.batchName}','${hqmObject1.user_id}','${hqmObject1.measure_group_id}','${res.hospital_params.Compared_to_National}', '${res.hospital_params.HPR_Final_Score}', '${res.hospital_params.National_Average}', Criteria FROM Payout_Criteria_Performance_Notes WHERE Payout_Category = '${performance_notes}' AND Facility_List_ID = '${res.hospital_id}' AND Measure_Group_List_ID = '${hqmObject1.measure_group_id}' AND Year = '${res.year}' AND Insurance_Company_ID ='${res.insurance_company_id}' AND Measure_ID_List_ID = '${res.measure_id}'  END ELSE BEGIN  INSERT INTO Results(Facility_List_ID, Measure_ID_List_ID,Allocation_Percentage,Score,Baseline_Score,Payout,Year,Insurance_Company_ID, Measure_Contribution, Batch_Name, User_ID, Measure_Group_List_ID, Compared_to_National, Performance_Notes, HPR_Final_Score, National_Average) SELECT '${res.hospital_id}', '${res.measure_id}','${res.hospital_params.Measure_ID_Allocation_Percentage}','${res.hospital_params.Score}' , '${res.hospital_params.Baseline_Score}','${pay}', '${res.year}','${res.insurance_company_id}' , '${measure_contribution}','${hqmObject1.batchName}','${hqmObject1.user_id}','${hqmObject1.measure_group_id}','${res.hospital_params.Compared_to_National}','Payout Criteria Not Found','${res.hospital_params.HPR_Final_Score}', '${res.hospital_params.National_Average}' END 	END 	ELSE 	BEGIN INSERT INTO Results(Facility_List_ID, Measure_ID_List_ID,Allocation_Percentage,Score,Baseline_Score,Payout,Year,Insurance_Company_ID, Measure_Contribution, Batch_Name, User_ID, Measure_Group_List_ID, Compared_to_National,National_Average) SELECT '${res.hospital_id}', '${res.measure_id}','${res.hospital_params.Measure_ID_Allocation_Percentage}','${res.hospital_params.Score}' , '${res.hospital_params.Baseline_Score}','${pay}', '${res.year}','${res.insurance_company_id}' , '${measure_contribution}','${hqmObject1.batchName}','${hqmObject1.user_id}','${hqmObject1.measure_group_id}','${res.hospital_params.Compared_to_National}', '${res.hospital_params.National_Average}'  END`,
            (err, res) => {
              if (err) {
                console.log("error: ", err);
                return reject(err);
              }
              return resolve(res);
            }
          );
        }
      });
    }
    // Function End.
  };
}

exports.scaleRangeValidation = function (hospitalObj, callBack) {
  getScaleRangeMesureIDS(hospitalObj)
    .then((getScaleRangeMesureResult) => {
      const filteredReportOnly = getScaleRangeMesureResult.filter((id) => id.Is_Report_Only !== true);
      let r = filteredReportOnly.map((id) => {
        return new Promise((resolve, reject) => {
          let request = new sql.Request();
          let requestQuery = `SELECT * from Scale_Range WHERE Year = '${hospitalObj.year}' AND Measure_Group_List_ID = '${id.Measure_Group_List_ID}' AND  Measure_ID_List_ID = '${id.ID}'`;
          request.query(requestQuery, (err, result) => {
            if (err) {

              reject(err);
            } else {
              resolve(result.recordset);
            }
          });
        });
      });
      Promise.all(r).then((body) => {
        let allResultSetsNotEmpty = body.every((res) => res.length !== 0);
        if (allResultSetsNotEmpty) {
          return callBack(null, {
            status: 200,
            message: "All Scale Range Data available.",
          });
        } else {
          return callBack(null, {
            status: 409,
            message: "Error! Scale Range Data not available, Please upload Scale Range.",
          });
        }
      })
        .catch((err) => {
          console.log("Error:", err);
          return callBack({
            status: 500,
            message: "Error! Internal Server Error.",
          });
        });
    })
}

exports.getBatch = function (hospitalObj, callBack) {
  sql.query(
    // `SELECT Batch_Name FROM Results WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.hospital_id}' GROUP BY Batch_Name`,
    `SELECT Batch_Name as item_id, Batch_Name as item_text FROM Results WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.hospital_id}' GROUP BY Batch_Name`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

exports.getBatchListUrl = function (hospitalObj, callBack) {

  sql.query(
    // `SELECT Batch_Name FROM Results WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.hospital_id}' GROUP BY Batch_Name`,
    `SELECT Batch_Name as item_id, Batch_Name as item_text FROM Results GROUP BY Batch_Name`,
    (err, hospitalResult) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

exports.getBatchByName = function (hospitalObj, callBack) {
  sql.query(
    // `SELECT Batch_Name FROM Results WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.hospital_id}' GROUP BY Batch_Name`,
    `SELECT Batch_Name as item_id, Batch_Name as item_text FROM Results WHERE Batch_Name ='${hospitalObj.batchName}'`,
    (err, hospitalResult) => {
      //  console.log("Inside Hospital List Model.",hospitalResult);
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset.length > 0) {
        return callBack({
          status: 302,
          message: "Error! Batch Aready Exist.",
        },
          null
        );
      } else {
        return callBack({
          status: 404,
          message: "Error! Batch Not Found.",
        },
          null
        );
      }
    }
  );
};

exports.getYearHospitalByBatchName = function (hospitalObj, callBack) {

  sql.query(
    // `SELECT Batch_Name FROM Results WHERE Year = '${hospitalObj.year}' AND Facility_List_ID = '${hospitalObj.hospital_id}' GROUP BY Batch_Name`,
    `SELECT DISTINCT R.Facility_List_ID, Facility_List.Facility_Name, R.Year FROM Results R left join Facility_List on Facility_List.ID = R.Facility_List_ID WHERE Batch_Name ='${hospitalObj.batchName}'`,
    (err, hospitalResult) => {
      //  console.log("Inside Hospital List Model.",hospitalResult);
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }

      if (hospitalResult.recordset.length > 0) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Batch Not Found.",
        },
          null
        );
      }
    }
  );
};


function getNationalPercentileQuery(year, measure_group_id, measure_ID) {
  return new Promise(function (resolve, reject) {
    sql.query(
      `SELECT Query, Table_Name FROM National_Percentile_Mapping WHERE Measure_Group_List_ID = '${measure_group_id}' AND Year = '${year}' AND Measure_ID_List_ID = '${measure_ID}'`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        return resolve(res);
      }
    );
  });
}
function getHopitalPercentRankQuery(year, hospital_id, measure_group_id) {
  return new Promise(function (resolve, reject) {
    sql.query(
      `SELECT Queries FROM Hospital_Percent_Rank_Mapping WHERE Measure_Group_List_ID = '${measure_group_id}'`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        return resolve(res);
      }
    );
  });
}

function getScaleRangeMesureIDS(hospitalObj) {
  return new Promise(function (resolve, reject) {
    // sql.query(`SELECT fmid.Measure_ID_List_ID, q.Get_All_Param_Query FROM [dbo].[Facilty_Measure_Mapping] fmid INNER JOIN [dbo].[Get_All_Params_Queries_Mapping] qm ON qm.Facility_List_ID = fmid.Facility_List_ID AND qm.Measure_Group_List_ID = fmid.Measure_Group_List_ID AND qm.Measure_ID_List_ID = fmid.Measure_ID_List_ID INNER JOIN [dbo].[Queries] q ON q.ID = qm.Queries_ID WHERE fmid.Facility_List_ID = '${hospital_id}' AND fmid.Measure_Group_List_ID = '${measure_group_id}' AND fmid.Year = '${year}' AND fmid.Insurance_Company_ID = '${insurance_company_id}' AND fmid.Measure_ID_Allocation_Percentage IS NOT NULL`, (err, res) => {
    sql.query(
      `SELECT  L.Measure_ID_Name,M.Measure_Group_List_ID,L.ID, L.Measure_ID, L.Is_Report_Only FROM Facilty_Measure_Mapping M left join Measure_ID_List L on L.ID =M.Measure_ID_List_ID WHERE M.Measure_Group_List_ID = ${hospitalObj.measure_group_id} AND M.Year = ${hospitalObj.year} AND M.Facility_List_ID = ${hospitalObj.hospital_id}`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        const vals = res.recordset;
        return resolve(vals);
      }
    );
  });

}

exports.getHospitalPercentRankDetails = function (hospitalObj, callBack) {

  getHopitalPercentRankQuery(hospitalObj.year, hospitalObj.hospital_id, hospitalObj.measure_group_id)
    .then((hopitalPercentRankQueryResult) => {

      let requestQuery = hopitalPercentRankQueryResult.recordset[0].Queries
        .replace("+hospital_id+", hospitalObj.hospital_id)
        .replace("+measure_group_id+", hospitalObj.measure_group_id)
        .replace("+year+", hospitalObj.year)
        .replace("+insurance_company_id+", hospitalObj.insurance_company_id);
      // console.log(requestQuery);

      sql.query(requestQuery, (error, finalResult) => {
        // console.log("finalResult", finalResult);
        if (error) {
          return callBack({
            status: 500,
            message: "Error! Internal Server Error.",
          },
            null
          );
        }
        if (finalResult) {
          return callBack(null, {
            status: 200,
            data: finalResult,
          });
        }
      });
    })
};
// Measure ID Pagination
exports.getNationalPercentilePagination = function (reqObject, callBack) {


  //------
  getNationalPercentileQuery(
    reqObject.dateObject.year,
    reqObject.dateObject.measure_group_id,
    reqObject.dateObject.measure_ID
  )
    .then((nationalPersontileQueryResult) => {
      // console.log("National Persontile RESULT .", nationalPersontileQueryResult);

      let requestQuery = nationalPersontileQueryResult.recordset[0].Query
        .replace("+Measure_ID_List_ID+", reqObject.dateObject.measure_ID)
        .replace("+Measure_Group_List_ID+", reqObject.dateObject.measure_group_id)
        .replace("+year+", reqObject.dateObject.year);


      let length = reqObject.length; //lenght
      let start = reqObject.start;
      let column = reqObject.order[0].column;
      if (reqObject.order[0].column === 0) {
        column = 1;
      }
      let dir = reqObject.order[0].dir;
      let filterquery = "";
      sql.query(requestQuery, function (err, rows, fields) {
        if (err) {
          console.log("error: ", err);
          return callBack({
            status: 500,
            message: "Error! Internal Server Error.",
          },
            null
          );
        } else {
          let numRows = rows.recordset.length;
          let disquery = requestQuery;
          if (filterquery !== "") {
            disquery = requestQuery + filterquery;
          }
          sql.query(
            disquery +
            `  ORDER BY ${column} ${dir}  OFFSET ${start} ROWS FETCH NEXT ${length} ROWS ONLY`,
            function (err, rows, fields) {
              if (err) {
                console.log("error: ", err);
                return callBack({
                  status: 500,
                  message: "Error! Internal Server Error.",
                },
                  null
                );
              } else {
                let data = {
                  data: rows.recordsets,
                  draw: reqObject.draw,
                  recordsFiltered: numRows,
                  recordsTotal: numRows,
                };

                return callBack(null, {
                  status: 200,
                  data: data,
                });
              }
            }
          );
        }
      });
    })
    .catch((err) => {

      return callBack({
        status: 500,
        message: "Error! Internal Server Error.",
      },
        null
      );
    });
};

exports.getNationalPercentile = function (hospitalObj, callBack) {

  sql.query(
    `SELECT * FROM National_Percentile WHERE Year = '${hospitalObj.year}' AND Measure_Group_List_ID = '${hospitalObj.hospital_id}' AND Measure_ID_List_ID = '${hospitalObj.Measure_ID_List_ID}'`,
    (err, hospitalResult) => {
      //  console.log("Inside Hospital List Model.",hospitalResult);
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (hospitalResult.recordset) {
        return callBack(null, {
          status: 200,
          data: hospitalResult.recordset,
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Hospital Not Found.",
        },
          null
        );
      }
    }
  );
};

//Assign Measure ID Wise Allocation
exports.assignAllocation = function (hospitalObj, callBack) {
  // checking the allocation sum status
  CheckAllocationStatus(hospitalObj)
    .then((checkAllocationStatusResult) => {
      let total =
        checkAllocationStatusResult.recordset[0].Total +
        Number(hospitalObj.allocation);
      if (total.toFixed(3) <= 100) {
        // checking if the Measure Group Allotment was already done for the current year
        sql.query(
          `SELECT ID,Measure_Group_Allocation_Percentage, CONVERT(letCHAR, Created_Datetime, 0) AS Created_Datetime FROM [dbo].[Facilty_Measure_Mapping] WHERE Facility_List_ID =  '${hospitalObj.hospital_id}' AND Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND Year = '${hospitalObj.year}' AND Insurance_Company_ID = '${hospitalObj.insurance_company_id}'`,
          (err, res) => {
            if (err) {

              return callBack({
                status: 500,
                message: "Error! Query Mapping Internal Server Error.",
              },
                null
              );
            }
            if (res.recordset.length === 0) {
              return callBack({
                status: 408,
                message: "Error! Mapping Not Done!",
              },
                null
              );
            }
            if (res.recordset[0].Measure_Group_Allocation_Percentage !== null) {
              // checking of the same allocation was done earlier
              if (
                res.recordset[0].Measure_Group_Allocation_Percentage ===
                hospitalObj.allocation
              ) {
                return callBack({
                  status: 409,
                  message: "Error! Allocation Already Exists!",
                },
                  null
                );
              }
              // inserting the old data into logs table
              PersistOldDataToLogs(hospitalObj, res.recordset[0])
                .then((PersistOldDataToLogsResult) => {
                  // updating the old allocation with the new one
                  UpdateMeasureGroupMappingValues(hospitalObj)
                    .then((UpdateMeasureGroupMappingValuesResult) => {
                      sql.query(
                        `SELECT ID FROM [dbo].[Facilty_Measure_Mapping] WHERE Facility_List_ID =  '${hospitalObj.hospital_id}' AND Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND Year = '${hospitalObj.year}' AND Insurance_Company_ID = '${hospitalObj.insurance_company_id}' AND Measure_ID_Allocation_Percentage IS NOT NULL`,
                        (error, result) => {
                          if (error) {

                            return callBack({
                              status: 500,
                              message: "Error! Fetch Measure ID Mapping Internal Server Error.",
                            },
                              null
                            );
                          }
                          if (result.recordset.length > 0) {
                            let leng = result.recordset.length;
                            let len = leng;
                            let allocation = hospitalObj.allocation / leng;
                            result.recordset.forEach((mid) => {
                              UpdateAllocationValues(mid.ID, allocation)
                                .then((UpdateAllocationValuesResult) => {
                                  len--;
                                  if (len === 0) {
                                    return callBack(null, {
                                      status: 201,
                                      message: "Success! Measure IDs Allocation Calculated & Updated Successfully !",
                                    });
                                  }
                                })
                                .catch((err) => {

                                  return callBack({
                                    status: 500,
                                    message: "Error! Update Allocation Values Function Internal Server Error.",
                                  },
                                    null
                                  );
                                });
                            });
                          } else {
                            return callBack({
                              status: 501,
                              message: "Error! No Valid MeasureID(s) Available for Allocation.",
                            },
                              null
                            );
                          }
                        }
                      );
                    })
                    .catch((err) => {

                      return callBack({
                        status: 500,
                        message: "Error! Update Measure Group Mapping Values Function Internal Server Error.",
                      },
                        null
                      );
                    });
                })
                .catch((err) => {

                  return callBack({
                    status: 500,
                    message: "Error! Persist Old Data To Logs Function Internal Server Error.",
                  },
                    null
                  );
                });
            } else {
              AddMeasureGroupMappingValues(hospitalObj)
                .then((AddMeasureGroupMappingValuesResult) => {
                  sql.query(
                    `SELECT Measure_ID_Allocation_Query FROM Measure_ID_Allocation_Queries_Mapping miaqm INNER JOIN Queries q ON q.ID = miaqm.Queries_ID WHERE miaqm.Facility_List_ID =  '${hospitalObj.hospital_id}' AND miaqm.Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND miaqm.Year = '${hospitalObj.year}' AND miaqm.Insurance_Company_ID = '${hospitalObj.insurance_company_id}'`,
                    (err, res) => {
                      if (err) {

                        return callBack({
                          status: 500,
                          message: "Error! Query Mapping Internal Server Error.",
                        },
                          null
                        );
                      }
                      if (res.recordset.length > 0) {
                        sql.query(
                          res.recordset[0].Measure_ID_Allocation_Query.replace(
                            "+hospital_id+",
                            `${hospitalObj.hospital_id}`
                          )
                            .replace(
                              "+measure_group_id+",
                              `${hospitalObj.measure_group_id}`
                            )
                            .replace(
                              "+insurance_company_id+",
                              `${hospitalObj.insurance_company_id}`
                            )
                            .replace("+year+", `${hospitalObj.year}`),
                          (error, resp) => {
                            if (error) {

                              return callBack({
                                status: 500,
                                message: "Error! Fetching Measure ID Query Internal Server Error.",
                              },
                                null
                              );
                            }
                            if (resp.recordset.length > 0) {
                              let leng = resp.recordset.length;
                              let len = leng;
                              let allocation = hospitalObj.allocation / leng;
                              resp.recordset.forEach((mid) => {

                                AddAllocationValues(
                                  hospitalObj,
                                  mid.Measure_ID_List_ID,
                                  allocation
                                )
                                  .then((AddAllocationValuesResult) => {
                                    len--;
                                    if (len === 0) {
                                      return callBack(null, {
                                        status: 201,
                                        message: "Measure IDs Allocation Calculated & Saved Successfully !",
                                      });
                                    }
                                  })
                                  .catch((err) => {

                                    return callBack({
                                      status: 500,
                                      message: "Error! Add Allocation Values Function Internal Server Error.",
                                    },
                                      null
                                    );
                                  });
                              });
                            } else {
                              return callBack({
                                status: 501,
                                message: "Error! No Valid MeasureID(s) Available for Allocation.",
                              },
                                null
                              );
                            }
                          }
                        );
                      }
                    }
                  );
                })
                .catch((err) => {

                  return callBack({
                    status: 500,
                    message: "Error! Add Measure Group Mapping Function Internal Server Error.",
                  },
                    null
                  );
                });
            }
          }
        );
      } else {
        return callBack({
          status: 400,
          message: "Error! Allocation limit exceeded.",
        },
          null
        );
      }
    })
    .catch((err) => {

      return callBack({
        status: 500,
        message: "Error! Check allocation status Function Internal Server Error.",
      },
        null
      );
    });
};

// adding the facility to measure ID mapping
function AddAllocationValues(hospitalObj, measure_ID, allocation) {
  return new Promise(function (resolve, reject) {

    sql.query(
      `UPDATE Facilty_Measure_Mapping SET Measure_ID_Allocation_Percentage = '${allocation}' WHERE Facility_List_ID =  '${hospitalObj.hospital_id}' AND Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND Year = '${hospitalObj.year}' AND Insurance_Company_ID = '${hospitalObj.insurance_company_id}' AND Measure_ID_List_ID = '${measure_ID}'`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        return resolve(res);
      }
    );
  });
}

// adding the facility to measure group mapping
function AddMeasureGroupMappingValues(hospitalObj) {
  return new Promise(function (resolve, reject) {
    sql.query(
      `UPDATE [dbo].[Facilty_Measure_Mapping] SET Measure_Group_Allocation_Percentage = '${hospitalObj.allocation}' WHERE Facility_List_ID =  '${hospitalObj.hospital_id}' AND Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND Year = '${hospitalObj.year}' AND Insurance_Company_ID = '${hospitalObj.insurance_company_id}'`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        return resolve(res);
      }
    );
  });
}

// check the allocation status of the hospital
function CheckAllocationStatus(hospitalObj) {
  return new Promise(function (resolve, reject) {
    sql.query(
      `SELECT SUM(CAST (Measure_Group_Allocation_Percentage AS FLOAT)) AS Total FROM (SELECT DISTINCT(Measure_Group_List_ID),Measure_Group_Allocation_Percentage FROM [dbo].[Facilty_Measure_Mapping]  WHERE Facility_List_ID = '${hospitalObj.hospital_id}' AND Insurance_Company_ID = '${hospitalObj.insurance_company_id}' AND Year = '${hospitalObj.year}') A`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        return resolve(res);
      }
    );
  });
}

// persist the old allocation percentage in the logs tables
function PersistOldDataToLogs(hospitalObj, response) {

  return new Promise(function (resolve, reject) {

    sql.query(
      `INSERT INTO Allocation_Logs (Year, Facility_List_ID, Measure_Group_List_ID, Old_Allocation_Percentage, Old_Created_Datetime, Insurance_Company_ID, User_ID) VALUES('${hospitalObj.year}','${hospitalObj.hospital_id}','${hospitalObj.measure_group_id}','${response.Measure_Group_Allocation_Percentage}', '${response.Created_Datetime}' ,'${hospitalObj.insurance_company_id}','${hospitalObj.user_id}')`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        return resolve(res);
      }
    );
  });
}

// updating the facility to measure group mapping
function UpdateMeasureGroupMappingValues(hospitalObj) {
  return new Promise(function (resolve, reject) {
    sql.query(
      `UPDATE Facilty_Measure_Mapping SET Measure_Group_Allocation_Percentage = '${hospitalObj.allocation}', Created_Datetime = GETDATE() WHERE Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND Year = '${hospitalObj.year}' AND Facility_List_ID =  '${hospitalObj.hospital_id}' AND Insurance_Company_ID = '${hospitalObj.insurance_company_id}'`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        return resolve(res);
      }
    );
  });
}

// updating the facility to measure ID mapping
function UpdateAllocationValues(ID, allocation) {
  return new Promise(function (resolve, reject) {
    sql.query(
      `UPDATE Facilty_Measure_Mapping SET Measure_ID_Allocation_Percentage = '${allocation}', Created_Datetime = GETDATE() WHERE ID = '${ID}'`,
      (err, res) => {
        if (err) {
          console.log("error: ", err);
          return reject(err);
        }
        return resolve(res);
      }
    );
  });
}

// Get payout screen display details
exports.getPayoutScreenDisplayDetails = function (hospitalObj, callBack) {
  sql.query(
    `SELECT Payout_Screen_Display_Query FROM Payout_Screen_Display_Queries_Mapping psdqm INNER JOIN Queries q ON q.ID = psdqm.Queries_ID WHERE psdqm.Facility_List_ID =  '${hospitalObj.hospital_id}' AND psdqm.Measure_Group_List_ID = '${hospitalObj.measure_group_id}' AND psdqm.Year = '${hospitalObj.year}' AND psdqm.Insurance_Company_ID = '${hospitalObj.insurance_company_id}'`,
    (err, result) => {
      if (err) {
        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      // console.log(result, "query............");
      if (result) {

        // const replaced = a.replace(/:/g,"hi");
        // str.replace(/\+hospital_id\+/g,"1");


        let requestQuery =
          result.recordset[0].Payout_Screen_Display_Query
            .replace(/\+hospital_id\+/g, hospitalObj.hospital_id)
            .replace(/\+measure_group_id\+/g, hospitalObj.measure_group_id)
            .replace(/\+insurance_company_id\+/g, hospitalObj.insurance_company_id)
            .replace(/\+batch_name\+/g, hospitalObj.batchName)
            .replace(/\+year\+/g, hospitalObj.year);
        // console.log(requestQuery, "requestQuery............");
        sql.query(requestQuery, (error, finalResult) => {
          // console.log("finalResult", finalResult);
          if (error) {
            return callBack({
              status: 500,
              message: "Error! Internal Server Error.",
            },
              null
            );
          }
          if (finalResult) {
            return callBack(null, {
              status: 200,
              data: finalResult,
            });
          }
        });
      } else {
        return callBack({
          status: 404,
          message: "Error! Payout Screen Display Details Not Found for Provided Measure Group.",
        },
          null
        );
      }
    }
  );
};

// Get getPayoutDisplay
exports.getPayoutDisplay = function (hospitalObj, callBack) {
  if (hospitalObj.hospital_id === 9) {
    sql.query(
      `SELECT Results.ID as Result_ID, Measure_ID_List.Measure_ID, Measure_ID_List.Measure_Description,
      Measure_ID_List.Measure_ID_Name, Results.Sum_Actual,Results.Rounded_Expected, Results.System_Performance_Score,Results.System_Target_Score,Results.System_Visits,Results.System_Discharges, Results.Allocation_Percentage,Results.Major_Teaching, Results.Beds_100_199,Results.System_Denominator, Results.System_Score_Readm, Results.System_Base_Score, Measure_Contribution, Comments, Results.Created_Datetime, 
      HPR_Final_Score FROM Results INNER JOIN Measure_Group_List ON Results.Measure_Group_List_ID = Measure_Group_List.ID INNER JOIN Measure_ID_List ON Results.Measure_ID_List_ID = Measure_ID_List.ID WHERE Results.Facility_List_ID =  '${hospitalObj.hospital_id}' AND Results.Year = '${hospitalObj.year}' AND Results.Batch_Name = '${hospitalObj.batchName}' AND Results.Insurance_Company_ID = '${hospitalObj.insurance_company_id}' ORDER BY Measure_ID_List.Measure_ID`,
      (err, result) => {
        if (err) {
          return callBack({
            status: 500,
            message: "Error! Internal Server Error.",
          },
            null
          );
        }
        if (result) {
          return callBack(null, {
            status: 200,
            data: result,
          });
        } else {
          return callBack({
            status: 404,
            message: "Error! Payout Screen Display Details Not Found for Provided Measure Group.",
          },
            null
          );
        }
      }
    );

  } else {
    sql.query(
      `SELECT Results.ID as Result_ID, Measure_ID_List.Measure_ID, Measure_ID_List.Measure_Description,Measure_ID_List.Measure_ID_Name, Results.Allocation_Percentage, Results.National_Percentile, Baseline_Score, Score, Compared_to_National, Performance_Notes, Measure_Contribution, Comments, Results.Created_Datetime, HPR_Final_Score FROM Results INNER JOIN Measure_Group_List ON Results.Measure_Group_List_ID = Measure_Group_List.ID INNER JOIN Measure_ID_List ON Results.Measure_ID_List_ID = Measure_ID_List.ID WHERE Results.Facility_List_ID =  '${hospitalObj.hospital_id}' AND Results.Year = '${hospitalObj.year}' AND Results.Batch_Name = '${hospitalObj.batchName}' AND Results.Insurance_Company_ID = '${hospitalObj.insurance_company_id}' ORDER BY Measure_ID_List.Measure_ID`,
      (err, result) => {
        if (err) {
          return callBack({
            status: 500,
            message: "Error! Internal Server Error.",
          },
            null
          );
        }
        if (result) {
          return callBack(null, {
            status: 200,
            data: result,
          });
        } else {
          return callBack({
            status: 404,
            message: "Error! Payout Screen Display Details Not Found for Provided Measure Group.",
          },
            null
          );
        }
      }
    );
  }
};

//Modify Measure ID Allocation
exports.modifyAllocation = function (hospitalObj, callBack) {


  sql.query(
    `INSERT INTO Results_Logs(Year, Facility_List_ID, Measure_ID_List_ID, Allocation_Percentage, Score, Baseline_Score, Payout, National_Percentile, Hospital_Percent_Rank, Measure_Contribution, Result_ID, Insurance_Company_ID, User_ID, Old_Created_Datetime) SELECT Year, Facility_List_ID, Measure_ID_List_ID, Allocation_Percentage, Score, Baseline_Score, Payout, National_Percentile, Hospital_Percent_Rank, Measure_Contribution, ID, Insurance_Company_ID, '${hospitalObj.user_id}',Created_Datetime from Results WHERE ID = ${hospitalObj.r_id}`,
    (error, result) => {
      if (error) {

        return callBack({
          status: 500,
          message: "Error! Internal Server Error.",
        },
          null
        );
      }
      if (result) {
        sql.query(
          `UPDATE Results SET Performance_Notes = '${hospitalObj.performance_notes}', Measure_Contribution = CONVERT(float, '${hospitalObj.measure_contribution}'), Comments = '${hospitalObj.comments}', User_ID = '${hospitalObj.user_id}', Created_Datetime = GETDATE() WHERE ID  = ${hospitalObj.r_id}`,
          (err, res) => {
            if (err) {

              return callBack({
                status: 500,
                message: "Error! Internal Server Error.",
              },
                null
              );
            }
            if (res) {
              return callBack(null, {
                status: 200,
                data: res,
              });
            }
          }
        );
      } else {
        return callBack({
          status: 404,
          message: "Error! Result Not Found!",
        },
          null
        );
      }
    }
  );
};

//Modify Measure ID Allocation CR
exports.modifyMeasureIDAllocation = function (hospitalObj, callBack) {
  let UserID = hospitalObj.user_id;
  //fetching the allocation data from DB
  sql.query(`SELECT DISTINCT(Measure_Group_Allocation_Percentage) FROM Facilty_Measure_Mapping WHERE Measure_Group_List_ID = ${hospitalObj.measure_group_id} AND Year = '${hospitalObj.year}' AND Insurance_Company_ID = ${hospitalObj.insurance_company_id} AND Facility_List_ID = ${hospitalObj.hospital_id}`, (err, res) => {
    if (err) {
      console.log("error: ", err);
      result(err, null);
      return;
    }
    if (res.recordset.length > 0) {
      let MeasureGroupAllocation = res.recordset[0].Measure_Group_Allocation_Percentage;
      let MeasureGroupAllocationFromAPI = 0;
      hospitalObj.measure_ids.forEach((mids) => {
        if (mids)
          if (mids.Allocation !== 'NULL')
            MeasureGroupAllocationFromAPI += Number(mids.Allocation);
      });
      //cross-verifying the allocations

      if (MeasureGroupAllocation === MeasureGroupAllocationFromAPI || ((Math.abs(MeasureGroupAllocation - MeasureGroupAllocationFromAPI)).toFixed(3) <= 0.004)) {
        sql.query(`INSERT INTO Facilty_Measure_Mapping_Logs(Year,Facility_List_ID,Measure_Group_List_ID,Measure_ID_List_ID,Old_Measure_ID_Allocation_Percentage,Insurance_Company_ID,User_ID,Old_Created_Datetime) SELECT Year,Facility_List_ID,Measure_Group_List_ID,Measure_ID_List_ID,Measure_ID_Allocation_Percentage,Insurance_Company_ID,${UserID},Created_Datetime FROM Facilty_Measure_Mapping WHERE Measure_Group_List_ID = ${hospitalObj.measure_group_id} AND Year = '${hospitalObj.year}' AND Insurance_Company_ID = ${hospitalObj.insurance_company_id} AND Facility_List_ID = ${hospitalObj.hospital_id}`, (error, result) => {
          if (error) {
            console.log("error: ", error);
            result(error, null);
            return;
          }
          if (result) {
            hospitalObj.measure_ids.forEach((mids) => {
              if (mids)
                if (mids.Allocation !== 'NULL') {
                  sql.query(`UPDATE Facilty_Measure_Mapping SET Measure_ID_Allocation_Percentage = FORMAT(${mids.Allocation},'g15') WHERE Measure_ID_List_ID = ${mids.ID} AND Year = ${hospitalObj.year} AND Measure_Group_List_ID = ${hospitalObj.measure_group_id} AND Facility_List_ID = ${hospitalObj.hospital_id}`, (errors, results) => {
                    if (errors) {
                      console.log("error: ", errors);
                      results(errors, null);
                      return;
                    }
                  });
                }
            });
            return callBack(null, {
              status: 200,
              data: "Updated the Measure ID Allocations Successfully!",
            });
          }
        });
      } else {
        return callBack(null, {
          status: 407,
          data: "Measure Group and Measure ID Allocations Do Not Match!",
        });
      }
    } else {
      return callBack(null, {
        status: 400,
        data: "Measure Group Allocation Not Found!",
      });
    }
  });

};



//Function End