var express = require("express");
var app = express();
app.set('trust proxy', true);
var routes = require("./routes").routes;
var mongoose = require("mongoose");
var bodyParser = require("body-parser");
var config = require("./config");
var path = require("path");
var cors = require("cors");
var compression = require("compression");
var helmet = require("helmet");
const csrf = require('csurf');
const cookieParser = require('cookie-parser');

require('./fn/endecrypt');
app.use(compression());
app.use(helmet())
app.use(helmet.contentSecurityPolicy({
  directives: {
    defaultSrc: ["'self'"],
    scriptSrc: ["'self'"],
    styleSrc: ["'self'"],
  },
}));

// view engine setup
app.set("views", path.join(__dirname, "views"));
app.set("view engine", "ejs");

// app.use('/uploads', express.static(path.join(__dirname, 'public')))

// app.use('/uploads', express.static('public'))
app.use('/uploads', express.static(__dirname + '/uploads'));
 
app.use(bodyParser.json());
app.use(
  bodyParser.urlencoded({
    limit: "50mb",
    extended: true,
    parameterLimit: 50000
  })
);
app.get('/', (req, res) => {
  res.status(200).send('ok');
});

app.get('/health', (req, res) => {
  res.status(200).send('ok');
});

// Middleware to set cache-control headers based on Content-Type
app.use((req, res, next) => {
  const contentType = res.get('Content-Type');
  if (contentType && (contentType.startsWith('image/') ||
      contentType.startsWith('text/css') ||
      contentType.startsWith('application/javascript'))) {
    res.setHeader('Cache-Control', 'public, max-age=604800'); // 1 week
  } else {
    res.setHeader('Cache-Control', 'no-store'); // Do not cache other content types
  }
  next();
});

// Middleware to set security headers for all routes
app.use((req, res, next) => {
  res.setHeader('X-Frame-Options', 'DENY');
  next();
});
const corsOptions = {
  origin: [
    'http://localhost:4200',
    'http://[::1]:4200',
    'https://hqm-fe-dev-app-01.yellowwater-7db21bcc.eastus2.azurecontainerapps.io',
    'https://dev-hqm.bcbsri.org'
  ],
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE',
  credentials: true, 
  // optionsSuccessStatus: 204,
};
app.use(cors(corsOptions));
app.options('*', cors());

app.use(cookieParser());
app.use("/api/rest",routes); // Set the default version to latest.

app.use((err, req, res, next) => {
  if (err.code === 'EBADCSRFTOKEN') {
    res.status(403).json({ error: 'CSRF token validation failed' });
  } else {
    next(err);
  }
});
exports.app = app;