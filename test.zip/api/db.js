const dbConfig = require("./config");
var logger = require('./logger.js')(__filename);
const { DefaultAzureCredential } = require('@azure/identity');
const sql = require('mssql');

const credential = new DefaultAzureCredential({
  managedIdentityClientId: dbConfig.con.managedClientId
});

try {
    console.log(process.env);
    console.log('-------------------------------------HQM DEbug ---------------------------------');
    console.log(dbConfig.con.managedClientId);
    console.log('---------------------------------------------------------------------------');
    console.log(JSON.stringify(dbConfig.con));
    console.log('-------------------------------------HQM DEbug End ---------------------------------');
    logger.info(JSON.stringify(dbConfig.con));
    
    credential.getToken('https://database.windows.net/.default').then((tokenResp) => { 
        if (!tokenResp || !tokenResp.token) {
            throw new Error('Failed to acquire token');
        }
        const config = {
            server: dbConfig.con.host,
            port: 1433,
            database: dbConfig.con.database,
            authentication: {
                type: 'azure-active-directory-access-token',
                options: {
                    token: tokenResp.token
                }
            },
            options: {
                encrypt: true
            }
        };

        sql.connect(config).then(pool => {
            console.info('Connected to Azure SQL using managed identity', dbConfig.con.database);
        }).catch(function (err) {
            console.error("MSSql DB Connect Error *** ", err);
        });
        
    }).catch(function(err) {
        console.error('Get token err :', err);
    });
  } catch (err) {
    console.error('Connection failed:', err);
  }

module.exports = sql;