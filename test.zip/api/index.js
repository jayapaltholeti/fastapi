let app = require('./app.js').app;
let http = require('http');
let server = http.Server(app); 
let config = require("./config");
let multer = require('multer');
let logger = require('./logger.js')(__filename);
let port = 7001;
let gfs;
let dbName, fileUpload;
dbName = config.con.db
logger.info("HQM APIs Running On " + process.env.NODE_ENV + " Mode..!");
logger.info("Connection Name : ----- " + process.env.NODE_ENV);

 
server.listen(port, '0.0.0.0', function (err, open) {
  if (err) {
    logger.error('Port Already in use : -----' + port);
  } else {
    logger.info('Server Listening On Port : ----- ' + port);
  }
}); 


module.exports = server; 





