let routes = require('express')();
let authfilter = require('./fn/filter').authFilter;
let multer = require('multer');
let upload = multer({
  'dest': 'storage/csv/'
});
let logger = require('./logger.js')(__filename);

//Disable respone header for 'x-powered-by'
routes.disable('x-powered-by')
// Import Controller.
let userController = require('./controllers/userController');
let fileController = require('./controllers/fileStorageController');
let hospitalController = require('./controllers/hospitalController');

routes.get('/csrfToken', function (req, res) {
  if (req.csrfToken) {
    // console.log(req.csrfToken());
     res.cookie('XSRF-TOKEN', req.csrfToken(),{path: '/' });
    // res.send('pong');
    // res.json({ csrfToken: req.csrfToken(), message: 'CSRF token included in the response' });
    res.json({ });
  } else {
    
    res.status(500).send('Internal Server Error');
  }
});

//User APIs
routes.post('/private/hqm/v1/user/create', userController.create);
routes.post('/private/dma/v1/user/signIn', userController.signInSSO);

// OAuth Authorization Code Flow Routes
routes.get('/auth/login', userController.initiateAuth);
routes.get('/auth/callback', userController.handleAuthCallback);

routes.post('/private/dma/v1/user/fileUpload', authfilter(false), fileController.fileUpload);
routes.post('/private/dma/v1/user/dma/list', authfilter(false),  fileController.findDmaList);
// HQM API
// Get Hospital Group List // done
routes.post('/private/hqm/v1/hospital/group/getlist', authfilter(false), hospitalController.getHospitalGroupList);
// Get Measure Group List   //Done
routes.post('/private/hqm/v1/hospital/measuregroup/getlist', authfilter(false), hospitalController.getMeasureGroupList);
// Get Measure ID List
routes.get('/private/hqm/v1/hospital/measureidlist/getlist', authfilter(false), hospitalController.getMeasureIDList);

// Get All Hospital List //Done
routes.post('/private/hqm/v1/hospital/getlist', authfilter(false), hospitalController.getAllHospital);
// Get All InsuranceCompany List
routes.get('/private/hqm/v1/hospital/insurancecompany/getlist', authfilter(false), hospitalController.getAllInsuranceCompany);
// Get Hospital By Id
routes.post('/private/hqm/v1/hospital/getbyid/:ID', authfilter(false), hospitalController.getHospitalById);
// Get Report List
routes.post('/private/hqm/v1/report/getlist', authfilter(false), hospitalController.getReportList);
// HQM File Upload
routes.post('/private/hqm/v1/hospital/file/upload', authfilter(false), fileController.fileUpload);
// Create hospital Group //done
routes.post('/private/hqm/v1/hospital/group/create', authfilter(false), hospitalController.createHospitalGroup);
// Create Measure Group //done
routes.post('/private/hqm/v1/hospital/measuregroup/create', authfilter(false), hospitalController.createHospitalMeasureGroup);
// Create Measure ID List //done
routes.post('/private/hqm/v1/hospital/measuregroupidlist/create', authfilter(false), hospitalController.createMeasureIDList);
// Create Hospital
routes.post('/private/hqm/v1/hospital/create', authfilter(false), hospitalController.createHospital);
// Delete Hospital
routes.post('/private/hqm/v1/hospital/delete', authfilter(false), hospitalController.deleteHospital);
// update Hospital
routes.post('/private/hqm/v1/hospital/update', authfilter(false), hospitalController.updateHospital);
// Get Facilty Measure Id Mapping //done
routes.post('/private/hqm/v1/hospital/measureidmapping', authfilter(false), hospitalController.getMeasureGroupById);
//Create Mapping
routes.post('/private/hqm/v1/hospital/mapping/create', authfilter(false), hospitalController.createMapping);
// Update Update Facilty Measure Id Mapping
routes.post('/private/hqm/v1/hospital/faciltymeasureidmapping', authfilter(false), hospitalController.faciltymeasureidmapping);
// Rule Engine Payout Calculation  //done
routes.post('/private/hqm/v1/hospital/calculate/payout', authfilter(false), hospitalController.calculatePayout);

// Calculating Measure ID wise allocation
routes.post('/private/hqm/v1/hospital/assignAllocation', authfilter(false), hospitalController.assignAllocation);

// Calculating Measure ID wise allocation
routes.post('/private/hqm/v1/hospital/modifyAllocation', authfilter(false), hospitalController.modifyAllocation);

// Modifying Measure ID allocation
routes.post('/private/hqm/v1/hospital/modifyMeasureIDAllocation', authfilter(false), hospitalController.modifyMeasureIDAllocation);

// Get Payout calculation details  //done
routes.post('/private/hqm/v1/hospital/payout/details', authfilter(false), hospitalController.getPayoutScreenDisplayDetails);

// Get Payout calculation details //done
routes.post('/private/hqm/v1/hospital/payout/display', authfilter(false), hospitalController.getPayoutDisplay);

// Get Payout calculation details //done
routes.post('/private/hqm/v1/hospital/file/get',authfilter(false), hospitalController.getFilesType);

// Get Payout calculation details
routes.post('/private/hqm/v1/hospital/year/get', authfilter(false), hospitalController.getYear);
// done
routes.post('/private/hqm/v1/mapping/get', authfilter(false), hospitalController.getMappedIDList);

routes.get('/private/hqm/v1/getYears', authfilter(false), hospitalController.getYears);

routes.post('/private/hqm/v1/mapping/update', authfilter(false), hospitalController.mappingUpdate);

routes.post('/private/hqm/v1/hospital/upload', authfilter(false), hospitalController.hospitalUpload);

routes.post('/private/hqm/v1/payout/hospital/getlist', authfilter(false), hospitalController.payoutHospital);

//done
routes.post('/private/hqm/v1/payout/hospital/measuregrouplist', authfilter(false), hospitalController.patoutMeasureGroupList);

routes.post('/private/hqm/v1/payout/hospital/scaleMeasuregrouplist', authfilter(false), hospitalController.scaleMeasureGroupList);

routes.post('/private/hqm/v1/payout/hospital/scaleRangeValidation', authfilter(false), hospitalController.scaleRangeValidation);
//done
routes.post('/private/hqm/v1/groupsystem/pagination', authfilter(false), hospitalController.getGroupSystemPagination);

routes.post('/private/hqm/v1/groupsystem/update', authfilter(false), hospitalController.updateGroupSystem);

routes.post('/private/hqm/v1/groupsystem/delete', authfilter(false), hospitalController.deleteGroupSystem);

// Done
routes.post('/private/hqm/v1/measuregroup/criteria', authfilter(false), hospitalController.getCriteria);
// Measure group // Done
routes.post('/private/hqm/v1/measuregroup/pagination', authfilter(false), hospitalController.getMeasureGroupPagination);

routes.post('/private/hqm/v1/measuregroup/update', authfilter(false), hospitalController.updateMeasureGroup);

routes.post('/private/hqm/v1/measuregroup/delete', authfilter(false), hospitalController.deleteMeasureGroup);

// Measure ID group // Done 
routes.post('/private/hqm/v1/measureid/pagination', authfilter(false), hospitalController.getMeasureIDPagination);
  // Done
routes.post('/private/hqm/v1/measureid/update', authfilter(false), hospitalController.updateMeasureID);

routes.post('/private/hqm/v1/measureid/delete', authfilter(false), hospitalController.deleteMeasureID);
// Measure Hospital // Done
routes.post('/private/hqm/v1/hospital/pagination', authfilter(false), hospitalController.hospitalPagination);
 // Done
routes.post('/private/hqm/v1/hospital/batch', authfilter(false), hospitalController.getBatch);
// Done
routes.post('/private/hqm/v1/hospital/batchList', authfilter(false), hospitalController.getBatchListUrl);

routes.post('/private/hqm/v1/hospital/getMearureAllocation', authfilter(false), hospitalController.getMearureAllocation);

routes.post('/private/hqm/v1/hospital/getMearureIDs', authfilter(false), hospitalController.getMearureIDs);

routes.post('/private/hqm/v1/hospital/getScaleMearureIDs', authfilter(false), hospitalController.getScaleMearureIDs);

routes.post('/private/hqm/v1/hospital/getScaleRangeDetailsList', authfilter(false), hospitalController.getScaleRangeDetailsList);

routes.post('/private/hqm/v1/hospital/getBothScore', authfilter(false), hospitalController.getBothScore);
routes.post('/private/hqm/v1/hospital/getTableName', authfilter(false), hospitalController.getTableName);

routes.post('/private/hqm/v1/hospital/lifespan/file/upload', authfilter(false), hospitalController.fileUploadLifeSpan);
routes.post('/private/hqm/v1/hospital/lifespan/statusList', authfilter(false), hospitalController.findLifespanDmaList);

routes.post('/private/hqm/v1/hospital/test/file/upload', authfilter(false), fileController.uploadTest);
routes.post('/private/hqm/v1/hospital/test/file/excelupload', authfilter(false), fileController.excelTest);
//done
routes.post('/private/hqm/v1/hospital/getNationalPercentile', authfilter(false),  hospitalController.getNationalPercentile);
// done
routes.post('/private/hqm/v1/hospitalpercentrank/getrank', authfilter(false), hospitalController.hospitalPercentRank);

routes.post('/private/hqm/v1/hospital/batchbyname', authfilter(false), hospitalController.getBatchByName);
routes.post('/private/hqm/v1/hospital/getYearHospitalByBatchName', authfilter(false), hospitalController.getYearHospitalByBatchName);
// Get National Percentile
routes.post('/private/hqm/v1/nationalPercentile/year/get', authfilter(false), hospitalController.getNationalPercentileYear);
//done
routes.post('/private/hqm/v1/nationalPercentile/getMearureIDs', authfilter(false), hospitalController.getNationalPercentileMeasureIDs);
//done
routes.post('/private/hqm/v1/nationalPercentile/getMearureGroup', authfilter(false), hospitalController.getNationalPercentileMeasureGroup);

// user manage
routes.post('/private/hqm/v1/user/pagination', authfilter(false), hospitalController.userPagination);
routes.post('/private/hqm/v1/user/role/getlist', authfilter(false), hospitalController.getRoleList);
// update user
routes.post('/private/hqm/v1/user/update', authfilter(false), hospitalController.updateUser);
// Delete Hospital
routes.post('/private/hqm/v1/user/delete', authfilter(false), hospitalController.deleteUser);
 // Done

routes.post('/private/hqm/v1/delete/batch', authfilter(false), hospitalController.deleteBatch);

exports.routes = routes;

logger.info('Routes loaded successfully...');