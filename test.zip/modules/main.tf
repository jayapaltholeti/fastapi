# Resource Group
data "azurerm_resource_group" "resource_group" {
  name = var.resource_group_name
}
 
# Log Analytics Workspace
data "azurerm_log_analytics_workspace" "log_analytics" {
  name                = var.log_analytics_workspace.name
  resource_group_name = var.log_analytics_workspace.rg_name
}

# Storage Accounts
data "azurerm_storage_account" "storage_account" {
  name                = var.storage_account.name
  resource_group_name = var.storage_account.rg_name
}

data "azurerm_storage_account" "db_storage_account" {
  name                = var.db_storage_account.name
  resource_group_name = var.db_storage_account.rg_name
}
 
# Azure Container Registry (ACR)
data "azurerm_container_registry" "container_registry" {
  name                = var.container_registry.name
  resource_group_name = var.container_registry.rg_name
}

# Azure Container App Environment
data "azurerm_container_app_environment" "app_environment" {
  name                = var.container_app_environment_name
  resource_group_name = var.resource_group_name
}

data "azurerm_user_assigned_identity" "acr_identity" {
  name  = var.acr_identity_name
  resource_group_name = var.resource_group_name
}

data "azurerm_user_assigned_identity" "storage_cms_dev_identity" {
  name                = var.storage_cms_dev_identity_name
  resource_group_name = var.storage_cms_dev_identity_rg
}

data "azurerm_user_assigned_identity"   "sqldb_datadev_identity" {
  name                = var.sqldb_datadev_identity_name
  resource_group_name = var.sqldb_datadev_identity_rg
}

resource "null_resource" "force_recreate" {
  triggers = {
    always_run = timestamp ()
  }
}
 
# Azure Container App
resource "azurerm_container_app" "app" {
  depends_on = [data.azurerm_user_assigned_identity.acr_identity]
  name                         = var.container_app_name
  container_app_environment_id = data.azurerm_container_app_environment.app_environment.id
  resource_group_name          = data.azurerm_resource_group.resource_group.name
  revision_mode                = "Multiple"
   workload_profile_name = "Consumption"
  
  lifecycle {
    ignore_changes = [
      tags,
      template.0.container.0.image
    ]

    #create_before_destroy = false
    replace_triggered_by = [
      null_resource.force_recreate.id
    ]
  }
 
  identity {
    type = "SystemAssigned, UserAssigned"
    identity_ids = [
      data.azurerm_user_assigned_identity.acr_identity.id,
      data.azurerm_user_assigned_identity.storage_cms_dev_identity.id,
      data.azurerm_user_assigned_identity.sqldb_datadev_identity.id
      ]
  }  
 
  template {
    min_replicas = 1
    max_replicas = 5
    container {
      name  = var.container_name
      image = "${data.azurerm_container_registry.container_registry.login_server}/${var.docker_image_name}:${var.docker_image_tag}"
      cpu   = var.cpu
      memory = var.memory    
      dynamic "env" {
        for_each = var.environment_variables
        content {
          name  = env.value.name
          value = env.value.value
        }
      }
    }
  }  
 
  ingress {
    external_enabled = true
    target_port      = 7001
    traffic_weight {
      percentage      = 100
      latest_revision = true
    }
  }
  registry {
    server = data.azurerm_container_registry.container_registry.login_server
    identity = data.azurerm_user_assigned_identity.acr_identity.id
  }
}
