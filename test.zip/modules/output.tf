output "user_assigned_identity_ids" {
  value = azurerm_container_app.app.identity[0].identity_ids
}