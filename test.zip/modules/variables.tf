variable "resource_group" {
  type = object({
    name = string
  })
}

variable "storage_cms_dev_identity_rg" {
  type = string
}

variable "sqldb_datadev_identity_rg" {
  type = string
}


variable "log_analytics_workspace" {
  type = object({
    name    = string
    rg_name = string
  })
}

variable "container_registry" {
  type = object({
    name    = string
    rg_name = string
  })
}

variable "acr_identity_name" {
  description = "The name of the user identity."
  type = string
}

variable "storage_cms_dev_identity_name" {
  type = string
}

variable "sqldb_datadev_identity_name" {
  type = string
}

variable "storage_account" {
  type = object({
    name    = string
    rg_name = string
  })
}

variable "db_storage_account" {
  type = object({
    name    = string
    rg_name = string
  })
}

variable "resource_group_name" {
  description = "resource group name"
  type  = string
}

variable "container_app_environment_name" {
  description = "Name of the Azure Container App Environment"
  type        = string
}

variable "container_app_name" {
  description = "Name of the Azure Container App"
  type        = string
}

variable "container_name" {
  description = "Name of the container"
  type        = string
}

variable "docker_image_name" {
  description = "Name of the Docker image"
  type        = string
}

variable "docker_image_tag" {
  description = "Tag of the Docker image"
  type        = string
  default  = "latest"
  validation {
    condition  = length(var.docker_image_tag) > 0
    error_message = "docker_image_tag must not be empty"
  }
}

variable "environment_variables" {
  description = "List of environment variables for the container app"
  type = list(
    object({
      name  = string
      value = string
    })
  )
}

variable "location" {
  description = "The location where the resources will be created"
  type        = string
  default     = "eastus2" # Set your default Azure region
}

variable "workload_profile" {
  description = "The Workload profile to use for the container app"
  type = string
  default = "Consumption"
}

variable "cpu" {
  description = "cpu allocation for container app"
  type = number
}

variable "memory" {
  description = "memory allocation for container app"
  type = string
}

variable "tags" {
  description = "Tags to assign to the Azure resources"
  type = map(string)
}

#variable "storage_accounts" {
 #type = list(object({
   #name    = string
   #rg_name = string
 #}))
#}


