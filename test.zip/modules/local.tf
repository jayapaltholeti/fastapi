#locals {
  #user_assigned_identity_name = "acr_identity"
  #user_assigned_identity_name_location = "eastus2"
  #user_assigned_identity_resource_group = var.resource_group_name
 #}