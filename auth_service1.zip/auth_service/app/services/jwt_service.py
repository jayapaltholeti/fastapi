# app/services/jwt_service.py
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from jose import jwt, JWTError
import requests
from app.config import settings

# --- Local dev token config ---
LOCAL_SECRET_KEY = settings.SECRET_KEY
ALGORITHM = settings.ALGORITHM
ACCESS_TOKEN_EXPIRE_MINUTES = settings.ACCESS_TOKEN_EXPIRE_MINUTES

# --- Azure AD config ---
AZURE_TENANT_ID = settings.AZURE_TENANT_ID
AZURE_CLIENT_ID = settings.AZURE_CLIENT_ID
AZURE_ISSUER = f"https://login.microsoftonline.com/{AZURE_TENANT_ID}/v2.0"
AZURE_JWKS_URI = f"{AZURE_ISSUER}/discovery/v2.0/keys"

_jwks_cache: Dict[str, Any] = {}

# ------------------------
# Local JWT generator
# ------------------------
def create_access_token(payload: dict, expires_delta: Optional[int] = None) -> str:
    to_encode = payload.copy()
    expire = datetime.utcnow() + timedelta(minutes=expires_delta or ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({"exp": int(expire.timestamp()), "iat": int(datetime.utcnow().timestamp())})
    token = jwt.encode(to_encode, LOCAL_SECRET_KEY, algorithm=ALGORITHM)
    return token

# ------------------------
# Azure AD JWT validation
# ------------------------
def _get_jwks() -> dict:
    global _jwks_cache
    if not _jwks_cache:
        resp = requests.get(AZURE_JWKS_URI)
        resp.raise_for_status()
        _jwks_cache = resp.json()
    return _jwks_cache

def _get_signing_key(token: str) -> dict:
    unverified_header = jwt.get_unverified_header(token)
    kid = unverified_header.get("kid")
    jwks = _get_jwks()
    key = next((k for k in jwks["keys"] if k["kid"] == kid), None)
    if not key:
        _jwks_cache.clear()
        jwks = _get_jwks()
        key = next((k for k in jwks["keys"] if k["kid"] == kid), None)
    if not key:
        raise JWTError(f"Unable to find matching key for kid={kid}")
    return key

def validate_azure_jwt(token: str) -> dict:
    key = _get_signing_key(token)
    try:
        payload = jwt.decode(
            token,
            key,
            algorithms=["RS256"],
            audience=AZURE_CLIENT_ID,
            issuer=AZURE_ISSUER
        )
        return payload
    except JWTError as e:
        raise JWTError(f"Azure AD token validation failed: {str(e)}")

# ------------------------
# Unified decode (strict dev mode)
# ------------------------
def decode_access_token(token: str) -> dict:
    if not token:
        raise JWTError("Missing token")

    header = jwt.get_unverified_header(token)
    alg = header.get("alg")

    if alg == "RS256":
        return validate_azure_jwt(token)

    elif settings.ENV == "dev" and alg == ALGORITHM:
        try:
            payload = jwt.decode(
                token,
                LOCAL_SECRET_KEY,
                algorithms=[ALGORITHM],
                options={"verify_aud": False}  # skip aud check in dev
            )
            return payload
        except JWTError as e:
            raise JWTError(f"Invalid dev token: {str(e)}")


    else:
        raise JWTError("Unsupported or invalid JWT algorithm")
