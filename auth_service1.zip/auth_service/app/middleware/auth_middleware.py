# app/middleware/auth_middleware.py
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request
from fastapi.responses import JSONResponse
from jose import JWTError
from app.services.jwt_service import decode_access_token

EXCLUDE_PATHS = [
    "/docs",
    "/redoc",
    "/openapi.json",
    "/healthz",
    "/auth/dev-token",
    "/auth/login",
    "/auth/callback"
]

class AuthMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        # Skip authentication for excluded paths
        if request.url.path in EXCLUDE_PATHS:
            return await call_next(request)

        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            return JSONResponse(
                {"detail": "Unauthorized: Missing or invalid Authorization header"},
                status_code=401
            )

        token = auth_header.split(" ")[1]

        try:
            # Decode the JWT using your jwt_service
            payload = decode_access_token(token)
            request.state.user = {
                "sub": payload.get("sub"),
                "email": payload.get("email"),
                "roles": payload.get("roles", []),
                "oid": payload.get("oid")  # Optional: for Azure-specific claims
            }
            request.state.claims = payload
        except JWTError as e:
            return JSONResponse(
                {"detail": f"Unauthorized: {str(e)}"},
                status_code=401
            )

        # Proceed to endpoint
        response = await call_next(request)
        return response
