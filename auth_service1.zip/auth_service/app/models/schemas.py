# app/models/schemas.py
from pydantic import BaseModel, EmailStr
from typing import List, Optional

class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: Optional[int] = None

class UserBase(BaseModel):
    id: str
    email: EmailStr
    roles: List[str] = []

class LoginResp(BaseModel):
    message: str
