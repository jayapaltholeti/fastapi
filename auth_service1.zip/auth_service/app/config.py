# app/config.py
from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    ENV: str = "dev"
    HOST: str = "0.0.0.0"
    PORT: int = 8000

    # JWT
    SECRET_KEY: str = "replace-me"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60

    # Database placeholder (optional for now)
    DATABASE_URL: Optional[str] = None

    # OAuth placeholders (not yet configured)
    OAUTH_CLIENT_ID: Optional[str] = None
    OAUTH_CLIENT_SECRET: Optional[str] = None
    OAUTH_AUTHORIZE_URL: Optional[str] = None
    OAUTH_TOKEN_URL: Optional[str] = None
    OAUTH_PROVIDER_NAME: Optional[str] = None
    OAUTH_USERINFO_URL: Optional[str] = None
    OAUTH_SCOPE: Optional[str] = None
    OAUTH_REDIRECT_PATH: Optional[str] = None

    # Azure AD JWT validation
    AZURE_TENANT_ID: Optional[str] = None
    AZURE_CLIENT_ID: Optional[str] = None
    AZURE_ISSUER: Optional[str] = None
    AZURE_JWKS_URI: Optional[str] = None

     # AWS Verified Permissions
    AWS_REGION: Optional[str] = None
    AVP_POLICY_STORE_ID: Optional[str] = None
    AVP_ACTION_TYPE: Optional[str] = None
    AVP_RESOURCE_ENTITY_TYPE: Optional[str] = None
    AVP_PRINCIPAL_ENTITY_TYPE: Optional[str] = None
    
    # Logging
    LOG_LEVEL: str = "INFO"

    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        # Optional: prevents crashes if extra env vars exist
        extra = "ignore"

settings = Settings()

AZURE_VALID_AUDIENCES: list[str] = ["api://your-client-id"]