# app/main.py
from fastapi import FastAPI, Request, HTTPException
from fastapi.openapi.utils import get_openapi
from app.config import settings
from app.logging_config import setup_logging
from app.middleware.auth_middleware import AuthMiddleware
from starlette.middleware.sessions import SessionMiddleware
from app.services.avp_service import check_access
from app.routers.auth import router as auth_router
from app.routers.me import router as me_router
from app.routers.customer import router as customer_router

# --- Logging ---
setup_logging(settings.LOG_LEVEL)

# --- FastAPI app ---
app = FastAPI(title="Secure API: Azure AD + AVP", version="1.0.0")

# --- Middleware ---
app.add_middleware(AuthMiddleware)  # JWT verification
app.add_middleware(SessionMiddleware, secret_key=settings.SECRET_KEY)  # OAuth state storage

# --- Health endpoint ---
@app.get("/healthz", tags=["health"])
def health():
    return {"status": "ok", "env": settings.ENV}

# --- Include routers ---
app.include_router(auth_router, prefix="/auth", tags=["auth"])
app.include_router(me_router, prefix="", tags=["user"])
app.include_router(customer_router, prefix="", tags=["customer"])

# --- Custom OpenAPI with BearerAuth ---
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema

    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        routes=app.routes,
    )

    # Ensure components exist
    openapi_schema.setdefault("components", {})
    openapi_schema["components"].setdefault("securitySchemes", {})

    # Bearer auth scheme
    openapi_schema["components"]["securitySchemes"]["BearerAuth"] = {
        "type": "http",
        "scheme": "bearer",
        "bearerFormat": "JWT",
    }

    # Apply globally
    for path in openapi_schema["paths"].values():
        for method in path.values():
            method.setdefault("security", [{"BearerAuth": []}])

    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi
