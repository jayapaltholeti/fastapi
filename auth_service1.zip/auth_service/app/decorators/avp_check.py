# app/decorators/avp_check.py
from fastapi import HTTPException, Request
from functools import wraps
from app.services.avp_service import check_access

def authorize(action: str, resource_fn=None):
    """
    Decorator to enforce AVP policies.
    `resource_fn` is a callable that takes Request and returns resource dict.
    """
    def decorator(func):
        @wraps(func)
        async def wrapper(*args, **kwargs):
            request: Request = kwargs.get("request")
            if not request:
                # Try to extract from args if not in kwargs
                request = next((arg for arg in args if isinstance(arg, Request)), None)
            if not request:
                raise ValueError("Request object not found in endpoint arguments")

            user = getattr(request.state, "user", None)
            if not user:
                raise HTTPException(status_code=401, detail="Unauthorized")

            # Determine resource
            resource = resource_fn(request) if resource_fn else {"id": "default"}

            # Check AVP policy
            allowed = check_access(user, action, resource)
            if not allowed:
                raise HTTPException(status_code=403, detail="Forbidden by AVP")
            return await func(*args, **kwargs)
        return wrapper
    return decorator
