# app/routers/auth.py
from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse
from authlib.integrations.starlette_client import OAuth
from app.config import settings
from jose import jwt
from datetime import datetime, timedelta, timezone
import logging

logger = logging.getLogger(__name__)
router = APIRouter()

# Initialize OAuth client
oauth = OAuth()

# Flag to check if OAuth is configured properly
OAUTH_CONFIGURED = all([
    settings.OAUTH_CLIENT_ID not in ("", "your-client-id-here"),
    settings.OAUTH_CLIENT_SECRET not in ("", "your-client-secret-here"),
    "{tenant-id}" not in settings.OAUTH_AUTHORIZE_URL
])

if OAUTH_CONFIGURED:
    oauth.register(
        name=settings.OAUTH_PROVIDER_NAME,
        client_id=settings.OAUTH_CLIENT_ID,
        client_secret=settings.OAUTH_CLIENT_SECRET,
        authorize_url=settings.OAUTH_AUTHORIZE_URL,
        access_token_url=settings.OAUTH_TOKEN_URL,
        client_kwargs={"scope": settings.OAUTH_SCOPE},
    )
    logger.info("OAuth provider registered: %s", settings.OAUTH_PROVIDER_NAME)
else:
    logger.warning("OAuth not configured. Login endpoints will return 503.")

# ---------- OAuth endpoints ----------
@router.get("/login")
async def login(request: Request):
    """
    Start OAuth login flow.
    Redirects the user to the OAuth provider's login page.
    """
    if not OAUTH_CONFIGURED:
        raise HTTPException(status_code=503, detail="OAuth not configured. Update .env.")
    
    redirect_uri = str(request.url_for("auth_callback"))
    return await oauth.azure.authorize_redirect(request, redirect_uri)


@router.get("/callback")
async def auth_callback(request: Request):
    """
    OAuth callback handler.
    Exchanges the code for tokens and returns user info.
    """
    if not OAUTH_CONFIGURED:
        raise HTTPException(status_code=503, detail="OAuth not configured. Update .env.")

    try:
        token = await oauth.azure.authorize_access_token(request)
        userinfo = await oauth.azure.parse_id_token(request, token)
        return JSONResponse({"token": token, "userinfo": userinfo})
    except Exception as e:
        logger.exception("OAuth callback failed")
        raise HTTPException(status_code=400, detail=f"Failed to fetch token: {str(e)}")


# ---------- Dev-only endpoint ----------
if settings.ENV.lower() == "dev":
    @router.get("/dev-token")
    def dev_token():
        """
        Generate a fake JWT for local development/testing.
        Only available in DEV environment.
        """
        from datetime import datetime, timedelta, timezone
        now = datetime.now(timezone.utc)
        expire = now + timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)

        payload = {
            "sub": "test-user@example.com",
            "name": "Dev User",
            "roles": ["tester"],
            "iat": int(now.timestamp()),    # integer timestamp
            "exp": int(expire.timestamp()), # integer timestamp
            "aud": "local-client"           # fixed for dev
        }

        token = jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.ALGORITHM)
        return {"access_token": token, "token_type": "bearer"}

