# app/routers/me.py
from fastapi import APIRouter, Request

router = APIRouter(tags=["user"])

@router.get("/me")
async def me(request: Request):
    """
    Returns the authenticated user's identity and JWT claims.
    Assumes AuthMiddleware has validated the token.
    """
    # AuthMiddleware guarantees request.state.user exists in prod
    user = request.state.user
    claims = getattr(request.state, "claims", {})

    return {"user": user, "claims": claims}
