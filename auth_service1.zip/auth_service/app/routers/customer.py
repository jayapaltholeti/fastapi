# app/routers/customer.py
from fastapi import APIRouter, Request, HTTPException
from app.services.avp_service import check_access

router = APIRouter(tags=["customer"])

@router.get("/customer/{customer_id}")
async def get_customer(customer_id: str, request: Request):
    """
    Retrieve customer info if the user has read access.
    AVP policy enforced.
    """
    principal_id = request.state.user.get("oid") or request.state.user.get("sub")
    
    allowed, decision = check_access(principal_id, "readCustomer", {"id": customer_id})
    if not allowed:
        raise HTTPException(
            status_code=403,
            detail="Access denied",
            headers={"X-AVP-Decision": str(decision)}
        )

    # TODO: Replace with actual data fetching logic
    return {"customer_id": customer_id, "data": "Customer info (example)"}


@router.put("/customer/{customer_id}")
async def update_customer(customer_id: str, request: Request):
    """
    Update customer info if the user has update access.
    AVP policy enforced.
    """
    principal_id = request.state.user.get("oid") or request.state.user.get("sub")
    
    allowed, decision = check_access(principal_id, "updateCustomer", {"id": customer_id})
    if not allowed:
        raise HTTPException(
            status_code=403,
            detail="Access denied",
            headers={"X-AVP-Decision": str(decision)}
        )

    # TODO: Replace with actual update logic
    return {"customer_id": customer_id, "result": "updated (example)"}
