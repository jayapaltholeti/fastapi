# app/logging_config.py
import logging
from pythonjsonlogger import jsonlogger
from app.config import settings


def setup_logging(log_level: str = None):
    root = logging.getLogger()
    if not root.handlers:
        handler = logging.StreamHandler()
        fmt = jsonlogger.JsonFormatter('%(asctime)s %(levelname)s %(name)s %(message)s')
        handler.setFormatter(fmt)
        root.addHandler(handler)
    level = log_level.upper() if log_level else settings.LOG_LEVEL.upper()
    root.setLevel(level)