# app/routers/me.py
from fastapi import APIRouter, Request

router = APIRouter(tags=["user"])

@router.get("/me")
async def me(request: Request):
    user = getattr(request.state, "user", None)
    claims = getattr(request.state, "claims", {})

    if not user:
        return {"error": "No authenticated user found"}

    return {"user": user, "claims": claims}

