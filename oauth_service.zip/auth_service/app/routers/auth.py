from fastapi import APIRouter, Request, HTTPException
from fastapi.responses import JSONResponse
from authlib.integrations.starlette_client import OAuth
from app.config import settings
from jose import jwt
import logging
from secrets import token_urlsafe
from fastapi import APIRouter, Request, Depends
from fastapi.responses import RedirectResponse, JSONResponse
from app.services.oauth_service import oauth, provider_name
from app.services.jwt_service import decode_access_token
from jose import JWTError

logger = logging.getLogger(__name__)
router = APIRouter()

oauth = OAuth()

# --- OAuth registration (prod) ---
OAUTH_CONFIGURED = all([
    settings.OAUTH_CLIENT_ID not in ("", "your-client-id-here"),
    settings.OAUTH_CLIENT_SECRET not in ("", "your-client-secret-here"),
    "{tenant-id}" not in settings.OAUTH_AUTHORIZE_URL
])

if OAUTH_CONFIGURED:
    oauth.register(
        name=settings.OAUTH_PROVIDER_NAME,
        client_id=settings.OAUTH_CLIENT_ID,
        client_secret=settings.OAUTH_CLIENT_SECRET,
        server_metadata_url=f"https://login.microsoftonline.com/{settings.AZURE_TENANT_ID}/v2.0/.well-known/openid-configuration",
        client_kwargs={"scope": settings.OAUTH_SCOPE or "openid profile email"},
    )
    logger.info("OAuth provider registered: %s", settings.OAUTH_PROVIDER_NAME)
else:
    logger.warning("OAuth not configured. Login endpoints will return 503.")

# --- Login endpoint ---
@router.get("/login")
async def login(request: Request):
    if not OAUTH_CONFIGURED:
        raise HTTPException(status_code=503, detail="OAuth not configured. Update .env.")
    
    state = token_urlsafe(16)
    request.session["oauth_state"] = state

    redirect_uri = f"http://localhost:8000{settings.OAUTH_REDIRECT_PATH}"
    client = oauth.create_client(settings.OAUTH_PROVIDER_NAME)

    return await client.authorize_redirect(request, redirect_uri, state=state)


# --- Callback endpoint ---
@router.get("/callback")
async def auth_callback(request: Request):
    try:
        client = oauth.create_client(provider_name)

        # Exchange code for token
        token = await client.authorize_access_token(request)

        # Extract id_token claims
        id_token_claims = {}
        if "id_token" in token:
            try:
                id_token_claims = decode_access_token(token["id_token"])
            except JWTError:
                # Fallback to Authlib parsing if jose fails
                id_token_claims = await client.parse_id_token(request, token)

        # Try userinfo endpoint (optional in Azure)
        userinfo = {}
        try:
            userinfo = await client.userinfo(token)
        except Exception:
            userinfo = {}

        # Merge info (id_token first, then userinfo to fill gaps)
        user = {
            "sub": id_token_claims.get("sub") or userinfo.get("sub"),
            "email": id_token_claims.get("email") or userinfo.get("email"),
            "name": id_token_claims.get("name") or userinfo.get("name"),
            "oid": id_token_claims.get("oid"),  # Azure AD object ID
            "roles": id_token_claims.get("roles", []),  # if app roles enabled
        }

        # Store user in session if you use sessions (optional)
        request.session["user"] = user

        return JSONResponse({"user": user, "token": token})

    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=400)