# app/routers/customer.py
from fastapi import APIRouter, Request
from app.decorators.avp_check import authorize

router = APIRouter(tags=["customer"])

@router.get("/customer/{customer_id}")
@authorize(
    action="readCustomer",
    resource_fn=lambda req: {"id": req.path_params["customer_id"]}
)
async def get_customer(customer_id: str, request: Request):
    """
    Retrieve customer info if the user has read access.
    AVP policy enforced by decorator.
    """
    return {"customer_id": customer_id, "data": "Customer info (example)"}


@router.put("/customer/{customer_id}")
@authorize(
    action="updateCustomer",
    resource_fn=lambda req: {"id": req.path_params["customer_id"]}
)
async def update_customer(customer_id: str, request: Request):
    """
    Update customer info if the user has update access.
    AVP policy enforced by decorator.
    """
    # TODO: Replace with actual update logic
    return {"customer_id": customer_id, "result": "updated (example)"}
