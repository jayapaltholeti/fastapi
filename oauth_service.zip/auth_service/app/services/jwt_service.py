# app/services/jwt_service.py
from datetime import datetime, timedelta
from typing import Optional, Dict, Any
from jose import jwt, JWTError
import requests
import logging
from app.config import settings
from time import time

logger = logging.getLogger(__name__)

# --- Local dev token config ---
LOCAL_SECRET_KEY = settings.SECRET_KEY
ALGORITHM = settings.ALGORITHM
ACCESS_TOKEN_EXPIRE_MINUTES = settings.ACCESS_TOKEN_EXPIRE_MINUTES

# --- Azure AD config ---
AZURE_TENANT_ID = settings.AZURE_TENANT_ID
AZURE_CLIENT_ID = settings.AZURE_CLIENT_ID
AZURE_ISSUER = f"https://login.microsoftonline.com/{AZURE_TENANT_ID}/v2.0"
AZURE_JWKS_URI = f"https://login.microsoftonline.com/{AZURE_TENANT_ID}/discovery/v2.0/keys"

_jwks_cache: Dict[str, Any] = {}
_jwks_cache_expiry: float = 0
_JWKS_TTL_SECONDS = 24 * 3600  # 24h

# ------------------------
# Local JWT generator
# ------------------------
def create_access_token(payload: dict, expires_delta: Optional[int] = None) -> str:
    """
    Create a JWT (dev or internal use) with optional expiration.
    """
    to_encode = payload.copy()
    expire = datetime.utcnow() + timedelta(minutes=expires_delta or ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode.update({
        "exp": int(expire.timestamp()),
        "iat": int(datetime.utcnow().timestamp()),
        "nbf": int(datetime.utcnow().timestamp())
    })
    token = jwt.encode(to_encode, LOCAL_SECRET_KEY, algorithm=ALGORITHM)
    return token

# ------------------------
# Azure AD JWT validation
# ------------------------
def _get_jwks() -> dict:
    global _jwks_cache, _jwks_cache_expiry
    if not _jwks_cache or time() > _jwks_cache_expiry:
        logger.info("Fetching JWKS from Azure AD")
        resp = requests.get(AZURE_JWKS_URI, timeout=5)
        resp.raise_for_status()
        _jwks_cache = resp.json()
        _jwks_cache_expiry = time() + _JWKS_TTL_SECONDS
    return _jwks_cache

def _get_signing_key(token: str) -> dict:
    unverified_header = jwt.get_unverified_header(token)
    kid = unverified_header.get("kid")
    jwks = _get_jwks()
    key = next((k for k in jwks["keys"] if k["kid"] == kid), None)

    # Retry if key not found
    if not key:
        logger.warning("Key not found, refreshing JWKS cache")
        _jwks_cache.clear()
        jwks = _get_jwks()
        key = next((k for k in jwks["keys"] if k["kid"] == kid), None)

    if not key:
        raise JWTError(f"Unable to find matching key for kid={kid}")
    return key

def validate_azure_jwt(token: str) -> dict:
    """
    Validate Azure AD RS256 JWT.
    """
    key = _get_signing_key(token)
    try:
        payload = jwt.decode(
            token,
            key,
            algorithms=["RS256"],
            audience=AZURE_CLIENT_ID,
            issuer=AZURE_ISSUER,
        )
        logger.debug("Azure AD token validated for sub=%s", payload.get("sub"))
        return payload
    except JWTError as e:
        logger.error("Azure AD token validation failed: %s", str(e))
        raise JWTError(f"Azure AD token validation failed: {str(e)}")

# ------------------------
# Unified decode
# ------------------------
def decode_access_token(token: str) -> dict:
    if not token:
        raise JWTError("Missing token")
    header = jwt.get_unverified_header(token)
    alg = header.get("alg")

    if alg == "RS256":
        return validate_azure_jwt(token)
    elif settings.ENV == "dev" and alg == ALGORITHM:
        try:
            payload = jwt.decode(
                token,
                LOCAL_SECRET_KEY,
                algorithms=[ALGORITHM],
                options={"verify_aud": False}  # dev mode
            )
            logger.debug("Dev token decoded for sub=%s", payload.get("sub"))
            return payload
        except JWTError as e:
            raise JWTError(f"Invalid dev token: {str(e)}")
    else:
        raise JWTError("Unsupported or invalid JWT algorithm")

# ------------------------
# App-issued JWT
# ------------------------
def create_app_token(userinfo: dict, roles: list[str], expires_minutes: Optional[int] = None) -> str:
    payload = {
        "sub": userinfo.get("sub") or userinfo.get("oid"),
        "email": userinfo.get("email"),
        "name": userinfo.get("name"),
        "roles": roles,
        "iat": int(datetime.utcnow().timestamp()),
        "nbf": int(datetime.utcnow().timestamp()),
        "exp": int((datetime.utcnow() + timedelta(minutes=expires_minutes or ACCESS_TOKEN_EXPIRE_MINUTES)).timestamp())
    }
    return create_access_token(payload)
