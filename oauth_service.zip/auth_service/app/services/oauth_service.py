# app/services/oauth_service.py
from authlib.integrations.starlette_client import OAuth
from fastapi import Request
from fastapi.responses import RedirectResponse
from app.config import settings

oauth = OAuth()
provider_name = settings.OAUTH_PROVIDER_NAME or "entrea"

# Dev-mode flag
USE_DEV_MOCK = settings.ENV == "dev" and not settings.OAUTH_CLIENT_ID

if USE_DEV_MOCK:
    print("⚠️ Using mock OAuth provider (dev mode)")

    async def mock_authorize_redirect(*args, **kwargs):
        redirect_uri = kwargs.get("redirect_uri")
        if isinstance(redirect_uri, Request):
            redirect_uri = str(redirect_uri.url)
        if not redirect_uri:
            redirect_uri = "/auth/callback"
        return RedirectResponse(url=redirect_uri + "?code=fake-code")

    async def mock_authorize_access_token(*args, **kwargs):
        return {
            "access_token": "fake-access-token",
            "id_token": "fake-id-token",
            "userinfo": {"sub": "dev-user", "email": "dev@example.com"}
        }

    async def mock_parse_id_token(*args, **kwargs):
        return {"sub": "dev-user", "email": "dev@example.com"}

    class MockClient:
        authorize_redirect = mock_authorize_redirect
        authorize_access_token = mock_authorize_access_token
        parse_id_token = mock_parse_id_token

        async def userinfo(self, token):
            return {"sub": "dev-user", "email": "dev@example.com"}

    oauth.create_client = lambda name: MockClient()

else:
    if settings.OAUTH_CLIENT_ID and settings.OAUTH_CLIENT_SECRET:
        oauth.register(
            name=provider_name,
            client_id=settings.OAUTH_CLIENT_ID,
            client_secret=settings.OAUTH_CLIENT_SECRET,
            server_metadata_url=f"https://login.microsoftonline.com/{settings.AZURE_TENANT_ID}/v2.0/.well-known/openid-configuration",
            client_kwargs={"scope": settings.OAUTH_SCOPE or "openid profile email"},
        )
