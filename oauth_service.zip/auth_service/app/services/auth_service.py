# app/services/auth_service.py
from typing import List, Optional
import logging
from app.config import settings

logger = logging.getLogger(__name__)

# In-memory roles for quick dev/admin use (override with DB in prod)
_DEFAULT_ROLES = {
    "admin@example.com": ["admin"],
}

def get_roles_for_user(user_id: str) -> List[str]:
    """
    Retrieve roles for a user.
    In production, replace with DB or AVP integration.
    """
    roles = _DEFAULT_ROLES.get(user_id)
    if roles:
        logger.debug("Found roles for user %s: %s", user_id, roles)
        return roles

    # Default fallback role
    return ["user"]

def add_role_for_user(user_id: str, role: str):
    """
    Add a role dynamically (only in-memory, useful for dev/testing).
    """
    if user_id not in _DEFAULT_ROLES:
        _DEFAULT_ROLES[user_id] = []
    if role not in _DEFAULT_ROLES[user_id]:
        _DEFAULT_ROLES[user_id].append(role)
        logger.info("Added role '%s' for user %s", role, user_id)
