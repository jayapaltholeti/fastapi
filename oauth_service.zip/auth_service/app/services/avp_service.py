# app/services/avp_service.py
import boto3
from app.config import settings

# Create Verified Permissions client with explicit region
client = boto3.client(
    "verifiedpermissions",
    region_name=settings.AWS_REGION
)

def check_access(principal: dict, action: str, resource: dict) -> tuple[bool, str]:
    """
    Call AWS Verified Permissions to check if the principal is allowed
    to perform the action on the resource.
    Returns (allowed: bool, decision: str)
    """
    try:
        response = client.is_authorized(
            policyStoreId=settings.AVP_POLICY_STORE_ID,
            principal={
                "entityType": settings.AVP_PRINCIPAL_ENTITY_TYPE,
                "identifier": principal["sub"]
            },
            action={
                "actionType": settings.AVP_ACTION_TYPE,
                "actionId": action
            },
            resource={
                "entityType": settings.AVP_RESOURCE_ENTITY_TYPE,
                "identifier": resource.get("id"),
                **resource
            }
        )
        allowed = response.get("isAuthorized", False)
        decision = response.get("decision", "unknown")  # add some dummy info if AWS response lacks it
        return allowed, decision
    except Exception as e:
        print(f"AVP check failed: {str(e)}")
        return False, "error"
