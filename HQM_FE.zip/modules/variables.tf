
variable "resource_group_name" {
 description = "Resource group name where container app exists"
 type        = string
}
variable "container_app_environment_name" {
 description = "Name of the Azure Container App Environment"
 type        = string
}
variable "container_app_name" {
 description = "Name of the Azure Container App"
 type        = string
}
variable "container_name" {
 description = "Name of the container"
 type        = string
}
variable "docker_image_name" {
 description = "Name of the Docker image"
 type        = string
}
variable "docker_image_tag" {
 description = "Tag of the Docker image"
 type        = string
 default     = "latest"
 validation {
   condition     = length(var.docker_image_tag) > 0
   error_message = "docker_image_tag must not be empty"
 }
}
variable "container_registry" {
 type = object({
   name    = string
   rg_name = string
 })
}
variable "acr_identity_name" {
 description = "User Assigned Identity used for ACR pull"
 type        = string
}
variable "log_analytics_workspace" {
 type = object({
   name    = string
   rg_name = string
 })
}

variable "storage_account" {
 type = object({
   name    = string
   rg_name = string
 })
}
variable "db_storage_account" {
 type = object({
   name    = string
   rg_name = string
 })
}
variable "storage_cms_dev_identity_name" {
 type = string
}
variable "sqldb_datadev_identity_name" {
 type = string
}
variable "cpu" {
 description = "CPU allocation for container app"
 type        = number
}
variable "memory" {
 description = "Memory allocation for container app"
 type        = string
}
variable "min_replicas" {
 type    = number
 default = 1
}
variable "max_replicas" {
 type    = number
 default = 5
}
variable "target_port" {
 description = "Container listening port"
 type        = number
 default     = 8080
}
variable "external_enabled" {
 type    = bool
 default = true
}
variable "environment_variables" {
 description = "List of environment variables for the container app"
 type = list(object({
   name  = string
   value = string
 }))
 default = []
}
variable "enable_custom_domain" {
 description = "Enable custom domain mapping for Container App"
 type        = bool
 default     = false
}
variable "custom_domain_name" {
 description = "Custom domain hostname (example: api.qa.company.com)"
 type        = string
 default     = null
}
variable "key_vault_id" {
 description = "Key Vault resource ID (can be in different RG)"
 type        = string
 default     = null
}
variable "key_vault_certificate_name" {
 description = "Certificate name stored in Key Vault"
 type        = string
 default     = null
}
variable "cert_reader_identity_name" {
 description = "UAMI that has access to Key Vault certificate secret"
 type        = string
 default     = null
}
variable "tags" {
 description = "Tags applied to resources"
 type        = map(string)
 default     = {}
}
variable "acr_identity_rg_name" {
 type        = string
 description = "Resource group for ACR user-assigned identity"
}
variable "storage_cms_dev_identity_rg_name" {
 type        = string
 description = "Resource group for Storage CMS Dev identity"
}
variable "sqldb_datadev_identity_rg_name" {
 type        = string
 description = "Resource group for SQL DB Data Dev identity"
}
variable "cert_reader_identity_rg_name" {
 type        = string
 description = "Resource group for cert reader identity"
}

variable "key_vault_name" {
  type = string
}

variable "key_vault_rg_name" {
  type = string
}
variable "kv_pfx_secret_name" {
  type = string
}

