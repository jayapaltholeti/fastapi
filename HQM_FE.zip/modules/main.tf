############################
# Existing resources (Data)
############################
data "azurerm_resource_group" "rg" {
 name = var.resource_group_name
}
data "azurerm_container_app_environment" "env" {
 name                = var.container_app_environment_name
 resource_group_name = var.resource_group_name
}
data "azurerm_container_registry" "acr" {
 name                = var.container_registry.name
 resource_group_name = var.container_registry.rg_name
}
############################
# Managed Identities (Data)
############################
# ACR pull identity (used in registry block)
data "azurerm_user_assigned_identity" "acr_identity" {
 name                = var.acr_identity_name
 resource_group_name = var.acr_identity_rg_name
}
# Optional/extra identities attached to the Container App (if you have them)
data "azurerm_user_assigned_identity" "storage_identity" {
 count               = (var.storage_cms_dev_identity_name != null && var.storage_cms_dev_identity_rg_name != null) ? 1 : 0
 name                = var.storage_cms_dev_identity_name
 resource_group_name = var.storage_cms_dev_identity_rg_name
}
data "azurerm_user_assigned_identity" "sqldb_identity" {
 count               = (var.sqldb_datadev_identity_name != null && var.sqldb_datadev_identity_rg_name != null) ? 1 : 0
 name                = var.sqldb_datadev_identity_name
 resource_group_name = var.sqldb_datadev_identity_rg_name
}
locals {
 container_app_identity_ids = compact(concat(
   [data.azurerm_user_assigned_identity.acr_identity.id],
   data.azurerm_user_assigned_identity.storage_identity[*].id,
   data.azurerm_user_assigned_identity.sqldb_identity[*].id
 ))
 cae_cert_name = "${replace(var.custom_domain_name, ".", "-")}-cert"
}
############################
# Key Vault (Data)
############################
# You can provide either:
#  - var.key_vault_id (ARM resource ID), OR
#  - var.key_vault_name + var.key_vault_rg_name
data "azurerm_key_vault" "kv" {
 count               = (var.enable_custom_domain && (var.key_vault_id == null || var.key_vault_id == "")) ? 1 : 0
 name                = var.key_vault_name
 resource_group_name = var.key_vault_rg_name
}
locals {
 resolved_key_vault_id = (
   var.key_vault_id != null && var.key_vault_id != ""
   ? var.key_vault_id
   : try(data.azurerm_key_vault.kv[0].id, null)
 )
}
# Read the PFX from Key Vault *Secret*
# IMPORTANT: The secret value must be base64(PFX bytes).
data "azurerm_key_vault_secret" "pfx" {
 count        = var.enable_custom_domain ? 1 : 0
 name         = var.kv_pfx_secret_name
 key_vault_id = local.resolved_key_vault_id
}
############################################
# Import cert into Container Apps Environment
############################################
# Passwordless PFX => certificate_password = ""
resource "azurerm_container_app_environment_certificate" "tls" {
 count = var.enable_custom_domain ? 1 : 0
 name                         = local.cae_cert_name
 container_app_environment_id = data.azurerm_container_app_environment.env.id
 certificate_blob_base64 = data.azurerm_key_vault_secret.pfx[0].value
 certificate_password    = "" # <-- passwordless PFX
}
############################
# Force recreate helper
############################
resource "null_resource" "force_recreate" {
 triggers = {
   always_run = timestamp()
 }
}
############################
# Azure Container App
############################
resource "azurerm_container_app" "app" {
 name                         = var.container_app_name
 resource_group_name          = data.azurerm_resource_group.rg.name
 container_app_environment_id = data.azurerm_container_app_environment.env.id
 revision_mode                = "Multiple"
 workload_profile_name = "Consumption"
 lifecycle {
   ignore_changes = [
     tags,
     template[0].container[0].image
   ]
   # MUST be inside lifecycle
   replace_triggered_by = [
null_resource.force_recreate.id
   ]
 }
 identity {
   type         = length(local.container_app_identity_ids) > 0 ? "SystemAssigned, UserAssigned" : "SystemAssigned"
   identity_ids = local.container_app_identity_ids
 }
 registry {
   server   = data.azurerm_container_registry.acr.login_server
   identity = data.azurerm_user_assigned_identity.acr_identity.id
 }
 template {
   min_replicas = var.min_replicas
   max_replicas = var.max_replicas
   container {
     name   = var.container_name
     image  = "${data.azurerm_container_registry.acr.login_server}/${var.docker_image_name}:${var.docker_image_tag}"
     cpu    = var.cpu
     memory = var.memory
     dynamic "env" {
       for_each = var.environment_variables
       content {
         name  = env.value.name
         value = env.value.value
       }
     }
   }
 }
 ingress {
   external_enabled = true
   target_port      = 80
   traffic_weight {
     percentage      = 100
     latest_revision = true
   }
   # Optional custom domain + TLS binding
   #dynamic "custom_domain" {
     #for_each = var.enable_custom_domain ? [1] : []
     #content {
       #name                     = var.custom_domain_name
       #certificate_binding_type = "SniEnabled" # correct attribute name
       #certificate_id           = azurerm_container_app_environment_certificate.tls[0].id
     #}
   #}
 }
 tags = var.tags
}
resource "azurerm_container_app_custom_domain" "custom_domain" {
  count        = var.enable_custom_domain ? 1 : 0
  container_app_id = azurerm_container_app.app.id
  name         = var.custom_domain_name
  # Correct attribute name:
  container_app_environment_certificate_id = azurerm_container_app_environment_certificate.tls[0].id
  certificate_binding_type = "SniEnabled"
}
