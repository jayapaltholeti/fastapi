terraform {
  backend "azurerm" {}

  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = ">= 4.6.0"
    }
    null = {
      source  = "hashicorp/null"
      version = ">= 3.1.0"
    }
  }
}

provider "azurerm" {
    features {}
    
  #  subscription_id   = "50a22a18-aba4-43cf-b315-cc4b3a1e70ee"
  #  tenant_id         = "2c93d3cb-f285-49c4-8265-fba1bd1fe468"
  #  client_id         = "3da4d6b9-9aaa-4d72-aaab-a2b0fc559301"
  #  client_secret     = "wMg8Q~e5EQU9nwijmiQv5tqBmZcuqrhOrC3jpc-3"

}