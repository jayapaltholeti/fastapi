$(document).ready(function () {


});
function likelihood_of_Conversion() {

	var checkList = document.getElementById('likelihood_of_Conversion_list');
	if (checkList.classList.contains('visible'))
		checkList.classList.remove('visible');
	else
		checkList.classList.add('visible');

}


function State_list() {

	var checkList = document.getElementById('State_list');
	if (checkList.classList.contains('visible'))
		checkList.classList.remove('visible');
	else
		checkList.classList.add('visible');

}
function City_list() {

	var checkList = document.getElementById('City_list');
	if (checkList.classList.contains('visible'))
		checkList.classList.remove('visible');
	else
		checkList.classList.add('visible');

}
function Zipcode_list() {

	var checkList = document.getElementById('Zipcode_list');
	if (checkList.classList.contains('visible'))
		checkList.classList.remove('visible');
	else
		checkList.classList.add('visible');

}
function Income_list() {

	var checkList = document.getElementById('Income_list');
	if (checkList.classList.contains('visible'))
		checkList.classList.remove('visible');
	else
		checkList.classList.add('visible');

}

function Next() {
	var index;
	var month = document.getElementById("month");
	var options = month.getElementsByTagName("option")
	for (var i = 0; i < options.length; i++) {
		if (options[i].selected) {
			index = i;
		}
	}
	index = index + 1;
	if (index >= month.length) {
		//alert('Last record reached')
	}
	else {
		month.value = month[index].value;
	}

}
function Previous() {
	var index;
	var month = document.getElementById("month");
	var options = month.getElementsByTagName("option")
	for (var i = 0; i < options.length; i++) {
		if (options[i].selected) {
			index = i;
		}
	}
	index = index - 1;

	if (index <= -1) {
		// alert('First record reached')
	}
	else {
		month.value = month[index].value;
	}
}

function select_file() {

	var month = document.getElementById("select_month").value;
	var file_type = document.getElementById("file_type").value;
	var file = document.getElementById("file").value;
	var submit_button = document.getElementById("submit_button");
	var msg = document.getElementById("msg");
	if (month !== "" && file_type !== "" && file !== "") {


		submit_button.style.display = "inline-block";
		msg.style.display = "none";
	}
	else {
		submit_button.style.display = "none";
		msg.style.display = "inline-block";

	}

}

function on_upload_click() {

	document.getElementById("msg").innerHTML = "";
	document.getElementById("msg").style.display = "inline-block";
	document.getElementById("submit_button").style.display = 'none';

	document.getElementById("msg").innerHTML += "<span>Uploaded Successfully.</span>";

	document.getElementById("process_button").classList.remove("btn-solid");
	document.getElementById("process_button").classList.add("btn-blue");

	setTimeout(function () {
		document.getElementById('msg').style.display = 'none';
		document.getElementById("loader").innerHTML = "";
	}, 5000);

}

function on_push_to_salesforce_click() {
	document.getElementById("push_to_salesforce").style.display = 'none';
	document.getElementById("msg").innerHTML = "";
	document.getElementById("msg").style.display = "inline-block";
	document.getElementById("msg").innerHTML += "<span> Pushed to Salesforce Successfully.</span>";
}
function checkAll_likelihood_of_Conversion(ele) {
	const checkboxes = document.getElementsByName('likelihood_of_conversion');
	const isChecked = ele.checked;

	for (let i = 0; i < checkboxes.length; i++) {
		if (checkboxes[i].type === 'checkbox') {
			checkboxes[i].checked = isChecked;
		}
	}
}



function checkAll_State(ele) {
	const checkboxes = document.getElementsByName('state');
	const isChecked = ele.checked;

	for (let i = 0; i < checkboxes.length; i++) {
		if (checkboxes[i].type === 'checkbox') {
			checkboxes[i].checked = isChecked;
		}
	}
}

function checkAll_Cities(ele) {
  const checkboxes = document.getElementsByName('city');
  const isChecked = ele.checked;

  for (let i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].type === 'checkbox') {
      checkboxes[i].checked = isChecked;
    }
  }
}

function checkAll_zipcodes(ele) {
  const checkboxes = document.getElementsByName('zip_code');
  const isChecked = ele.checked;

  for (let i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].type === 'checkbox') {
      checkboxes[i].checked = isChecked;
    }
  }
}

function checkAll_Income(ele) {
  const checkboxes = document.getElementsByName('income');
  const isChecked = ele.checked;

  for (let i = 0; i < checkboxes.length; i++) {
    if (checkboxes[i].type === 'checkbox') {
      checkboxes[i].checked = isChecked;
    }
  }
}

function GetIframeURL(data) {
  const dataArr = data.split(',');
  const url = dataArr[0];
  const theIframe = document.getElementById('ttt');
  theIframe.src = url;
}
