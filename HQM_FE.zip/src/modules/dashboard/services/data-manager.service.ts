import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';


import { ResDataModal } from '../containers/view-grid/resDataModal';

@Injectable({
  providedIn: 'root'
})
export class DataManagerService {

  apiUrl = 'https://reqres.in/api/users?page=1';

  httpHeaders?: HttpHeaders;
  constructor(private readonly httpClient: HttpClient, private readonly router: Router) { }

  setHeader() {
    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
    }
    this.httpHeaders = new HttpHeaders().set('Accept', 'application/json'); 
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Origin', '20.124.91.34');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    this.httpHeaders = this.httpHeaders.append("Authorization", 'Bearer ' + sessionStorage.getItem("token"));
  }

  getRequest(url: string): Observable<any> {
    this.setHeader();
    return this.httpClient.get(url, { headers: this.httpHeaders, withCredentials: true });
  }

  postRequest(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }

  getData(): Observable<ResDataModal> {
     this.setHeader();
    return this.httpClient.get<ResDataModal>(this.apiUrl, { headers: this.httpHeaders, withCredentials: true });
  }

}
