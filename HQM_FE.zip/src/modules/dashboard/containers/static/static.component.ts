import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';

@Component({
    selector: 'sb-static',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './static.component.html',
    styleUrls: ['static.component.scss'],
    standalone: false
})
export class StaticComponent implements OnInit {
    constructor() {}
    ngOnInit() { /* TODO document why this method 'ngOnInit' is empty */ }
}
