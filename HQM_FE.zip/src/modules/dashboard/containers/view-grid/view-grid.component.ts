//added for select box
import { FormBuilder, FormGroup } from '@angular/forms';
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { DataManagerService } from '../../services/data-manager.service';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';
import { NgbDatepickerNavigateEvent } from '@ng-bootstrap/ng-bootstrap';
import { Options } from '@angular-slider/ngx-slider';
const APIEndpoint = environment.APIEndpoint;
class Person {
  id?: number;
  firstName?: string;
  lastName?: string;
}
class DataTablesResponse {
  data?: any[];
  draw?: number;
  recordsFiltered?: number;
  recordsTotal?: number;
}
@Component({
  selector: 'sb-view-grid',
  templateUrl:   './view-grid.component.html',
  standalone: false
})
export class ViewGridComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, { static: false })
  dtElement?: DataTableDirective;

  errorMessage: boolean = false;
  successMessage: boolean = false;
  errorMessageText?: string;
  successMessageText?: string;
  waitMessage: boolean = false;
  waitMessageText?: string;
  isSubmitBtnDisabled: boolean = false;
  dtTrigger: Subject<void> = new Subject<void>();
  public serverEndPoint = APIEndpoint;
  getIntTableUrl: string = "";
  totalPushToSalesForce: string = "";
  userId: string = "";

  minValue: number = 16;
  maxValue: number = 100;
  options: Options = {
    floor: 1,
    ceil: 120
  };

  currentYear: number = new Date().getFullYear();

  fileObject: any = {
    fileMonth: new Date().getMonth() + 1,
    fileYear: new Date().getFullYear(),
    state: [],
    city: [],
    income: [],
    zipcode: [],
    age: { min: 16, max: 120 },
    integratedLead: [],
    isChecked: false,
    isCheckedLeadsAll: false,
    token: ""
  };

  paginationCount?: number;

  // Dropdown 
  myForm?: FormGroup;
  disabled = false;
  ShowFilter = true;
  limitSelection = false;
  selectedItems?: any[];
  dropdownSettings: any = {};

  getCityListUrl: string = "";
  getStateListUrl: string = "";
  getZipcodeListUrl: string = "";
  getIncomeListUrl: string = "";
  getAgeListUrl: string = "";
  pushToSalesForceUrl: string = "";
  checkboxSelectAllUrl: string = "";

  cities?: any[];
  stats?: any[];
  zipcodes?: any[];
  income?: any[];
  // age?: any[];


  dtOptions: DataTables.Settings = {};
  persons?: Person[];
  public constructor(private readonly router: Router, private readonly dataManager: DataManagerService, private readonly activatedRoute: ActivatedRoute, private readonly http: HttpClient, private readonly fb: FormBuilder) {
    this.activatedRoute.params.subscribe(params => {
      if (params.month != undefined) {
        this.fileObject.fileMonth = params.month;
        this.fileObject.fileYear = params.year;
        console.log("URL Month ", this.fileObject);
      }
    })
  }

  public ngOnInit(): void {

    let input = "age: 28, favorite number: 26, \"salary: $1,234,108\"";
    let splits = input.split(",(?=([^\"]\"[^\"]\")[^\"]$)");


    console.log(splits, "-------------------------------------");



    let currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
    this.userId = currentUser.id
    this.fileObject.token = 'Bearer ' + sessionStorage.getItem("token")
    //API urls
    this.getCityListUrl = this.serverEndPoint + "/rest/private/dma/v1/user/files/city";
    this.getStateListUrl = this.serverEndPoint + "/rest/private/dma/v1/user/files/state";
    this.getZipcodeListUrl = this.serverEndPoint + "/rest/private/dma/v1/user/files/zipcode";
    this.getIncomeListUrl = this.serverEndPoint + "/rest/private/dma/v1/user/files/income";
    this.getAgeListUrl = this.serverEndPoint + "/rest/private/dma/v1/user/files/age";
    this.pushToSalesForceUrl = this.serverEndPoint + "/rest/private/dma/v1/insertsaleforcedata";
    this.checkboxSelectAllUrl = this.serverEndPoint + "/rest/private/dma/v1/user/files/selectAllRow";



    this.fileObject.state = [];
    this.fileObject.city = [];
    this.fileObject.income = [];
    this.fileObject.zipcode = [];

    //call api
    this.getCityList();
    this.getStateList();
    this.getZipcodeList();
    this.getIncomeList();

    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: this.ShowFilter
    };

    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
    }
    console.log("Calling init function...");
    this.getIntTableUrl = this.serverEndPoint + "/rest/private/dma/v1/table/pagination";
    console.log("API URl...", this.getIntTableUrl);
    const that = this;
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      responsive: true,
      dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
      searching: true,
      language: {
        /* paginate: {
            previous: "<i class='fa fa-angle-left arrow left' aria-hidden='true'></i>",
            next: "<i class='fa fa-angle-right arrow right' aria-hidden='true'></i>"
          }*/
      },
    };
    this.dtOptions = {
      //  Type : { previous: String, next: String },
      pagingType: 'full_numbers',
      language: {
        // paginate: {
        //   previous: "<i class='fa fa-angle-left' aria-hidden='true'></i>",
        //   next: "<i class='fa fa-angle-right' aria-hidden='true'></i>"
        // }
      },
      pageLength: 10,
      scrollY: '400',
      scrollX: true,
      serverSide: true,
      processing: true,
      // dom: '<"top"i>rt<"bottom"flp><"clear">',
      dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
      searching: false,
      ajax: (dataTablesParameters: any, callback: DataTablesAjaxCallback) => {
        dataTablesParameters['dateObject'] = this.fileObject;
        that.http
          .post<DataTablesResponse>(
            this.getIntTableUrl,
            dataTablesParameters, {}
          ).subscribe(resp => {
            let updatedResponse = (this.selectRow(resp.data));
            that.persons = updatedResponse;
            let totalcount = resp.recordsTotal;
            this.paginationCount = totalcount;
            console.log(totalcount, "pagination total row..........................");
            if (typeof this.fileObject.integratedLead != "undefined" && this.fileObject.integratedLead?.length != null && this.fileObject.integratedLead.length > 0) {
              console.log(this.fileObject.integratedLead.length, "totalcount  true....................................................");
              this.isSubmitBtnDisabled = false;
              this.totalPushToSalesForce = "Push " + this.fileObject.integratedLead.length + " Selected To SalesForce";
            } else {
              this.isSubmitBtnDisabled = true;
              this.totalPushToSalesForce = "No leads Selected To Push";
            }

            callback({
              recordsTotal: resp.recordsTotal,
              recordsFiltered: resp.recordsFiltered,
              data: []
            });
          });
      },
      columns: [{ data: 'isSelected' }, { data: 'integreted_id' }, { data: 'MAD_ID' },
      { data: 'first_name' },
      { data: 'middle_initial' },
      { data: 'dobview' },
      { data: 'address_line1' },
      { data: 'city' },
      { data: 'state' },
      { data: 'zip_code' },
      { data: 'income' },
      { data: 'phone' },
      { data: 'member_email' },
      { data: 'MAD_Data_Source' }
      ]
    };
  }


  // Push to Sales force

  pushToSalesForce() {
    this.errorMessage = false;
    this.successMessage = false;
    this.waitMessage = true;
    this.waitMessageText = "Please Wait.. Leads Are Exporting Into Salesforce..!";
    this.isSubmitBtnDisabled = true;
    this.fileObject.userId = this.userId;
    console.log("inside pushToSalesForce", this.fileObject);
    this.dataManager.postRequest(this.pushToSalesForceUrl, this.fileObject)
      .subscribe((response: any) => {
        console.log(" pushToSalesForce response", response);
        this.ngOnInit();
        this.waitMessage = false;
        this.errorMessage = false;
        this.successMessage = true;
        this.successMessageText = "Leads Are Exported Successfully Into Salesforce..!";
        this.isSubmitBtnDisabled = false;
        console.log(response, "getIncomeList response");
        this.income = response;
      }, (error: any) => {
        this.successMessage = false;
        this.waitMessage = false;
        this.errorMessage = true;
        this.errorMessageText = "Leads Export Failed..!";
        this.isSubmitBtnDisabled = false;
      });
  }

  rangeChange(item: any) {

    this.fileObject.age.min = item.value;
    this.fileObject.age.max = item.highValue;
    console.log('Range change ,......', item);
    this.rerender();

  }
  //Dropdown City----------
  onItemSelect(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemSelect', item);
    this.fileObject.city.push(item.item_text);
    this.getStateList();
    this.getZipcodeList();
    this.rerender();
    console.log('fileObject push', this.fileObject);
  }

  onSelectAll(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onSelectAll', items);
    this.fileObject.city = [];
    for (const element of items) {
      this.fileObject.city.push(element.item_text);
    }
    this.getStateList();
    this.getZipcodeList();
    this.rerender();
    console.log('fileObject push All City', this.fileObject.city);
  }

  onItemDeSelectAll(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelectAll', items);
    this.fileObject.city = [];
    this.getStateList();
    this.getZipcodeList();
    this.rerender()
    console.log('fileObject POP All City', this.fileObject.city);
  }

  onItemDeSelect(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelect', item);
    for (let i = 0; i < this.fileObject.city.length; i++) {
      if (this.fileObject.city[i] === item.item_text) {
        console.log(item.item_text, "true", this.fileObject);
        this.fileObject.city.splice(i, 1);
      }
    }
    this.getStateList();
    this.getZipcodeList();
    this.rerender();
    console.log('fileObject pop', this.fileObject.city);
  }

  toogleShowFilter() {
    this.ShowFilter = !this.ShowFilter;
    this.dropdownSettings = { ...this.dropdownSettings, allowSearchFilter: this.ShowFilter };
  }

  handleLimitSelection() {
    if (this.limitSelection) {
      this.dropdownSettings = { ...this.dropdownSettings, limitSelection: 2 };
    } else {
      this.dropdownSettings = { ...this.dropdownSettings, limitSelection: null };
    }
  }

  getCityList() {
    console.log("inside getCityList", this.fileObject);
    this.dataManager.postRequest(this.getCityListUrl, this.fileObject)
      .subscribe((response: any) => {
        console.log(response, "getCityList response");
        this.cities = response;
      }, (error: any) => {
        console.log(error, "getCityList error");
        this.cities = [];
      });
  }
  // City End--------------

  // State dropdown------
  onItemSelectState(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemSelect', item);
    this.fileObject.state.push(item.item_text);
    this.getCityList();
    this.getZipcodeList();
    this.rerender();
    console.log('fileObject push', this.fileObject.state);
  }

  onSelectAllState(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onSelectAll', items);
    this.fileObject.state = [];
    for (const element of items) {
      this.fileObject.state.push(element.item_text);
    }
    this.getCityList();
    this.getZipcodeList();
    this.rerender();
    console.log('fileObject push All state', this.fileObject.state);
  }

  onItemDeSelectAllState(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelectAll', items);
    this.fileObject.state = [];
    this.getCityList();
    this.getZipcodeList();
    this.rerender();
    console.log('fileObject POP All state', this.fileObject.state);
  }

  onItemDeSelectState(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelect', item);
    for (let i = 0; i < this.fileObject.state.length; i++) {
      if (this.fileObject.state[i] === item.item_text) {
        console.log(item.item_text, "true", this.fileObject);
        this.fileObject.state.splice(i, 1);
      }
    }
    this.getCityList();
    this.getZipcodeList();
    this.rerender();
    console.log('fileObject pop', this.fileObject.state);
  }

  getStateList() {
    console.log("inside getStateList", this.fileObject);
    this.dataManager.postRequest(this.getStateListUrl, this.fileObject)
      .subscribe((response: any) => {
        console.log(response, "getStateList response");
        this.stats = response;
      }, (error: any) => {
        console.log(error, "getStateList error");
        this.stats = [];
      });
  }
  // State End-------------------

  // Zipcode dropdown------------
  onItemSelectZipcode(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemSelect', item);
    this.fileObject.zipcode.push(item.item_text);
    this.getStateList();
    this.getCityList();
    this.rerender();
    console.log('fileObject push', this.fileObject.zipcode);
  }

  onSelectAllZipcode(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onSelectAll', items);
    this.fileObject.zipcode = [];
    for (const element of items) {
      this.fileObject.zipcode.push(element.item_text);
    }
    this.getStateList();
    this.getCityList();
    this.rerender();
    console.log('fileObject push All zipcode', this.fileObject.zipcode);
  }

  onItemDeSelectAllZipcode(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelectAll', items);
    this.fileObject.zipcode = [];
    this.getStateList();
    this.getCityList();
    this.rerender();
    console.log('fileObject POP All zipcode', this.fileObject.zipcode);
  }

  onItemDeSelectZipcode(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelect', item);
    for (let i = 0; i < this.fileObject.zipcode.length; i++) {
      if (this.fileObject.zipcode[i] === item.item_text) {
        console.log(item.item_text, "true", this.fileObject);
        this.fileObject.zipcode.splice(i, 1);
      }
    }
    this.getStateList();
    this.getCityList();
    this.rerender();
    console.log('fileObject pop', this.fileObject.zipcode);
  }

  getZipcodeList() {
    console.log("inside getZipcodeList", this.fileObject);
    this.dataManager.postRequest(this.getZipcodeListUrl, this.fileObject)
      .subscribe((response: any) => {
        console.log(response, "getZipcodeList response");
        this.zipcodes = response;
      }, (error: any) => {
        console.log(error, "getZipcodeList error");
        this.zipcodes = [];
      });
  }
  // Zipcode End------------

  // Income dropdown---------
  onItemSelectIncome(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemSelectIncome', item);
    this.fileObject.income.push(item.item_text);
    this.rerender();
    console.log('fileObject push', this.fileObject.income);
  }

  onSelectAllIncome(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onSelectAllIncome', items);
    this.fileObject.income = [];
    for (const element of items) {
      this.fileObject.income.push(element.item_text);
    }
    this.rerender();
    console.log('fileObject push All income', this.fileObject.income);
  }

  onItemDeSelectAllIncome(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelectAllIncome', items);
    this.fileObject.income = [];
    console.log('fileObject POP All income', this.fileObject.income);
    this.rerender();
  }

  onItemDeSelectIncome(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelectIncome', item);
    for (let i = 0; i < this.fileObject.income.length; i++) {
      if (this.fileObject.income[i] === item.item_text) {
        console.log(item.item_text, "true", this.fileObject);
        this.fileObject.income.splice(i, 1);
      }
    }
    this.rerender();
    console.log('fileObject pop ', this.fileObject.income);
  }

  getIncomeList() {
    console.log("inside getIncomeList", this.fileObject);
    this.dataManager.postRequest(this.getIncomeListUrl, this.fileObject)
      .subscribe((response: any) => {
        console.log(response, "getIncomeList response");
        this.income = response;
      }, (error: any) => {
        console.log(error, "getIncomeList error");
        this.income = [];
      });
  }
  // Income End---------------

  // Age dropdown--------------
  onItemSelectAge(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemSelectAge', item);
    this.fileObject.age.push(item.item_text);
    this.rerender();
    console.log('fileObject push', this.fileObject.age);
  }

  onSelectAllAge(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onSelectAllAge', items);
    this.fileObject.age = [];
    for (const element of items) {
      this.fileObject.age.push(element.item_text);
    }
    this.rerender();
    console.log('fileObject push All age', this.fileObject.age);
  }

  onItemDeSelectAllAge(items: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelectAllAge', items);
    this.fileObject.age = [];
    console.log('fileObject POP All age', this.fileObject.age);
  }

  onItemDeSelectAge(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log('onItemDeSelectAge', item);

    for (let i = 0; i < this.fileObject.age.length; i++) {
      if (this.fileObject.age[i] === item.item_text) {
        console.log(item.item_text, "true", this.fileObject);
        this.fileObject.age.splice(i, 1);
      }
    }
    this.rerender();
    console.log('fileObject pop ', this.fileObject.age);
  }

  getAgeList() {
    console.log("inside getAgeList", this.fileObject);
    this.dataManager.postRequest(this.getAgeListUrl, this.fileObject)
      .subscribe((response: any) => {
        console.log(response, "getAgeList response");
      }, (error: any) => {

      });
  }
  // Age End-----------------

  rangeChangeMin(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    this.fileObject.age.min = item.target.value;
    console.log('Range change ,......', item.target.value);
    this.rerender();

  }
  rangeChangeMax(item: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    this.fileObject.age.max = item.target.value;
    console.log('Range change ,......', item.target.value);
    this.rerender();

  }

  public isNewLead(value: boolean) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    if (value) {
      this.fileObject.isChecked = value;
      console.log("true", this.fileObject);
      this.rerender();
    } else {
      this.fileObject.isChecked = value;
      console.log("false", this.fileObject);
      this.rerender();
    }
  }

  public isChekedLeadRow(value: boolean, id: any) {
    console.log(id, "id..................................................................................................");
    if (value) {
      this.fileObject.integratedLead.push(id);
      console.log("true", this.fileObject);
      this.rerender();
    } else {
      for (let i = 0; i < this.fileObject.integratedLead.length; i++) {
        if (this.fileObject.integratedLead[i] === id) {
          console.log(id, "true", this.fileObject);
          this.fileObject.integratedLead.splice(i, 1);
        }
      }
      console.log("false", this.fileObject);
      this.fileObject.isCheckedLeadsAll = false;
      this.rerender();
    }
  }

 selectRow(data: any) {
  console.log("inside selectRow............................", this.fileObject.integratedLead);

  if (this.fileObject.isCheckedLeadsAll) {
    this.applySelectAllLogic(data);
  } else {
    this.applySelectiveLogic(data);
  }

  return data;
}

private applySelectAllLogic(data: any[]): void {
  const leads = this.fileObject.integratedLead;

  for (const element of data) {
    if (leads !== undefined && leads.length > 0) {
      this.markIfLeadExists(element, leads);
    } else {
      this.addLeadAndSelect(element);
    }
  }

  console.log("length............................", this.fileObject.integratedLead.length);
}

private markIfLeadExists(element: any, leads: any[]): void {
  const leadSet = new Set(leads.map(x => String(x)));

  if (leadSet.has(String(element.integreted_id))) {
    element.isSelected = true;
  }
}

private addLeadAndSelect(element: any): void {
  this.fileObject.integratedLead.push(element.integreted_id);
  element.isSelected = true;
}

private applySelectiveLogic(data: any[]): void {
  const leads = this.fileObject.integratedLead || [];

  if (!Array.isArray(leads) || leads.length === 0) {
    this.resetSelection(data);
    return;
  }

  const leadSet = new Set(leads.map(x => String(x)));

  data.forEach(item => {
    item.isSelected = leadSet.has(String(item.integreted_id));
  });
}

private resetSelection(data: any[]): void {
  data.forEach(item => (item.isSelected = false));
  this.fileObject.integratedLead = [];
  this.fileObject.isCheckedLeadsAll = false;
  console.log("false", this.fileObject);
}


  isCheckedLeadRowAll(value: boolean) {
  value ? this.selectAllLeads() : this.unselectAllLeads();
}

private selectAllLeads(): void {
  this.fileObject.isCheckedLeadsAll = true;
  this.fileObject.integratedLead = [];

  this.dataManager.postRequest(this.checkboxSelectAllUrl, this.fileObject)
    .subscribe(
      (response: any) => {
        for (const element of response.data) {
          this.fileObject.integratedLead.push(element.integreted_id);
        }
        this.rerender();
      },
      () => { /* handle error if needed */ }
    );
}

private unselectAllLeads(): void {
  this.fileObject.integratedLead = [];
  this.fileObject.isCheckedLeadsAll = false;
  console.log("false", this.fileObject);
  this.rerender();
}

  // Save file --------------
  saveFile() {
    if (!this.fileObject.fileMonth) {
      this.errorMessage = true;
      this.errorMessageText = "Please Select a Month."
      return;
    }
    if (!this.fileObject.fileYear) {
      this.errorMessage = true;
      this.errorMessageText = "Please Select a Year."
      return;
    }
    console.log("Saving object...", this.fileObject);
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

  onchangeMonth(changeMonth: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    console.log("month", changeMonth);
    this.fileObject.fileMonth = changeMonth;
  }

  onchangeYear(changeYear: any) {
    this.fileObject.isCheckedLeadsAll = false;
    this.fileObject.integratedLead = [];
    this.fileObject.fileYear = changeYear
  }

  rerender(): void {
    console.log("rendering file......");
    this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();

      // Call the dtTrigger to rerender again
      this.dtTrigger.next();

    });
  }

  dateNavigate($event: NgbDatepickerNavigateEvent) {
    console.log("Inside data Nevigate");
    console.log($event.next.month, "month");
    console.log($event.next.year, "year");
    this.fileObject.fileMonth = $event.next.month;
    this.fileObject.fileYear = $event.next.year;
    this.fileObject.state = [];
    this.fileObject.city = [];
    this.fileObject.income = [];
    this.fileObject.zipcode = [];
    this.fileObject.age = { min: 16, max: 120 };
    this.fileObject.integratedLead = [];
    this.fileObject.isChecked = false;
    this.fileObject.isCheckedLeadsAll = false;
    this.getStateList();
    this.getCityList();
    this.getZipcodeList();
    this.rerender();
  }

}
