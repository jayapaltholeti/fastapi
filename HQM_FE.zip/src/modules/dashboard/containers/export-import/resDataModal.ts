export interface ResDataModal {
 
  }