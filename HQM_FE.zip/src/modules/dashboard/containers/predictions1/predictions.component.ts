import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective  } from 'angular-datatables';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../../environments/environment';
import { DataManagerService } from '../../services/data-manager.service';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Subject } from 'rxjs';
import { FormControl } from '@angular/forms';

const APIEndpoint = environment.APIEndpoint;
class Person {
  id?: number;
  firstName?: string;
  lastName?: string;
}
class DataTablesResponse {
  data?: any[];
  draw?: number;
  recordsFiltered?: number;
  recordsTotal?: number;
}
@Component({
    selector: 'sb-view-grid',
    templateUrl: './predictions.component.html',
    styleUrls: ['./predictions.component.scss'],
    standalone: false
})
export class PredictionsComponent implements AfterViewInit, OnDestroy, OnInit {

  @ViewChild(DataTableDirective, {static: false})
  dtElement?: DataTableDirective;

  errorMessage: boolean = false;
  successMessage: boolean = false;
  errorMessageText?: string;
  successMessageText?: string;
  dtTrigger: Subject<void> = new Subject<void>();

  

  public data = [
    {integreted_id: '1', MAD_ID: 'ClaAnm59178205', first_name:'Claybourne', middle_initial:'',dob:'03-04-1951', address_line1:'6239 Union Court',address_line2:'67 Northport Crossing',city:'Mesa',state:'Arizona', zip_code:'85205',phone:'51343454545'},
		{integreted_id: '2', MAD_ID: 'AshSke514245426', first_name:'Ashely', middle_initial:'',dob:'03-13-1989', address_line1:'95040 Bowman Court',address_line2:'1971 Dovetail Place',city:'Dayton',state:'Ohio', zip_code:'45426',phone:'2623424354534'},
		{integreted_id: '3', MAD_ID: 'LewCap462667230', first_name:'Lewie', middle_initial:'',dob:'01-18-1999', address_line1:'1 Green Center',address_line2:'13472 Lien Park',city:'Wichita',state:'Kansas', zip_code:'67230',phone:'912233223232'},
		{integreted_id: '4', MAD_ID: 'FraEdg49276705', first_name:'Francesco', middle_initial:'',dob:'11-17-1928', address_line1:'55952 Mcbride Pass', address_line2:'2 Dapin Pass',city:'Wichita',state:'Kansas', zip_code:'67205',phone:'51343434343'},
		{integreted_id: '5', MAD_ID: 'CasMcC512477020', first_name:'Case', middle_initial:'',dob:'08-08-1932', address_line1:'92212 Golf View Drive', address_line2:'28015 Delaware Hill',city:'Houston',state:'Texas', zip_code:'77020',phone:'2132424223'},
   
];

  months = [
    { id: 1, label: "January" },
    { id: 2, label: "February" },
    { id: 3, label: "March" },
    { id: 4, label: "April" },
    { id: 5, label: "May" },
    { id: 6, label: "June" },
    { id: 7, label: "July" },
    { id: 8, label: "August" },
    { id: 9, label: "September" },
    { id: 10, label: "October" },
    { id: 11, label: "November" },
    { id: 12, label: "December" }
  ]

  public serverEndPoint = APIEndpoint;
  getIntTableUrl: string = "";
  fileObject: any = {
    fileMonth: 11,
    fileYear: 2020,
  };
  dtOptions: DataTables.Settings = {};
  persons?: Person[];
  public constructor(private router: Router, private dataManager: DataManagerService, private activatedRoute: ActivatedRoute, private http: HttpClient) {
    this.activatedRoute.params.subscribe(params => {
      if (params.month != undefined) {
        this.fileObject.fileMonth = params.month;
        this.fileObject.fileYear = params.year;
        console.log("URL Month ", this.fileObject);
      }
    })
  }

  public ngOnInit(): void {

    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
      //...
    }
    console.log("Calling init function...");
    this.getIntTableUrl = this.serverEndPoint + "/rest/private/dma/v1/table/pagination";
    const that = this;
   
    this.dtOptions = {
      pagingType: 'full_numbers',
      pageLength: 10,
      processing: true,
      responsive: true,
      dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
        searching: false,
        


      language: {
      /* paginate: {
          previous: "<i class='fa fa-angle-left arrow left' aria-hidden='true'></i>",
          next: "<i class='fa fa-angle-right arrow right' aria-hidden='true'></i>"
        }*/
    },
    };

    // this.dtOptions = {
    //   pagingType: 'full_numbers',
    //   pageLength: 5,
    //   serverSide: true,
    //   processing: true,
    //   ajax: (dataTablesParameters: any, callback) => {
    //     that.http
    //       .post<DataTablesResponse>(
    //         'https://angular-datatables-demo-server.herokuapp.com/',
    //         dataTablesParameters, {}
    //       ).subscribe(resp => {
    //         console.log(resp, "responce data......");
    //         that.persons = resp.data;
    //         callback({
    //           recordsTotal: resp.recordsTotal,
    //           recordsFiltered: resp.recordsFiltered,
    //           data: []
    //         });
    //       });
    //   },
    //   columns: [{ data: 'id' }, { data: 'firstName' }, { data: 'lastName' }]
    // };
    //-------
   
    //-------


    // Datatable old code
   
   /* this.dtOptions = {
      
  
        pagingType: 'full_numbers',
  
        language: {
          paginate: {
            previous: "<i class='fa fa-angle-left' aria-hidden='true'></i>",
            next: "<i class='fa fa-angle-right' aria-hidden='true'></i>"
          }
      },
   
     
        pageLength: 10,
        scrollY: '400',
        serverSide: true,
        processing: true,
        
       
        dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
        searching: false,
       
        ajax: (dataTablesParameters: any, callback) => {
          dataTablesParameters['dateObject'] = this.fileObject;
          that.http
            .post<DataTablesResponse>(
              this.getIntTableUrl,
              dataTablesParameters, {}
            ).subscribe(resp => {
              console.log(resp, "responce data......");
              that.persons = resp.data;
              callback({
                recordsTotal: resp.recordsTotal,
                recordsFiltered: resp.recordsFiltered,
                data: []
              });
            }); 
        },
        columns: [{ data: 'integreted_id' }, { data: 'MAD_ID' },
        { data: 'first_name' },
        { data: 'middle_initial' },
        { data: 'dob' },
        { data: 'address_line1' },
        { data: 'address_line2' },
        { data: 'city' },
        { data: 'state' },
        { data: 'zip_code' },
        { data: 'phone' }
        ]
      };
*/
    //End code
  }

  // Save file

  saveFile() { 
    if (!this.fileObject.fileMonth) {
      this.errorMessage = true;
      this.errorMessageText = "Please Select a Month."
      return;
    }
    if (!this.fileObject.fileYear) {
      this.errorMessage = true;
      this.errorMessageText = "Please Select a Year."
      return;
    }
    console.log("Saving object...", this.fileObject);
  }

  ngAfterViewInit(): void {
    this.dtTrigger.next();
  }

  ngOnDestroy(): void {
    // Do not forget to unsubscribe the event
    this.dtTrigger.unsubscribe();
  }

 onchangeMonth(changeMonth: any) {
    console.log("month", changeMonth);
    // this.errorMessage = false;
    // this.successMessage = false;
    this.fileObject.fileMonth = changeMonth;
    // this.getDmaList();
  }

  onchangeYear(changeYear: any) {
    // this.errorMessage = false;
    // this.successMessage = false;
    this.fileObject.fileYear = changeYear
    // this.getDmaList();
  }

  rerender(): void {
    console.log("rendering file......");
    this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
      // Destroy the table first
      dtInstance.destroy();
      // Call the dtTrigger to rerender again
      this.dtTrigger.next();
    });
  }

  
}
