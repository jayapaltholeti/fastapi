import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { MemberretentionComponent } from './memberretention.component';

describe('MemberretentionComponent', () => {
  let component: MemberretentionComponent;
  let fixture: ComponentFixture<MemberretentionComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ MemberretentionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MemberretentionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
