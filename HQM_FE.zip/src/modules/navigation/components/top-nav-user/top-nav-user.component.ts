import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { UserService } from '@modules/auth/services';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
    selector: 'sb-top-nav-user',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './top-nav-user.component.html',
    styleUrls: ['top-nav-user.component.scss'],
    standalone: false
})
export class TopNavUserComponent implements OnInit {


    First_Name: string = ""
    Last_Name: string = ""
    Email: string = ""

    userDetails: any = {}

    constructor(public userService: UserService, private router: Router) { }
    ngOnInit() { }

    logOut() {
        sessionStorage.clear();
        this.router.navigate(['auth/login']);
    }
    getData() {
        this.userDetails = sessionStorage.getItem('user')
        console.log(JSON.parse(this.userDetails))
        this.First_Name = JSON.parse(this.userDetails).First_Name
        this.Last_Name = JSON.parse(this.userDetails).Last_Name
        this.Email = JSON.parse(this.userDetails).Email
    }

    // openPdf() {
    //     window.open('', '_blank')
    // }
}
