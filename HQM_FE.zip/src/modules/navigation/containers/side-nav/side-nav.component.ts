import { ChangeDetectionStrategy, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { UserService } from '@modules/auth/services';
import { SideNavItems, SideNavSection } from '@modules/navigation/models';
import { NavigationService } from '@modules/navigation/services';
import { Subscription } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from '../../../../environments/environment';


@Component({
    selector: 'sb-side-nav',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './side-nav.component.html',
    styleUrls: ['side-nav.component.scss'],
    standalone: false
})
export class SideNavComponent implements OnInit, OnDestroy {
    @Input() sidenavStyle!: string;
    @Input() sideNavItems!: SideNavItems;
    @Input() sideNavSections!: SideNavSection[];

    subscription: Subscription = new Subscription();
    routeDataSubscription!: Subscription;
    retention_arrow: string = "";
    acquisition_arrow: string = "";
    reportsLink = environment.reportsUrl;
    analyticsLink = environment.analyticsUrl;

    currentUser: any;
    isDisabled: boolean = false;



    constructor(public navigationService: NavigationService, public userService: UserService, public activatedRoute: ActivatedRoute, public router: Router) {
        this.activatedRoute.params.subscribe(params => {
            console.log(this.router.url)
            this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
            var dataArr = this.router.url.split('/');
            var url = dataArr[0];
            var name = dataArr[2];
            //var dashboard = dataArr[1];

            console.log("name1 = " + name)
            if ((name == "retention-dashboard") || (name == "rerentionfileupload") || (name == "retention-int-view") || (name == "memberretention") || (name == "memberdetails")) {
                console.log("name2 = " + name)
                this.acquisition_status = false;
                // this.retention_status = true;
                this.retention_arrow = "['fas', 'angle-down']";
                this.acquisition_arrow = "['fas', 'angle-right']";

            }

            if ((name == "dashboardnew") || (name == "roles") || (name == "users")
                || (name == "edit-hospital/:ID")) {
                console.log("name2 = " + name)
                this.acquisition_status = true;
                //  this.retention_status = false;
                this.retention_arrow = '["fas", "angle-right"]';
                this.acquisition_arrow = '["fas", "angle-down"]';

            }


            if ((name == "add-group-system") || (name == "hospital-list") || (name == "add-hospital") || (name == "add-measure-group") || (name == "add-measure-id") || (name == "mapping")) {
                console.log("name2 = " + name)
                this.masters_status = false;
                // this.retention_status = true;
                this.retention_arrow = "['fas', 'angle-down']";
                this.acquisition_arrow = "['fas', 'angle-right']";

            }

            if ((name == "add-group-system") || (name == "hospital-list") || (name == "add-hospital") || (name == "add-measure-group") || (name == "add-measure-id") || (name == "mapping")) {
                console.log("name2 = " + name)
                this.masters_status = true;
                //  this.retention_status = false;
                this.retention_arrow = '["fas", "angle-right"]';
                this.acquisition_arrow = '["fas", "angle-down"]';

            }

            if ((name == "upload") || (name == "calculate-payout") || (name == "display-payout") || (name == "national-percentile")) {
                console.log("name2 = " + name)
                this.payout_status = false;
                // this.retention_status = true;
                this.retention_arrow = "['fas', 'angle-down']";
                this.acquisition_arrow = "['fas', 'angle-right']";

            }

            if ((name == "upload") || (name == "calculate-payout") || (name == "display-payout")) {
                console.log("name2 = " + name)
                this.payout_status = true;
                //  this.retention_status = false;
                this.retention_arrow = '["fas", "angle-right"]';
                this.acquisition_arrow = '["fas", "angle-down"]';

            }
            if ((name == "national-percentile") || (name == "hospital-percentile")) {
                console.log("name2 = " + name)
                this.percentile_status = false;
                // this.retention_status = true;
                this.retention_arrow = "['fas', 'angle-down']";
                this.acquisition_arrow = "['fas', 'angle-right']";

            }
            if ((name == "national-percentile") || (name == "hospital-percentile")) {
                console.log("name2 = " + name)
                this.percentile_status = true;
                //  this.retention_status = false;
                this.retention_arrow = '["fas", "angle-right"]';
                this.acquisition_arrow = '["fas", "angle-down"]';

            }

            if ((name == "reports") || (name == "analytic")) {
                console.log("name2 = " + name)
                this.reports_status = false;
                // this.retention_status = true;
                this.retention_arrow = "['fas', 'angle-down']";
                this.acquisition_arrow = "['fas', 'angle-right']";

            }

            if ((name == "reports") || (name == "analytic")) {
                console.log("name2 = " + name)
                this.reports_status = true;
                //  this.retention_status = false;
                this.retention_arrow = '["fas", "angle-right"]';
                this.acquisition_arrow = '["fas", "angle-down"]';

            }

            if ((name == "help") || (name == "help")) {
                console.log("name2 = " + name)
                this.help_status = true;
                //  this.retention_status = false;
                this.retention_arrow = '["fas", "angle-right"]';
                this.acquisition_arrow = '["fas", "angle-down"]';

            }

            if ((name == "users")) {
                console.log("name2 = " + name)

                if (!this.checkStatus()) {
                    this.router.navigate(['/auth/login']);

                }
            }
        })

    }

    ngOnInit() {

        console.log("ngOnInit Loading......");
        // this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        // this.user.User_Id = this.currentUser.ID;

        if (this.checkStatus()) {
            this.isDisabled = true;
            console.log("nav...prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = false;
            console.log("nav....prermission Disabled......", this.isDisabled);
        }
    }

    checkStatus() {
        var found = false;
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'User') {
                found = true;
            }
        });
        return found;
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
    acquisition_status: boolean = false;
    //   retention_status: boolean = false;
    masters_status: boolean = false;
    payout_status: boolean = false
    reports_status: boolean = false
    help_status: boolean = false
    percentile_status: boolean = false


    Open_Acquisition() {
        this.acquisition_status = !this.acquisition_status;
    }
    Open_Payout() {
        this.payout_status = !this.payout_status;
    }
    Open_Masters() {
        this.masters_status = !this.masters_status;
    }
    Open_Reports() {
        this.reports_status = !this.reports_status;
    }
    Open_Help() {
        this.help_status = !this.help_status;
    }

    Open_Percentile() {
        this.percentile_status = !this.percentile_status;
    }

}
