
export class LoginModel {
    email?: string;
    apassword?: string;
}
