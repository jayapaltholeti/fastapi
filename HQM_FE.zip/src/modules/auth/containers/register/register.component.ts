import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { RegisterModel } from './register.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MustMatch } from '../_helpers/must-match.validator';
import { DataManagerService } from '../service/data-manager.service';
import { environment } from '../../../../environments/environment';
import { Router, ActivatedRoute } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;

@Component({
    selector: 'sb-register',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './register.component.html',
    styleUrls: ['register.component.scss'],
    standalone: false
})
export class RegisterComponent implements OnInit {
    alert: boolean = false;
    user: RegisterModel;
    registerForm?: FormGroup;
    submitted = false;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    registerUrl: string = '';
    password: string = '';
    public serverEndPoint = APIEndpoint;

    constructor(private formBuilder: FormBuilder, private router: Router, private dataManager: DataManagerService) {
        this.user = new RegisterModel();
    }
    ngOnInit() {
        this.registerUrl = this.serverEndPoint + "/rest/private/dma/v1/user/create";
        this.registerForm = this.formBuilder.group({

            firstName: ['', [Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]],
            lastName: ['', [Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]],
            email: ['', [Validators.required, Validators.email, Validators.pattern("^([a-zA-Z0-9_\\-\\.]+)@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.)|(([a-zA-Z0-9\\-]+\\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\\]?)$")]],
            password: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{6,}')]],
            confirmPassword: ['', [Validators.required, Validators.pattern('(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[$@$!%*?&])[A-Za-z\d$@$!%*?&].{6,}')]],
        }, {
             validator: MustMatch('password', 'confirmPassword')
        });
    }

    get f() { return this.registerForm?.controls; }


    onSubmit() {
        this.submitted = true;

        // stop here if form is invalid
        if (this.registerForm?.invalid) {
            return;
        }
        this.dataManager.postRegister(this.registerUrl, this.user)
            .subscribe((response: any) => {
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Register Created Successfully."
                console.log("Login Responce", response);
                sessionStorage.setItem('user', JSON.stringify(response.user));
                sessionStorage.setItem('token', response.token);
                this.reset();

                //    this.router.navigate(['/auth/login']);

            }, (error: any) => {
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Email Already Exist."
                this.reset();
            });
    }
    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }

    reset() {
        this.submitted = false;
        this.registerForm?.reset();
    }






}




