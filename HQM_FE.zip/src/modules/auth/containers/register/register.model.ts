
export class RegisterModel {
    email?: string;
    apassword?: string;
    password?: string;
    firstname?:string;
    lastname?:string;
}