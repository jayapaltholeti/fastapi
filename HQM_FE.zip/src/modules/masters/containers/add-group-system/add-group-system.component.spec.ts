import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NoopAnimationsModule } from '@angular/platform-browser/animations';

import { AddGroupSystemComponent } from './add-group-system.component';

@Component({
  template: `
    <sb-register [someInput]="someInput" (someFunction)="someFunction($event)"></sb-register>
  `
})
class TestHostComponent {
  someInput = 1;
  someFunction(event: Event) {
    // Intentionally empty: required for output binding in test host
  }
}

describe('AddGroupSystemComponent', () => {
  let fixture: ComponentFixture<TestHostComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestHostComponent, AddGroupSystemComponent],
      imports: [NoopAnimationsModule]
    }).compileComponents();

    fixture = TestBed.createComponent(TestHostComponent);
    fixture.detectChanges();
  });

  it('should display the component', () => {
    expect(fixture.nativeElement.querySelector('sb-register')).toBeTruthy();
  });
});
