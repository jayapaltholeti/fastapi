import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { AddGroupSystemModel } from './add-group-system.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router, ActivatedRoute } from '@angular/router';
import { Options } from '@angular-slider/ngx-slider';
const APIEndpoint = environment.APIEndpoint;

class DataTablesResponse {
    data?: any[];
    draw?: number;
    recordsFiltered?: number;
    recordsTotal?: number;
}

@Component({
    selector: 'sb-add-group-system',
    templateUrl: './add-group-system.component.html',
    styleUrls: ['add-group-system.component.scss'],
    standalone: false
})
export class AddGroupSystemComponent implements AfterViewInit, OnDestroy, OnInit {
    // Data table
    @ViewChild(DataTableDirective, { static: false })
    dtElement?: DataTableDirective;
    dtTrigger: Subject<void> = new Subject<void>();
    httpHeaders?: HttpHeaders;
    dtOptions: DataTables.Settings = {};
    getTableUrl: string = "";
    persons?: any[];
    postObject: any = {
        user: '1',
    };
    options: Options = {
        floor: 1,
        ceil: 120
    };

    alert: boolean = false;
    user: AddGroupSystemModel;
    addGroupForm?: FormGroup;
    submitted = false;
    isUpdate = false;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    addGroupUrl: string = '';
    updateGroupUrl: string = '';
    deleteGroupUrl: string = '';
    searchText: string = '';
    InsuranceCompanyUrl: string = '';
    public serverEndPoint = APIEndpoint;
    dataList: any;
    success: any
    error: any
    dismissible = true;
    currentUser: any;
    isDisabled: boolean = false;
    displayStyle = "none";
    isLoading: boolean = false;

    constructor(
        private readonly formBuilder: FormBuilder,
        private readonly router: Router,
        private readonly http: HttpClient,
        private readonly activatedRoute: ActivatedRoute,
        private readonly hospitalService: HospitalService
    ) {
        this.user = new AddGroupSystemModel();
    }

    ngOnInit() {
        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.User_Id = this.currentUser.ID;
        this.user.Insurance_Company_ID = this.currentUser.Insurance_Company_ID;
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Group Hospital';
        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }

        this.user.Insurance_Company_ID = null;
        this.addGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/group/create";
        this.updateGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/groupsystem/update";
        this.deleteGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/groupsystem/delete";
        this.InsuranceCompanyUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/insurancecompany/getlist";
        // Data Table
        console.log("Datatable Loading.....");
        this.getTableUrl = this.serverEndPoint + "/rest/private/hqm/v1/groupsystem/pagination";
        console.log("API URl...", this.getTableUrl);
        console.log("postObject ...", this.postObject);
        const that = this;

        this.dtOptions = {
            //  Type : { previous: String, next: String },
            pagingType: 'full_numbers',
            language: {
                emptyTable: '',   // removes "No matching records found"
                zeroRecords: ''   // removes "No matching records found" when filtering
                // you can still customize paginate icons here if needed
            },
            pageLength: 10,
            scrollY: '400',
            scrollX: true,
            serverSide: true,
            processing: true,
            // dom: '<"top"i>rt<"bottom"flp><"clear">',
            dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
            searching: false,
            ajax: (dataTablesParameters: any, callback: DataTablesAjaxCallback) => {
                dataTablesParameters['dateObject'] = this.postObject;
                this.isLoading = true;
                that.http
                    .post<DataTablesResponse>(
                        this.getTableUrl,
                        dataTablesParameters, {
                        headers: new HttpHeaders({
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + sessionStorage.getItem("token"),
                        }), withCredentials: true
                    }
                    ).subscribe(resp => {
                        if (resp.data) {
                            this.isLoading = false;
                            that.persons = resp?.data[0];
                            console.log(that.persons, "responce data......");
                            callback({
                                recordsTotal: resp.recordsTotal,
                                recordsFiltered: resp.recordsFiltered,
                                data: []
                            });
                        }
                    });
            },
            columns: [{ data: 'Group_ID' }, { data: 'Group_Name' }, { data: null, orderable: false }
            ]
        };
        // End
        this.addGroupForm = this.formBuilder.group({
            groupId: ['', [Validators.required]],
            groupName: ['', [Validators.required, Validators.pattern("^[a-zA-Z -']+")]]
        });
    }

    get f() { return this.addGroupForm?.controls; }

    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

    public isActive(value: any, id: any) {
        this.user.ID = id;
        this.user.Is_Active = value;
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                if (value) {
                    this.successMessageText = "Success! Group System Activated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000);
                } else {
                    this.successMessageText = "Success! Group System Inactivated Successfully."
                    setTimeout(() => {
                        this.successMessageText = ''; // Clear the success message or assign a different message
                        this.successMessage = false;
                    }, 2000);
                }
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                this.reset()
            });
    }

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Group Hospital') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }
    //Get Api Insurance_Company_ID
    getInsuranceCompanyListFunc() {
        console.log("Inside Get Insurance Company List Func ");
        this.hospitalService.getInsuranceCompanyList(this.InsuranceCompanyUrl).subscribe((dataList: any) => {
            this.dataList = dataList.data;
            console.log(dataList, "InsuranceCompanyList");
        }, (error: any) => {
            console.log(" Get Insurance Company Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    //Create api addgroup system
    onSubmit() {
        console.log(this.addGroupForm?.value)
        this.submitted = true;
        if (this.addGroupForm?.invalid) {
            return;
        }
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.addGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Group Created Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Hospital Group Already Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 3000);
                this.reset()
            });
    }

    onUpdate() {
        console.log(this.addGroupForm?.value)
        this.submitted = true;
        if (this.addGroupForm?.invalid) {
            return;
        }
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.updateGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Group System Updated Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                this.reset()
            });
    }

    reset() {
        this.submitted = false;
        this.errorMessage = false;
        this.isUpdate = false;
        this.addGroupForm?.reset();
    }

    deleteFun(val: any) {
        console.log("Delete Function", val)
        this.user.ID = val.ID
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Group System Delete Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                this.reset()
            });
    }

    editFun(val: any) {
        console.log("Edit Function", val)
        this.isUpdate = true;
        this.user.ID = val.ID;
        this.user.Group_ID = val.Group_ID.trim();;
        this.user.Group_Name = val.Group_Name.trim();
        this.user.Insurance_Company_ID = val.Insurance_Company_ID;
    }

    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        // Do not forget to unsubscribe the event
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        console.log("rendering file......");
        this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            this.dtTrigger.next();
        });
    }

}




