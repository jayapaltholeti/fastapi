
import { AddGroupSystemComponent } from './add-group-system/add-group-system.component';
import { AddMeasureGroupComponent } from './add-measure-group/add-measure-group.component';
import { AddMeasureIdComponent } from './add-measure-id/add-measure-id.component';
import {AddHospitalComponent} from './add-hospital/add-hospital.component'
import { HospitalListComponent } from './hospital-list/hospital-list.component';
import { EditHospitalComponent } from './edit-hospital/edit-hospital.component';
import { MappingComponent } from './mapping/mapping.component';

export const containers = [ AddGroupSystemComponent,AddMeasureGroupComponent,AddMeasureIdComponent,
    AddHospitalComponent,HospitalListComponent,EditHospitalComponent,MappingComponent];


export * from './add-group-system/add-group-system.component';
export * from './add-measure-group/add-measure-group.component';
export * from './add-measure-id/add-measure-id.component';
export * from './add-hospital/add-hospital.component';
export * from './hospital-list/hospital-list.component';
export * from './edit-hospital/edit-hospital.component';
export * from './mapping/mapping.component'


