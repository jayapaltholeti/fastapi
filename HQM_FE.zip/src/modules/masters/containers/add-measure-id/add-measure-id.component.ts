import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { AddMeasureIdModel } from './add-measure-id.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;
class DataTablesResponse {
    data?: any[];
    draw?: number;
    recordsFiltered?: number;
    recordsTotal?: number;
}
@Component({
    selector: 'sb-add-measure-id',
    templateUrl: './add-measure-id.component.html',
    styleUrls: ['add-measure-id.component.scss'],
    standalone: false
})
export class AddMeasureIdComponent implements AfterViewInit, OnDestroy, OnInit {

    // Data table
    @ViewChild(DataTableDirective, { static: false })
    dtElement?: DataTableDirective;
    dtTrigger: Subject<void> = new Subject<void>();
    httpHeaders?: HttpHeaders;
    dtOptions: DataTables.Settings = {};
    getTableUrl: string = "";
    persons?: any[];
    postObject: any = {
        user: '1',
    };
    isUpdate = false;
    alert: boolean = false;
    user: AddMeasureIdModel;
    addGroupForm?: FormGroup;
    submitted = false;
    addMeasuregroupIdUrl: string = '';
    GetAllMeasureGroupListUrl: string = ''
    GetAllMeasureIdListUrl: string = ''
    updateGroupUrl: string = '';
    deleteGroupUrl: string = '';
    public serverEndPoint = APIEndpoint;
    users: any;
    measureGrouplist: any;
    measureIdlist: any;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    page: any;
    filterTerm!: string;
    newItem: any = {};
    currentUser: any;
    isDisabled: boolean = false;
    isLoading: boolean = false;

    displayStyle = "none"

    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly http: HttpClient, private readonly hospitalService: HospitalService) {
        this.user = new AddMeasureIdModel();

    }
    ngOnInit() {

        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.User_Id = this.currentUser.ID;
        this.user.Insurance_Company_ID = this.currentUser.Insurance_Company_ID;
        this.user.Measure_Group_List_ID = null;
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Measures';
        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }

        this.addMeasuregroupIdUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/measuregroupidlist/create";
        this.GetAllMeasureGroupListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/measuregroup/getlist";
        this.GetAllMeasureIdListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/measureidlist/getlist";

        this.updateGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/measureid/update";
        this.deleteGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/measureid/delete";
        this.getTableUrl = this.serverEndPoint + "/rest/private/hqm/v1/measureid/pagination";

        const that = this;
       
        this.dtOptions = {
            //  Type : { previous: String, next: String },
            pagingType: 'full_numbers',
            language: {
                emptyTable: '',   // removes "No matching records found"
                zeroRecords: ''   // removes "No matching records found" when filtering
                // you can still customize paginate icons here if needed
            },
            pageLength: 10,
            scrollY: '400',
            scrollX: true,
            serverSide: true,
            processing: true,
            // dom: '<"top"i>rt<"bottom"flp><"clear">',
            dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
            searching: false,
            ajax: (dataTablesParameters: any, callback: DataTablesAjaxCallback) => {
                dataTablesParameters['dateObject'] = this.postObject;
                this.isLoading = true;
                that.http
                    .post<DataTablesResponse>(
                        this.getTableUrl,
                        dataTablesParameters, {
                        headers: new HttpHeaders({
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
                        }), withCredentials: true
                    }
                    ).subscribe(resp => {
                        if (resp.data) {
                            this.isLoading = false;
                            that.persons = resp?.data[0];
                            console.log(that.persons, "responce data......");
                            callback({
                                recordsTotal: resp.recordsTotal,
                                recordsFiltered: resp.recordsFiltered,
                                data: []
                            });
                        }
                    });
            },
            columns: [{ data: 'Measure_Group_Name' }, { data: 'Measure_ID' }, { data: 'Measure_ID_Name' }, { orderable: false }
            ]
        };

        this.addGroupForm = this.formBuilder.group({
            measureGroupname: ['', [Validators.required]],
            measureId: ['', [Validators.required]],
            // measureDescription: ['', [Validators.required]],
            Measure_Group_List_ID: [[null], [Validators.required]]
        });
        this.getAllMeasureGroupList();
        this.getMeasureIdList();
    }

    get f() { return this.addGroupForm?.controls; }

    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Measures') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }
    //Create Add Measure GroupId
    onSubmit() {
        console.log(this.addGroupForm?.value)
        this.submitted = true;
        if (this.addGroupForm?.invalid) {
            return;
        }
        this.hospitalService.addMeasuregroupId(this.addMeasuregroupIdUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Measure ID Created Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Hospital Measure ID Already Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    public isActive(value: any, id: any) {
        console.log(id, "id...........................................................");
        this.user.ID = id;
        this.user.Is_Active = value;
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                if (value) {
                    this.successMessageText = "Success! Measure ID Activated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000);
                } else {
                    this.successMessageText = "Success! Measure ID  Inactivated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000);
                }
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    //Get Measure Id List
    getMeasureIdList() {
        this.hospitalService.getAllMeasureIdList(this.GetAllMeasureIdListUrl)
            .subscribe((measureIdlist: any) => {
                this.measureIdlist = measureIdlist.data;
                console.log(this.measureIdlist, "measureIdlist");
            }, (error: any) => {
                console.log(" GetAll MeasureIdList Error ");
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
            });
    }

    //Get AllMeasureGroup List
    getAllMeasureGroupList() {
        this.hospitalService.getAllMeasureGroupList(this.GetAllMeasureGroupListUrl, this.user)
            .subscribe((measureGrouplist: any) => {
                this.measureGrouplist = measureGrouplist.data;
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Get Measure ID List Error."
                this.reset()
            });
    }

    addMeasuregroup() {
        this.router.navigate(['masters/add-measure-group']);
    }
    onUpdate() {
        console.log(this.addGroupForm?.value)
        this.submitted = true;
        if (this.addGroupForm?.invalid) {
            return;
        }
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.updateGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Measure ID Updated Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = error.error.message
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                // this.reset()
            });
    }

    reset() {
        this.submitted = false;
        this.errorMessage = false;
        this.isUpdate = false;
        this.addGroupForm?.reset();
    }

    deleteFun(val: any) {
        console.log("Delete Function", val)
        this.user.ID = val.Measure_ID_List_ID
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Measure ID Delete Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Measure ID Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    editFun(val: any) {
        console.log("Edit Function", val)
        this.isUpdate = true;
        this.user.ID = val.Measure_ID_List_ID;
        this.user.Measure_Group_List_ID = Number.parseInt(val.Measure_Group_List_ID);
        this.user.Measure_ID = val.Measure_ID;
        this.user.Measure_ID_Name = val.Measure_ID_Name;
        console.log("User Object", this.user)
    }

    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        // Do not forget to unsubscribe the event
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        console.log("rendering file......");
        this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            this.dtTrigger.next();
        });
    }

}




