
export class AddMeasureIdModel {
    Measure_Group_List_ID?: any;
    Measure_ID?: string;
    Measure_ID_Name?: string;
    Measure_Description?: any;
    ID?: any;
    User_Id?: any;
    Insurance_Company_ID?: any;
    role?: string;
    module_name?: string;
    permission?: string;
    Is_Active?: boolean;
}