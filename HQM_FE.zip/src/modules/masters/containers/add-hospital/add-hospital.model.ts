
export class HostpitalModel {
    Facility_Name?: string;
    Facility_ID?: string;
    Hospital_Group_ID?: any;
    Insurance_Company_ID?: any;
    User_Id:any;
    ID?: number;
    role?: string;
    module_name?: string;
    permission?: string;
    Is_Active?: boolean;
}