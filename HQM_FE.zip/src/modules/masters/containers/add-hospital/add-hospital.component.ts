import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { HostpitalModel } from './add-hospital.model'
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;
class DataTablesResponse {
    data?: any[];
    draw?: number;
    recordsFiltered?: number;
    recordsTotal?: number;
}

@Component({
    selector: 'sb-add-hospital',
    templateUrl: './add-hospital.component.html',
    styleUrls: ['add-hospital.component.scss'],
    standalone: false
})
export class AddHospitalComponent implements AfterViewInit, OnDestroy, OnInit {
    // Data table
    @ViewChild(DataTableDirective, { static: false })
    dtElement?: DataTableDirective;
    dtTrigger: Subject<void> = new Subject<void>();
    httpHeaders?: HttpHeaders;

    dtOptions: DataTables.Settings = {};
    getTableUrl: string = "";
    persons?: any[];
    postObject: any = {
        user: '1',
    };
    isUpdate = false;
    GetAllHospitalListUrl: string = '';
    addHospitalUrl: string = '';
    updateGroupUrl: string = '';
    deleteGroupUrl: string = '';
    InsuranceCompanyUrl: string = '';
    GroupSysytemUrl: string = '';
    alert: boolean = false;
    user: HostpitalModel;
    Group_Name: string | null = null;
    addHospitalForm?: FormGroup;
    submitted = false;
    public serverEndPoint = APIEndpoint;
    users: any;
    measureGrouplist: any;
    measureIdlist: any;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    dataList: any;
    hospitalList: any;
    groupSystemlist: any;
    closeResult: any;
    content: any;
    currentUser: any;
    isDisabled: boolean = false;
    displayStyle = "none";
    isLoading: boolean = false 
    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly http: HttpClient,
        // private modalService: NgbModal,
        private readonly hospitalService: HospitalService) {
        this.user = new HostpitalModel();

    }

    ngOnInit() {
        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        console.log("ngOnInit Loading......");
        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.User_Id = this.currentUser.ID;
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Hopital';
        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }

        console.log("user....... model......", this.user);
        this.user.Insurance_Company_ID = this.currentUser.Insurance_Company_ID;
        this.user.Hospital_Group_ID = null;
        this.GetAllHospitalListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getlist";
        this.addHospitalUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/create";
        this.InsuranceCompanyUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/insurancecompany/getlist";
        this.GroupSysytemUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/group/getlist";

        this.updateGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/update";
        this.deleteGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/delete";
        this.getTableUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/pagination";

        const that = this;
        
        this.dtOptions = {
            //  Type : { previous: String, next: String },
            pagingType: 'full_numbers',
            language: {
                emptyTable: '',   // removes "No matching records found"
                zeroRecords: ''   // removes "No matching records found" when filtering
                // you can still customize paginate icons here if needed
            },
            pageLength: 10,
            scrollY: '400',
            scrollX: true,
            serverSide: true,
            processing: true,
            // dom: '<"top"i>rt<"bottom"flp><"clear">',
            dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
            searching: false,
            ajax: (dataTablesParameters: any, callback: DataTablesAjaxCallback) => {
                dataTablesParameters['dateObject'] = this.postObject;
                this.isLoading = true;
                that.http
                    .post<DataTablesResponse>(
                        this.getTableUrl,
                        dataTablesParameters,
                        {
                            headers: new HttpHeaders({
                                'Content-Type': 'application/json',
                                'Authorization': 'Bearer ' + sessionStorage.getItem("token")
                            }), withCredentials: true
                        }
                    ).subscribe(resp => {
                        console.log(resp, "responce data......");
                        if (resp.data) {
                            this.isLoading = false;
                            that.persons = resp?.data[0];
                            console.log(that.persons, "responce data......");
                            callback({
                                recordsTotal: resp.recordsTotal,
                                recordsFiltered: resp.recordsFiltered,
                                data: []
                            });
                        }
                    });
            },
            columns: [{ data: 'Facility_ID' }, { data: 'Facility_Name' }, { data: 'Group_Name' }, { data: null, orderable: false }
            ]
        };

        this.addHospitalForm = this.formBuilder.group({
            Facility_ID: ['', [Validators.required, Validators.pattern('^[0-9]+$')]],
            Facility_Name: ['', [Validators.required, Validators.pattern("^[a-zA-Z ']+")]],
            // Insurance_Company_ID: [[null], [Validators.required]],
            Group_Name: [[null], [Validators.required]]
        });

        this.getGroupSystemListFunc();
    }

    get f() { return this.addHospitalForm?.controls; }

    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

    public isActive(value: any, id: any) {
        console.log(id, "id........ Object..");
        this.user.ID = id;
        this.user.Is_Active = value;
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                if (value) {
                    this.successMessageText = "Success! Hospital Activated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000);
                } else {
                    this.successMessageText = "Success! Hospital Inactivated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000);
                }
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    //Create api addgroup system
    onSubmit() {
        console.log(this.addHospitalForm?.value)
        this.submitted = true;
        if (this.addHospitalForm?.invalid) {
            return;
        }
        this.hospitalService.addHospital(this.addHospitalUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Created Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.reset()
                this.rerender();
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Hospital Already Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Hopital') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }

    //Get api hospital list
    getHospitalListFunc() {
        console.log("Inside Get Hospital Func ");
        this.hospitalService.getHospitalList(this.GetAllHospitalListUrl, this.user).subscribe((hospitalListResult: any) => {
            this.hospitalList = hospitalListResult.data.recordset;
            console.log(this.hospitalList, "Hospital List");
        }, (error: any) => {
            console.log(" Get Hospital Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    //Get api  insurance company list
    getInsuranceCompanyListFunc() {
        console.log("Inside Get Insurance Company List Func ");
        this.hospitalService.getInsuranceCompanyList(this.InsuranceCompanyUrl).subscribe((dataList: any) => {
            this.dataList = dataList.data;
            console.log(dataList, "InsuranceCompanyList");
        }, (error: any) => {
            console.log(" Get Insurance Company Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }
    //Get api group sysytem list
    getGroupSystemListFunc() {
        console.log("Inside Get GroupSysytem List Func ");
        this.hospitalService.getAllGroupSystem(this.GroupSysytemUrl, this.user).subscribe((groupSystemlist: any) => {
            this.groupSystemlist = groupSystemlist.data;
            console.log(groupSystemlist, "GroupSysytem");
        }, (error: any) => {
            console.log(" Get GroupSysytem Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        })
    }


    deleteFun(val: any) {
        console.log("Delete Function", val)
        this.user.ID = val.Facility_List_ID
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Deleted Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Hospital Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    editFun(val: any) {
        console.log("Edit Function", val)
        this.isUpdate = true;
        this.user.ID = val.Facility_List_ID;
        this.user.Hospital_Group_ID = Number.parseInt(val.Hospital_Group_ID);
        this.user.Facility_ID = val.Facility_ID;
        this.user.Facility_Name = val.Facility_Name;
        console.log("User Object", this.user)
    }

    onUpdate() {
        console.log(this.addHospitalForm?.value)
        this.submitted = true;
        if (this.addHospitalForm?.invalid) {
            return;
        }
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.updateGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Updated Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Measure ID Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }
    gethospitalList() {
        this.router.navigate(['/masters/hospital-list']);
    }

    addGroup() {
        this.router.navigate(['/masters/add-group-system']);
    }

    reset() {
        this.submitted = false;
        this.errorMessage = false;
        this.isUpdate = false;
        this.addHospitalForm?.reset();
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        // Do not forget to unsubscribe the event
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        console.log("rendering file......");
        this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            this.dtTrigger.next();
        });
    }

}




