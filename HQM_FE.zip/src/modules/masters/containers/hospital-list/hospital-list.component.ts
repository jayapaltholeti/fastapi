import { Component, OnInit } from '@angular/core';
import { HospitalListModel } from './hospital-list.model'
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;

@Component({
    selector: 'sb-hospital-list',
    templateUrl: './hospital-list.component.html',
    styleUrls: ['hospital-list.component.scss'],
    standalone: false
})
export class HospitalListComponent implements OnInit {
    GetAllHospitalListUrl: string = '';
    addHospitalUrl: string = '';
    InsuranceCompanyUrl: string = '';
    GroupSysytemUrl: string = '';
    DeleteHospitalUrl: string = '';
    alert: boolean = false;
    user: HospitalListModel;
    addHospitalForm?: FormGroup;
    submitted = false;
    public serverEndPoint = APIEndpoint;
    users: any;
    measureGrouplist: any;
    measureIdlist: any;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    dataList: any;
    hospitalList: any;
    groupSystemlist: any;
    closeResult: any;
    content: any;
    List: any
    searchText: any
    currentUser: any;
    isDisabled: boolean = false;
    displayStyle = "none";

    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router,
        private readonly modalService: NgbModal,
        private readonly hospitalService: HospitalService) {
        this.user = new HospitalListModel();

    }
    ngOnInit() {
        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Hopital';
        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }
        this.GetAllHospitalListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getlist";
        this.addHospitalUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/create";
        this.InsuranceCompanyUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/insurancecompany/getlist";
        this.GroupSysytemUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/group/getlist";
        this.DeleteHospitalUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/delete";

        this.getHospitalListFunc();
        this.getInsuranceCompanyListFunc();
        this.getGroupSystemListFunc();

        this.addHospitalForm = this.formBuilder.group({
            Facility_ID: ['', [Validators.required]],
            Facility_Name: ['', [Validators.required, Validators.pattern("^[a-zA-Z ']+")]],
            Insurance_Company_ID: [[null], [Validators.required]],
            Group_Name: [[null], [Validators.required]]
        });


    }

    get f() { return this.addHospitalForm?.controls; }

    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Hopital') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }
    //Create api addgroup system
    onSubmit() {
        console.log(this.addHospitalForm?.value)
        this.submitted = true;
        if (this.addHospitalForm?.invalid) {
            return;
        }
        this.hospitalService.addHospital(this.addHospitalUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Created Successfully."
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Hospital Already Exist."
                this.reset()
            });



    }

    
    reset() {
        this.submitted = false;
        this.addHospitalForm?.reset();
    }
    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }
    //get api hospital list
    getHospitalListFunc() {
        this.hospitalService.getHospitalList(this.GetAllHospitalListUrl, this.user)
            .subscribe((hospitalList: any) => {
                this.hospitalList = hospitalList.data;
                console.log(this.hospitalList, "hospitalList");
            }, (error: any) => {
                console.log("Get HospitalList Func Error ");
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
            });
    }
    //delete api
    deleteHospital(ID: any) {
        console.log(ID, "ID");
        this.hospitalService.deleteHospital(ID, `${this.DeleteHospitalUrl}/${ID}`)
            .subscribe(response => {
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Deleted Successfully."
                this.ngOnInit();
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error!"
            });
    }

    //Get api Insurance Company
    getInsuranceCompanyListFunc() {
        console.log("Inside Get Insurance Company Func ");
        this.hospitalService.getInsuranceCompanyList(this.InsuranceCompanyUrl).subscribe((dataList: any) => {
            this.dataList = dataList.data;
            console.log(dataList, "Insurance Company List");
        }, (error: any) => {
            console.log(" Get Insurance Companym Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });

    }
    //Get api group sysytem
    getGroupSystemListFunc() {
        console.log("Inside Get GroupSysytem Func ");
        this.hospitalService.getAllGroupSystem(this.GroupSysytemUrl, this.user).subscribe((groupSystemlist: any) => {
            this.groupSystemlist = groupSystemlist.data;
            console.log(groupSystemlist, "groupSystemlist");
        }, (error: any) => {
            console.log(" Get GroupSysytem Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });

    }

    addHospital() {
        this.router.navigate(['/masters/add-hospital']);
    }
}




