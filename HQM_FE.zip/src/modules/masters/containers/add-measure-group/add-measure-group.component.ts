import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild} from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';

import { AddMeasureGroupModel } from './add-measure-group.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
import { Options } from '@angular-slider/ngx-slider';
const APIEndpoint = environment.APIEndpoint;

class DataTablesResponse {
    data?: any[];
    draw?: number;
    recordsFiltered?: number;
    recordsTotal?: number;
}

@Component({
    selector: 'sb-add-group-system',
    templateUrl: './add-measure-group.component.html',
    styleUrls: ['add-measure-group.component.scss'],
    standalone: false
})
export class AddMeasureGroupComponent implements AfterViewInit, OnDestroy, OnInit {
    // Data table
    @ViewChild(DataTableDirective, { static: false })
    dtElement?: DataTableDirective;
    dtTrigger: Subject<void> = new Subject<void>();
    httpHeaders?: HttpHeaders;
    dtOptions: DataTables.Settings = {};
    getTableUrl: string = "";
    persons?: any[];
    postObject: any = {
        user: '1',
    };
    options: Options = {
        floor: 1,
        ceil: 120
    };
    updateGroupUrl: string = '';
    deleteGroupUrl: string = '';
    isUpdate = false;
    alert: boolean = false;
    user: AddMeasureGroupModel;
    measureGroupForm?: FormGroup;
    submitted = false;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    measureGroupUrl: string = '';
    InsuranceCompanyUrl: string = '';
    public serverEndPoint = APIEndpoint;
    dataList: any
    currentUser: any;
    isDisabled: boolean = false;
    displayStyle = "none";
    isLoading: boolean = false;

    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly http: HttpClient, private readonly hospitalService: HospitalService) {
        this.user = new AddMeasureGroupModel();
    }
    ngOnInit() {
        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.User_Id = this.currentUser.ID;
        this.user.Insurance_Company_ID = this.currentUser.Insurance_Company_ID;
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Measure Group';

        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }

        this.measureGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/measuregroup/create";
        this.InsuranceCompanyUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/insurancecompany/getlist";
        this.updateGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/measuregroup/update";
        this.deleteGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/measuregroup/delete";
        this.getTableUrl = this.serverEndPoint + "/rest/private/hqm/v1/measuregroup/pagination";
        const that = this;
      
        this.dtOptions = {
            //  Type : { previous: String, next: String },
            pagingType: 'full_numbers',
            language: {
                emptyTable: '',   // removes "No matching records found"
                zeroRecords: ''   // removes "No matching records found" when filtering
                // you can still customize paginate icons here if needed
            },
            pageLength: 10,
            scrollY: '400',
            scrollX: true,
            serverSide: true,
            processing: true,
            // dom: '<"top"i>rt<"bottom"flp><"clear">',
            dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
            searching: false,
            ajax: (dataTablesParameters: any, callback: DataTablesAjaxCallback) => {
                dataTablesParameters['dateObject'] = this.postObject;
                this.isLoading = true;
                that.http
                    .post<DataTablesResponse>(
                        this.getTableUrl,
                        dataTablesParameters, {
                        headers: new HttpHeaders({
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + sessionStorage.getItem("token")
                        }), withCredentials: true
                    }
                    ).subscribe(resp => {
                        if (resp.data) {
                            this.isLoading = false;
                            that.persons = resp?.data[0];
                            console.log(that.persons, "responce data......");
                            callback({
                                recordsTotal: resp.recordsTotal,
                                recordsFiltered: resp.recordsFiltered,
                                data: []
                            });
                        }
                    });
            },
            columns: [{ data: 'Group_ID' }, { data: 'Group_Name', orderable: false }
            ]
        };

        this.measureGroupForm = this.formBuilder.group({
            measureGroupname: ['', [Validators.required]],
            // Insurance_Company_ID: [null, [Validators.required]]
        });
        this.getInsuranceCompanyListFunc()

    }

    get f() { return this.measureGroupForm?.controls; }

    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

    public isActive(value: any, id: any) {
        this.user.ID = id;
        this.user.Is_Active = value;
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                if (value) {
                    this.successMessageText = "Success! Measure Group Activated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000);
                } else {
                    this.successMessageText = "Success! Measure Group Inactivated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000);
                }
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Measure Group') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }
    //Get Api Insurance_Company_ID
    getInsuranceCompanyListFunc() {
        console.log("Inside Get Insurance Company List Func ");
        this.hospitalService.getInsuranceCompanyList(this.InsuranceCompanyUrl).subscribe((dataList: any) => {
            this.dataList = dataList.data;
            console.log(dataList, "InsuranceCompanyList");
        }, (error: any) => {
            console.log(" Get Insurance Company Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }
    //create api measure group
    onSubmit() {
        this.submitted = true;
        if (this.measureGroupForm?.invalid) {
            return;
        }
        this.hospitalService.addMeasuregroup(this.measureGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Measure Group Created Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Hospital Measure Group Already Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    onUpdate() {
        console.log(this.measureGroupForm?.value)
        this.submitted = true;
        if (this.measureGroupForm?.invalid) {
            return;
        }
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.updateGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Group System Updated Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    reset() {
        this.submitted = false;
        this.errorMessage = false;
        this.isUpdate = false;
        this.measureGroupForm?.reset();
    }

    deleteFun(val: any) {
        console.log("Delete Function", val)
        this.user.ID = val.ID
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Group System Delete Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    editFun(val: any) {
        console.log("Edit Function", val)
        this.isUpdate = true;
        this.user.ID = val.ID;
        this.user.Measure_Group_Name = val.Measure_Group_Name;
        this.user.Insurance_Company_ID = val.Insurance_Company_ID;
    }

    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }
    focusFunction() {
        this.errorMessage = false;

    }
    ngAfterViewInit(): void {
        this.dtTrigger.next();
    }

    ngOnDestroy(): void {
        // Do not forget to unsubscribe the event
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        console.log("rendering file......");
        this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
            // Destroy the table first
            dtInstance.destroy();
            // Call the dtTrigger to rerender again
            this.dtTrigger.next();
        });
    }
}




