
export class AddMeasureGroupModel {
    Measure_Group_Name?: string;
    Insurance_Company_ID?: any;
    User_Id?: any;
    ID?: any;
    role?: string;
    module_name?: string;
    permission?: string;
    Is_Active?: boolean;
    
}