import { Component, OnInit } from '@angular/core';
import { MappingModel } from './mapping.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router, ActivatedRoute } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;

@Component({
    selector: 'sb-mapping',
    //  changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './mapping.component.html',
    styleUrls: ['mapping.component.scss'],
    standalone: false
})
export class MappingComponent implements OnInit {

    alert: boolean = false;
    user: MappingModel;
    mappingForm?: FormGroup;
    submitted = false;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    addGroupUrl: string = '';
    GetAllHospitalListUrl: string = '';
    GetAllMeasureGroupListUrl: string = '';
    GetMeasureIDMappedURL: string = '';
    mappingUrl: string = '';
    getYearsUrl: string = '';
    updateMappingURL: string = '';
    public serverEndPoint = APIEndpoint;
    users: any;
    dataList: any;
    success: any
    error: any
    dismissible = true;
    hospitalList: any;
    measureGrouplist: any;
    MeasureIdMappingList: any

    checkedMeasureIdMappingList: any
    MeasureIdList: any
    Measure_Group_List_ID?: any[];
    selectYear: any = {};
    MeasureIdMapped: any;
    currentUser: any;
    isDisabled: boolean = false;
    displayStyle = "none";
    isLoading: boolean = false;
    isDataShow: boolean = false;

    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router,
        private readonly route: ActivatedRoute,
        private readonly hospitalService: HospitalService) {
        this.user = new MappingModel();
    }

    ngOnInit() {
        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.User_Id = this.currentUser.ID;
        this.user.Insurance_Company_ID = this.currentUser.Insurance_Company_ID;
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Mapping';
        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }

        this.user.Facility_List_ID = null;
        this.user.Measure_Group_List_ID = null;
        this.user.year = null;
        this.user.isCheckedAll = false;
        this.addGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/mapping/create";
        this.GetAllMeasureGroupListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/measuregroup/getlist";
        this.GetAllHospitalListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getlist";
        this.GetMeasureIDMappedURL = this.serverEndPoint + "/rest/private/hqm/v1/mapping/get";
        this.updateMappingURL = this.serverEndPoint + "/rest/private/hqm/v1/mapping/update";
        this.mappingUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/measureidmapping";
        this.getYearsUrl = this.serverEndPoint + "/rest/private/hqm/v1/getYears";

        this.mappingForm = this.formBuilder.group({
            Facility_List_ID: ['', [Validators.required]],
            Measure_Group_List_ID: ['', [Validators.required]],
            Year: ['', [Validators.required]],
            // ID: ['', [Validators.required]],
            // MeasureIdMappingList: this.formBuilder.array([
            //     this.result
            // ]),
        });
        this.getHospitalListFunc();
        this.getAllMeasureGroupList();
        this.getYears();
    }
    get f() { return this.mappingForm?.controls; }

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Mapping') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }

    getYears() {
        this.hospitalService.getYears(this.getYearsUrl)
            .subscribe((yearList: any) => {
                const yearsList = yearList.data;
                console.log(yearsList);
                this.selectYear = yearsList.map((yearObj: { Year: any; }) => ({
                    item_id: yearObj.Year,
                    item_text: yearObj.Year
                }));

            }, (error: any) => {
                console.log("Get Years Func Error ");
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Getting Years Error."
            });
    }
    //get api hospital list
    getHospitalListFunc() {
        this.hospitalService.getHospitalList(this.GetAllHospitalListUrl, this.user)
            .subscribe((hospitalList: any) => {
                this.hospitalList = hospitalList.data;
                console.log(this.hospitalList, "hospitalList");
            }, (error: any) => {
                console.log("Get HospitalList Func Error ");
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
            });
    }

    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

    //Get AllMeasureGroup List
    getAllMeasureGroupList() {
        this.hospitalService.getAllMeasureGroupList(this.GetAllMeasureGroupListUrl, this.user)
            .subscribe((measureGrouplist: any) => {
                this.measureGrouplist = measureGrouplist.data;
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Get Measure Group List Error."
                this.reset()
            });
    }

    onSelectHospital() {
        this.user.Measure_Group_List_ID = null
    }

    onSelectMeasureGroup(val: any) {
        this.user.Measure_Group_List_ID = val
        this.getMeasureIdMappingList();
        console.log(this.user, "on select");
    }

    onSelectYear(val: any) {
        console.log(val, "val");
        this.user.year = val;
        this.user.Facility_List_ID = null;
        this.user.Measure_Group_List_ID = null;

        console.log(this.user, "on select Year");
    }

    //Get MeasureId Mapping List
    getMeasureIdMappingList() {
        this.isLoading = true;
        this.isDataShow = false;
        this.hospitalService.getMeasureIdMapping(this.mappingUrl, this.user)
            .subscribe((MeasureIdMappingList: any) => {
                this.MeasureIdMappingList = MeasureIdMappingList.data;
                if (this.MeasureIdMappingList.length > 0) {
                    console.log(this.MeasureIdMappingList, "MeasureId List");
                    this.hospitalService.getMeasureIdMapped(this.GetMeasureIDMappedURL, this.user)
                        .subscribe((mappedlistResult: any) => {
                            this.isLoading = false;
                            this.isDataShow = true;
                            this.user.checkedIds = mappedlistResult.data;
                            this.checkedMeasureIdMappingList = (this.checkSelected(this.user.checkedIds, this.MeasureIdMappingList));
                            console.log(this.user, "user");
                            console.log(this.checkedMeasureIdMappingList, "mapped list");
                        }, (error: any) => {
                            console.log("error", error)
                            this.successMessage = false;
                            this.errorMessage = true;
                            this.errorMessageText = "Error! Get Measure Group List Error."
                            this.reset()
                        });
                    //--
                } else {
                    this.isLoading = false;
                }
            }, (error: any) => {
                console.log(" Get MeasureIdMappingList Func Error ");
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
            });
    }


    public isChekedRow(value: boolean, id: any) {
        console.log(value, id, "id..................................................................................................");
        if (value) {
            this.user.checkedIds.push({ Measure_ID_List_ID: id + "" });
            console.log("true", this.user);
        } else {
            for (let i = 0; i < this.user.checkedIds.length; i++) {
                if (this.user.checkedIds[i].Measure_ID_List_ID === id + "") {
                    console.log(id, "true", this.user);
                    this.user.checkedIds.splice(i, 1);
                }
            }
            console.log("select all remove");
            this.user.isCheckedAll = false;
        }
    }

    checkSelected(checkedIds: any[], MeasureIdMappingList: any[]) {
    if (!Array.isArray(MeasureIdMappingList)) {
        return [];
    }

    const hasCheckedIds = Array.isArray(checkedIds) && checkedIds.length > 0;

    for (const item of MeasureIdMappingList) {
        item.isSelected = false;

        if (hasCheckedIds) {
            for (const checked of checkedIds) {
                if (String(checked.Measure_ID_List_ID) === String(item.ID)) {
                    item.isSelected = true;
                    break;
                }
            }
        }
    }

    return MeasureIdMappingList;
}


    //Create api addgroup system
    onSubmit() {
        console.log("inside onSubmit", this.user);
        this.result()
        this.submitted = true;
        if (this.mappingForm?.invalid) {
            return;
        }
        console.log("Form Validate True", this.user);

        this.hospitalService.addMapping(this.updateMappingURL, this.user)
            .subscribe((response: any) => {
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Mapping Updated Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000);
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Hospital Group Already Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000);
                this.reset()
            });
    }

    reset() {
        this.submitted = false;
        this.mappingForm?.reset();
    }

    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }

    checkAllCheckBox(value: any) {
        console.log("Check All Check box..", value);
        if (value) {
            console.log("true");
            this.user.isCheckedAll = true;
            this.user.checkedIds = [];
            for (const element of this.MeasureIdMappingList) {
                this.user.checkedIds.push({ Measure_ID_List_ID: element.ID + "" });
                element.isSelected = true;
            }
            console.log(this.MeasureIdMappingList, "True");
        } else {
            console.log("false");
            this.user.checkedIds = []
            this.user.isCheckedAll = false;
            for (const element of this.MeasureIdMappingList) {
                element.isSelected = false;
            }
            console.log(this.MeasureIdMappingList, "false");
        }
    }

    isAllCheckBoxChecked() {
        console.log("Check All..");
    }

    multipleCheck(val: any) {
        console.log("Multiple Check.", val);
    }

    result() { /*  'result' is empty */ }
}







