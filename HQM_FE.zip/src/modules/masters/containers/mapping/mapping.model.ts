
export class MappingModel {
    Facility_List_ID?: any;
    year?: any;
    Measure_Group_List_ID?: any;
    ID?: string;
    Insurance_Company_ID?: 1
    checkedIds:any;
    User_Id:any;
    isCheckedAll:any;
    role?: string;
    module_name?: string;
    permission?: string;
}