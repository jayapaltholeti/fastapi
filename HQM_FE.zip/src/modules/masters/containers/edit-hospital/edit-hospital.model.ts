
export class HostpitalModel {

    Facility_Name?: string;
    Facility_ID?: string;
    Hospital_Group_ID?: string;
    Insurance_Company_ID?: string;
    User_Id?: any;
    role?: string;
    module_name?: string;
    permission?: string;
    Is_Active?: boolean;
}