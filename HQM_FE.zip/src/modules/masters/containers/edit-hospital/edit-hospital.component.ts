import { Component, OnInit } from '@angular/core';
import { HostpitalModel } from './edit-hospital.model'
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router, ActivatedRoute } from '@angular/router';

const APIEndpoint = environment.APIEndpoint;

@Component({
    selector: 'sb-edit-hospital',
    // changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './edit-hospital.component.html',
    styleUrls: ['edit-hospital.component.scss'],
    standalone: false
})
export class EditHospitalComponent implements OnInit {
    GetAllHospitalListUrl: string = '';
    UpdateHospitalUrl: string = '';
    InsuranceCompanyUrl: string = '';
    GroupSysytemUrl: string = '';
    alert: boolean = false;
    user: HostpitalModel;
    addHospitalForm?: FormGroup;
    submitted = false;
    public serverEndPoint = APIEndpoint;
    users: any;
    measureGrouplist: any;
    measureIdlist: any;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    dataList: any;
    hospitalList = {
        Facility_Name: '',
        Facility_ID: '',
        Hospital_Group_ID: '',
        Insurance_Company_ID: '',
        Insurance_Company_Name: '',
        Group_Name: ''
    }
    groupSystemlist: any;
    closeResult: any;
    content: any;
    currentUser: any;
    isDisabled: boolean = false;

    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router,
        private readonly modalService: NgbModal,
        private readonly route: ActivatedRoute,
        private readonly hospitalService: HospitalService) {
        this.user = new HostpitalModel();

    }
    ngOnInit() {
        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
         this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.User_Id = this.currentUser.ID;
        this.user.Insurance_Company_ID = this.currentUser.Insurance_Company_ID;
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Hopital';
        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }
        this.GetAllHospitalListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getlist";
        this.UpdateHospitalUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/update";
        this.InsuranceCompanyUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/insurancecompany/getlist";
        this.GroupSysytemUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/group/getlist";

        this.addHospitalForm = this.formBuilder.group({
            Facility_ID: ['', [Validators.required]],
            Facility_Name: ['', [Validators.required, Validators.pattern("^[a-zA-Z']+")]],
            // Insurance_Company_ID: [[null], [Validators.required]],
            Hospital_Group_ID: [[null], [Validators.required]]
        });

        this.getHospitalByIdList();
        this.getGroupSystemListFunc()
    }

    get f() { return this.addHospitalForm?.controls; }

    //Create api addgroup system
    onSubmit() {
        console.log(this.addHospitalForm?.value)
        this.submitted = true;
        if (this.addHospitalForm?.invalid) {
            return;
        }
        this.hospitalService.updateHospitalData(`${this.UpdateHospitalUrl}/${this.route.snapshot.params.ID}`, this.hospitalList)
            .subscribe((response: any) => {
                console.log("response", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Hospital Updated Successfully."
                this.router.navigate(['/masters/hospital-list']);
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error!"
            });
    }

    reset() {
        this.submitted = false;
        this.addHospitalForm?.reset();
    }
    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Hopital') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }
    getHospitalByIdList() {
        console.log("inside getMemberDetails", this.users);
        this.hospitalService.getHospitalById(this.route.snapshot.params.ID, this.users)
            .subscribe((hospitalListResult: any) => {
                this.hospitalList.Facility_Name = hospitalListResult.data[0].Facility_Name;
                this.hospitalList.Facility_ID = hospitalListResult.data[0].Facility_ID;
                this.hospitalList.Hospital_Group_ID = hospitalListResult.data[0].Hospital_Group_ID;
                this.hospitalList.Insurance_Company_ID = hospitalListResult.data[0].Insurance_Company_ID;
                this.hospitalList.Insurance_Company_Name = hospitalListResult.data[0].Insurance_Company_Name;
                this.hospitalList.Group_Name = hospitalListResult.data[0].Group_Name;
                console.log(this.hospitalList, "getHospitalByIdList");
            }, (error: any) => {
                console.log(" Get Hospital Func Error ");
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
            });
    }

    //Get api  insurance company list
    getInsuranceCompanyListFunc() {
        console.log("Inside Get Insurance Company List Func ");
        this.hospitalService.getInsuranceCompanyList(this.InsuranceCompanyUrl).subscribe((dataList: any) => {
            this.dataList = dataList.data;
            console.log(dataList, "InsuranceCompanyList");
        }, (error: any) => {
            console.log(" Get Insurance Company Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }
    //Get api group sysytem list
    getGroupSystemListFunc() {
        console.log("Inside Get GroupSysytem List Func ");
        this.hospitalService.getAllGroupSystem(this.GroupSysytemUrl, this.user).subscribe((groupSystemlist: any) => {
            this.groupSystemlist = groupSystemlist.data;
            console.log(groupSystemlist, "GroupSysytem");
        }, (error: any) => {
            console.log(" Get GroupSysytem Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        })
    }
    gethospitalList() {
        this.router.navigate(['/masters/hospital-list']);
    }

    addGroup() {
        this.router.navigate(['/masters/add-group-system']);
    }
}



