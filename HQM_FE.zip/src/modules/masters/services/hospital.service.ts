import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
const APIEndpoint = environment.APIEndpoint;
import { Router, ActivatedRoute } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class HospitalService {

  httpHeaders?: HttpHeaders;
  constructor(private httpClient: HttpClient, private router: Router) { }

  setHeader() {
    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
    }
    this.httpHeaders = new HttpHeaders().set('Accept', 'application/json');
    // this.httpHeaders = this.httpHeaders.append('Content-Type', 'text');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Origin', '20.124.91.34');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Credentials', 'true');//
    this.httpHeaders = this.httpHeaders.append("Authorization", 'Bearer ' + sessionStorage.getItem("token"));
  }
  url2 = APIEndpoint + "/rest/private/hqm/v1/hospital/getbyid";

  // url2 = "http://localhost:7001/api/rest/private/hqm/v1/hospital/measureidmapping";
  // mappingUrl = APIEndpoint + "/rest/private/hqm/v1/hospital/measureidmapping";
  // url3 = "http://localhost:7001/api/rest/private/hqm/v1/hospital/measureidmapping";
  // url = "http://localhost:7001/api/rest/private/hqm/v1/hospital/delete";
  getAuth$(): Observable<{}> {
    return of({});
  }
  addGroupsystem(url: string, payload: any): Observable<any> {
    // console.log('url', url);
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  addMeasuregroup(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }

  addMeasuregroupId(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  addHospital(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  addMapping(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  getHospitalList(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  getInsuranceCompanyList(url: string): Observable<any[]> {
    this.setHeader();
    return this.httpClient.get<any[]>(url,{ headers: this.httpHeaders, withCredentials: true });
  }
  getYears(url: string): Observable<any[]> {
    this.setHeader();
    return this.httpClient.get<any[]>(url,{ headers: this.httpHeaders, withCredentials: true });
  }

  getAllGroupSystem(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders,withCredentials: true });

  }

 


  // postRequest(url: string, payload: any): Observable<any> {
  //   this.setHeader();
  //   // console.log('url', url); 
  //   return this.httpClient.post(url, payload, { headers: this.httpHeaders });
  // }


  deleteHospital(ID: any, url: string): Observable<any[]> {
    this.setHeader();
    return this.httpClient.post<any[]>(url, { headers: this.httpHeaders, withCredentials: true })
  }
  getHospitalById(ID: number, payload: any) {
    this.setHeader();
    return this.httpClient.post(`${this.url2}/${ID}`, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  getMeasureIdMapping(url: string, payload: any) {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }

  // getMeasureIdMapping(url: string, payload: any): Observable<any> {
  //   return this.httpClient.post(`${this.url3}`, payload, { headers: this.httpHeaders });
  // }

  getMeasureIdMapped(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }

  updateHospitalData(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }

  // getAllMeasureGroupList(url: string): Observable<any[]> {
  //   return this.httpClient.get<any[]>(url)
  // }

  getAllMeasureGroupList(url: string, payload: any): Observable<any> {
    this.setHeader();
    // console.log('url', url); 
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  getAllMeasureIdList(url: string): Observable<any> {
    this.setHeader();
    return this.httpClient.get<any>(url,{ headers: this.httpHeaders, withCredentials: true })
  }

  postRequest(url: string, payload: any): Observable<any> {
    this.setHeader();
    // console.log('url', url); 
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }

}



