/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SBRouteData } from '@modules/navigation/models';

/* Module */
import  {MastersModule} from './masters.module'

import  * as  mastersContainers from './containers'


/* Routes */
export const ROUTES: Routes = [

    {
        path: 'add-group-system',
        canActivate: [],
        component: mastersContainers.AddGroupSystemComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
            breadcrumbs: [
                {
                    text: 'Masters',
                    active: true,
                },
            ],
        } as SBRouteData,
    },

    {
        path: 'add-measure-group',
        canActivate: [],
        component: mastersContainers.AddMeasureGroupComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },
    {
        path: 'add-measure-id',
        canActivate: [],
        component: mastersContainers.AddMeasureIdComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },
    {
        path: 'add-hospital',
        canActivate: [],
        component: mastersContainers.AddHospitalComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },
    {
        path: 'hospital-list',
        canActivate: [],
        component: mastersContainers.HospitalListComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },
    {
        path: 'edit-hospital/:ID',
        canActivate: [],
        component: mastersContainers.EditHospitalComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },
    {
        path: 'mapping',
        canActivate: [],
        component: mastersContainers.MappingComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },

];

@NgModule({
imports: [MastersModule,RouterModule.forChild(ROUTES)
],
    exports: [RouterModule],
})
export class MastersRoutingModule {}
