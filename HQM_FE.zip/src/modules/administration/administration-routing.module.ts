/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SBRouteData } from '@modules/navigation/models';

/* Module */
import  {AdministrationModule} from './administration.module'

import  * as  administrationContainers from './containers'


/* Routes */
export const ROUTES: Routes = [

    {
        path: 'users',
        canActivate: [],
        component: administrationContainers.UsersComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
            breadcrumbs: [
                {
                    text: 'Masters',
                    active: true,
                },
            ],
        } as SBRouteData,
    },

    {
        path: 'roles',
        canActivate: [],
        component: administrationContainers.RolesComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },


];

@NgModule({
    imports: [RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class AdministrationRoutingModule {}
