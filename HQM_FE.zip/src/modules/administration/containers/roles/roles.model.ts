
export class RolesModel {
    Group_ID?: string;
    Group_Name?: string;
    Insurance_Company_ID?: string;

}