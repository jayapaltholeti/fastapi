import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { RolesModel } from './roles.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;

@Component({
    selector: 'sb-roles',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './roles.component.html',
    styleUrls: ['roles.component.scss'],
    standalone: false
})
export class RolesComponent implements OnInit {
    waitMessage: boolean = false;
    waitMessageText: string = '';

    alert: boolean = false;
    user: RolesModel;
    addGroupForm?: FormGroup;
    submitted = false;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    addGroupUrl: string = '';
    public serverEndPoint = APIEndpoint;
    users: any;
    dataList: any;
    success: any
    error: any

    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly hospitalService: HospitalService) {
        this.user = new RolesModel();
    }
    ngOnInit() {
        this.addGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/group/create";
        this.addGroupForm = this.formBuilder.group({
            groupId: ['', [Validators.required]],
            groupName: ['', [Validators.required, Validators.pattern('^[a-zA-Z -\']+')]],
            Insurance_Company_ID: [null]
        });

    }
    get f() { return this.addGroupForm?.controls; }

    //Create api addgroup system
    onSubmit() {
        console.log(this.addGroupForm?.value)
        this.submitted = true;
        if (this.addGroupForm?.invalid) {
            this.addGroupForm.reset();
            return;
        }
        this.hospitalService.addGroupsystem(this.addGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.addGroupForm?.reset(this.user);
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success!"
            }, (error: any) => {
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
            });
    }
}




