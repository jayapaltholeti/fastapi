import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { UsersModel } from './users.model'
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;
class DataTablesResponse {
    data?: any[];
    draw?: number;
    recordsFiltered?: number;
    recordsTotal?: number;
}

@Component({
    selector: 'sb-users',
    templateUrl: './users.component.html',
    styleUrls: ['users.component.scss'],
    standalone: false
})
export class UsersComponent implements AfterViewInit, OnDestroy, OnInit {
    Role: string | null = null;
    searchText: string = '';
    persons: any[] = [];   // also needed for your filter pipe

    // Data table
    @ViewChild(DataTableDirective, { static: false })
    dtElement?: DataTableDirective;
    dtTrigger: Subject<void> = new Subject<void>();
    httpHeaders?: HttpHeaders;

    dtOptions: DataTables.Settings = {};
    getTableUrl: string = "";
    postObject: any = {
        user: '1',
    };
    isUpdate = false;
    GetAllHospitalListUrl: string = '';
    addHospitalUrl: string = '';
    updateGroupUrl: string = '';
    deleteGroupUrl: string = '';
    InsuranceCompanyUrl: string = '';
    roleListUrl: string = '';
    alert: boolean = false;
    user: UsersModel;
    addUserForm?: FormGroup;
    submitted = false;
    public serverEndPoint = APIEndpoint;
    users: any;
    measureGrouplist: any;
    measureIdlist: any;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    dataList: any;
    hospitalList: any;
    roleList: any;
    closeResult: any;
    content: any;
    currentUser: any;
    isDisabled: boolean = false;
    isfieldDisabled: boolean = false;
    displayStyle = "none";
    isLoading: boolean = false

    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly http: HttpClient,
        private readonly hospitalService: HospitalService) {
        this.user = new UsersModel();

    }

    ngOnInit() {
        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        console.log("ngOnInit Loading......");
        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.User_Id = this.currentUser.ID;
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Hopital';
        this.user.Roles_ID = null;

        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }

        console.log("user....... model......", this.user);
        this.user.Insurance_Company_ID = this.currentUser.Insurance_Company_ID;
        this.GetAllHospitalListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getlist";
        this.addHospitalUrl = this.serverEndPoint + "/rest/private/hqm/v1/user/create";
        this.InsuranceCompanyUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/insurancecompany/getlist";
        this.roleListUrl = this.serverEndPoint + "/rest/private/hqm/v1/user/role/getlist";
        this.updateGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/user/update";
        this.deleteGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/user/delete";
        this.getTableUrl = this.serverEndPoint + "/rest/private/hqm/v1/user/pagination";

        const that = this;
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 10,
            processing: true,
            responsive: true,
            dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
            searching: true,
            language: {
                /* paginate: {
                    previous: "<i class='fa fa-angle-left arrow left' aria-hidden='true'></i>",
                    next: "<i class='fa fa-angle-right arrow right' aria-hidden='true'></i>"
                  }*/
            },
        };
        this.dtOptions = {
            //  Type : { previous: String, next: String },
            pagingType: 'full_numbers',
            language: {
                // paginate: {
                //   previous: "<i class='fa fa-angle-left' aria-hidden='true'></i>",
                //   next: "<i class='fa fa-angle-right' aria-hidden='true'></i>"
                // }
            },
            pageLength: 10,
            scrollY: '400',
            scrollX: true,
            serverSide: true,
            processing: true,
            // dom: '<"top"i>rt<"bottom"flp><"clear">',
            dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
            searching: false,
            ajax: (dataTablesParameters: any, callback: DataTablesAjaxCallback) => {
                dataTablesParameters['dateObject'] = this.postObject;
                this.isLoading = true
                that.http
                    .post<DataTablesResponse>(
                        this.getTableUrl,
                        dataTablesParameters,
                        {
                            headers: new HttpHeaders({
                                'Content-Type': 'application/json',
                                'Authorization': 'Bearer ' + sessionStorage.getItem("token")
                            })
                        }
                    ).subscribe(resp => {
                        console.log(resp, "responce data......");
                        if (resp.data) {
                            this.isLoading = false;
                            that.persons = resp?.data[0];
                            console.log(that.persons, "responce data......");
                            callback({
                                recordsTotal: resp.recordsTotal,
                                recordsFiltered: resp.recordsFiltered,
                                data: []
                            });
                        }
                    });
            },
            columns: [{ data: 'First_Name' }, { data: 'Last_Name' }, { data: 'Email' }, { data: 'Role' }, { data: null, orderable: false }
            ]
        };


        if (this.isfieldDisabled) {
            console.log(this.isfieldDisabled, "Admin true............")
            this.addUserForm = this.formBuilder.group({
                First_Name: ['', [Validators.required, Validators.pattern('^[a-zA-Z -\']+')]],
                Last_Name: ['', [Validators.required, Validators.pattern('^[a-zA-Z -\']+')]],
                Email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$')]],
                // Insurance_Company_ID: [[null], [Validators.required]],
                // Role: [[null], [Validators.required]]
            });
        } else {
            this.addUserForm = this.formBuilder.group({
                First_Name: ['', [Validators.required, Validators.pattern('^[a-zA-Z -\']+')]],
                Last_Name: ['', [Validators.required, Validators.pattern('^[a-zA-Z -\']+')]],
                Email: ['', [Validators.required, Validators.pattern('^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$')]],
                // Insurance_Company_ID: [[null], [Validators.required]],
                Role: [[null], [Validators.required]]
            });
        }

    }

    get f() { return this.addUserForm?.controls; }

    handleKey(event: KeyboardEvent): void {
        // TODO: implement logic
    }

    //Create api addgroup system
    onSubmit() {
        console.log(this.addUserForm?.value)
        this.submitted = true;
        if (this.addUserForm?.invalid) {
            return;
        }
        this.hospitalService.addHospital(this.addHospitalUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! User Created Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000)
                this.reset()
                this.rerender();
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! User Already Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000)
                this.reset()
            });
    }

    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'User') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }

    //Get api hospital list
    getHospitalListFunc() {
        console.log("Inside Get Hospital Func ");
        this.hospitalService.getHospitalList(this.GetAllHospitalListUrl, this.user).subscribe((hospitalListResult: any) => {
            this.hospitalList = hospitalListResult.data.recordset;
            console.log(this.hospitalList, "Hospital List");
        }, (error: any) => {
            console.log(" Get Hospital Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    public isActive(value: any, id: any) {
        this.user.ID = id;
        this.user.Is_Active = value;
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                if (value) {
                    this.successMessageText = "Success! User Activated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000)
                } else {
                    this.successMessageText = "Success! User Inactivated Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000)
                }
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Group System Not Exist."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000)
                this.reset()
            });
    }

    //Get api  insurance company list
    getInsuranceCompanyListFunc() {
        console.log("Inside Get Insurance Company List Func ");
        this.hospitalService.getInsuranceCompanyList(this.InsuranceCompanyUrl).subscribe((dataList: any) => {
            this.dataList = dataList.data;
            console.log(dataList, "InsuranceCompanyList");
        }, (error: any) => {
            console.log(" Get Insurance Company Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }
    //Get api group sysytem list
    getGroupSystemListFunc() {
        console.log("Inside Get GroupSysytem List Func ");
        this.hospitalService.getAllGroupSystem(this.roleListUrl, this.user).subscribe((roleListResult: any) => {
            this.roleList = roleListResult.data;
            console.log(roleListResult, "GroupSysytem");
        }, (error: any) => {
            console.log(" Get GroupSysytem Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        })
    }


    deleteFun(val: any) {
        if (confirm("Are you sure!  You want to delete this User?")) {
            console.log("Implement delete functionality here");
            console.log("Delete Function", val)
            this.user.ID = val.User_ID
            console.log(this.user, "User Object..");
            this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
                .subscribe((response: any) => {
                    console.log(this.user, "user")
                    console.log("Responce", response)
                    this.errorMessage = false;
                    this.successMessage = true;
                    this.successMessageText = "Success! User Deleted Successfully."
                    setTimeout(() => {
                        this.successMessageText = '';
                        this.successMessage = false;
                    }, 2000)
                    this.rerender();
                    this.reset()
                }, (error: any) => {
                    console.log("error", error)
                    this.successMessage = false;
                    this.errorMessage = true;
                    this.errorMessageText = "Error! User Not Exist."
                    setTimeout(() => {
                        this.errorMessageText = '';
                        this.errorMessage = false;
                    }, 2000)
                    this.reset()
                });
        }
    }

    editFun(val: any) {
        console.log("Edit Function11", val);

        this.isfieldDisabled = false;

        if (this.user.role === 'Admin' && this.user.User_Id === val.User_ID) {
            console.log("true..........................s");
            this.ngOnInit();
            this.isfieldDisabled = true;
            console.log("true", this.isfieldDisabled);
        }

        this.isUpdate = true;
        this.user.ID = val.User_ID;
        this.user.Roles_ID = Number.parseInt(val.Roles_ID);
        this.user.First_Name = val.First_Name;
        this.user.Last_Name = val.Last_Name;
        this.user.Email = val.Email;

        console.log("User Object", this.user);
    }


    onUpdate() {
        console.log(this.addUserForm?.value)
        this.submitted = true;
        if (this.addUserForm?.invalid) {
            return;
        }
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.updateGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! User Updated Successfully."
                setTimeout(() => {
                    this.successMessageText = '';
                    this.successMessage = false;
                }, 2000)
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! User Not Exist."
                setTimeout(() => {
                    this.errorMessageText = '';
                    this.errorMessage = false;
                }, 2000)
                this.reset()
            });
    }
    gethospitalList() {
        this.router.navigate(['/masters/hospital-list']);
    }

    addGroup() {
        this.router.navigate(['/masters/add-group-system']);
    }

    reset() {
        this.isfieldDisabled = false;
        this.submitted = false;
        this.errorMessage = false;
        this.isUpdate = false;
        this.addUserForm?.reset();
    }

    ngAfterViewInit(): void {
        this.dtTrigger.next(); // valid now
    }

    ngOnDestroy(): void {
        // Do not forget to unsubscribe the event
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        console.log("rendering file......");
        this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
            dtInstance.destroy();
            this.dtTrigger.next(); // still valid
        });
    }

    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

}




