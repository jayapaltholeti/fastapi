
export class UsersModel {
    First_Name?: string;
    Last_Name?: string;
    Email?: string;
    Role?: string;
    Roles_ID?: any;
    Insurance_Company_ID?: any;
    User_Id:any;
    ID?: any;
    role?: string;
    module_name?: string;
    permission?: string;
    Is_Active?: boolean;


}