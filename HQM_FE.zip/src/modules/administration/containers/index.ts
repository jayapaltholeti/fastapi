
import { RolesComponent } from './roles/roles.component';
import { UsersComponent } from './users/users.component';


export const containers = [ RolesComponent,UsersComponent];


export * from './roles/roles.component';
export * from './users/users.component';



