/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

// import { NgxPaginationModule } from 'ngx-pagination';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { DataTablesModule } from 'angular-datatables';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';

/* Components */
import * as mastersComponents from './components';

/* Containers */
import * as mastersContainers from './containers';

/* Guards */
import * as mastersGuards from './guards';

/* Services */
import * as hospitalServices from './services';

/* Custom Pipes */
import { SharedModule } from '../../app/shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    NgbModule,
    BsDatepickerModule,
    // NgxPaginationModule,
    ReactiveFormsModule,
    FormsModule,
    AppCommonModule,
    NavigationModule,
    DataTablesModule,
    SharedModule,
  ],
  providers: [
    ...hospitalServices.services,
    ...mastersGuards.guards
  ],
  declarations: [
    ...mastersContainers.containers,
    ...mastersComponents.components,
  ],
  exports: [
    ...mastersContainers.containers,
    ...mastersComponents.components,
  ]
})
export class AdministrationModule {}
