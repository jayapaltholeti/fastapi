import { HospitalService } from './hospital.service';


export const services = [HospitalService];

export * from './hospital.service';



