import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable({
    providedIn: 'root'
  })
export class HospitalService {
    private readonly apiURL = "http://localhost:7001/api/rest/private/hqm/v1/hospital/insurancecompany/getlist";
    private readonly url = "http://localhost:7001/api/rest/private/hqm/v1/hospital/measuregroup/getlist";
    private readonly url2 = "http://localhost:7001/api/rest/private/hqm/v1/hospital/measureidlist/getlist";

    httpHeaders?: HttpHeaders;
    constructor(private httpClient: HttpClient) { }

    setHeader() {
      this.httpHeaders = new HttpHeaders().set('Accept', 'application/json');
      this.httpHeaders = this.httpHeaders.append('Content-Type', 'text');
    }

    getAuth$(): Observable<{}> {
        return of({});
    }
    addGroupsystem(url: string, payload: any): Observable<any> {
        return this.httpClient.post(url, payload, { headers: this.httpHeaders });
      }
      addMeasuregroup(url: string, payload: any): Observable<any> {
        return this.httpClient.post(url, payload, { headers: this.httpHeaders });
      }
      addMeasuregroupId(url: string, payload: any): Observable<any> {
        return this.httpClient.post(url, payload, { headers: this.httpHeaders });
      }
      getAll(): Observable<any[]> {
        return this.httpClient.get<any[]>(this.apiURL)
      }
      getAllMeasureGroupList(): Observable<any[]> {
        return this.httpClient.get<any[]>(this.url)
      }
      getAllMeasureIdList(): Observable<any[]> {
        return this.httpClient.get<any[]>(this.url2)
      }


}



