import { TestBed } from '@angular/core/testing';

import {HospitalService} from './hospital.service'

describe('HospitalService', () => {
    let hospitalService: HospitalService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [HospitalService],
        });
        hospitalService = TestBed.inject(HospitalService);
    });

    describe('getAuth$', () => {
        it('should return Observable<Auth>', () => {
            hospitalService.getAuth$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});

