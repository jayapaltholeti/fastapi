import { Injectable } from '@angular/core';
import { Observable, ReplaySubject } from 'rxjs';

import { User } from '../models';

const userSubject: ReplaySubject<User> = new ReplaySubject(1);

@Injectable()
export class UserService {
    
    constructor() {
        let currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user = {
            id: currentUser.id,
            firstName: currentUser.firstname,
            lastName: currentUser.lastname,
            email: currentUser.email,
        };
    }

    set user(user: User) {
        userSubject.next(user);
    }

    get user$(): Observable<User> {
        return userSubject.asObservable();
    }
}
