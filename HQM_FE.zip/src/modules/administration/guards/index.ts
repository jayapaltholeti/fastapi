import { MastersGuard } from './masters.guard';

export const guards = [MastersGuard];

export * from './masters.guard';

