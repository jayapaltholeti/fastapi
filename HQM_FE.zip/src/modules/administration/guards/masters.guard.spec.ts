import { TestBed } from '@angular/core/testing';

import { MastersGuard } from './masters.guard';

describe('Hospital Guards', () => {
    let mastersGuard: MastersGuard;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [],
            providers: [MastersGuard],
        });
        mastersGuard = TestBed.inject(MastersGuard);
    });

    describe('canActivate', () => {
        it('should return an Observable<boolean>', () => {
            mastersGuard.canActivate().subscribe(response => {
                expect(response).toEqual(true);
            });
        });
    });
});
