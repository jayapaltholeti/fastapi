/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SBRouteData } from '@modules/navigation/models';

/* Module */
import  {ReportsModule} from './reports.module'

import  * as  reportsContainers from './containers'
 
/* Guards */
import * as mastersGuards from './guards'

/* Routes */
export const ROUTES: Routes = [



    {
        path: 'reports',
        canActivate: [],
        component: reportsContainers.ReportsComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },

    {
        path: 'analytic',
        canActivate: [],
        component: reportsContainers.AnalyticComponent,
        data: {
            title: 'Pages Login - SB Admin Angular',
        } as SBRouteData,
    },

];

@NgModule({
    imports: [ReportsModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class ReportsRoutingModule {}
