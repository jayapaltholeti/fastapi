/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';

/* Components */
import * as mastersComponents from './components';

/* Containers */
import * as mastersContainers from './containers'

/* Guards */
import * as mastersGuards from './guards'

/* Services */
import * as hospitalServices from './services'

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        FormsModule,
        AppCommonModule,
        NavigationModule,
    ],

    providers: [ ...hospitalServices.services,...mastersGuards.guards],
    declarations: [...mastersContainers.containers, ...mastersComponents.components],
    exports: [...mastersContainers.containers, ...mastersComponents.components],
})
export class ReportsModule {}

