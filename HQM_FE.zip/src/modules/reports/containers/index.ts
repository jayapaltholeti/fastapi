
import { ReportsComponent } from './reports/reports.component';
import { AnalyticComponent } from './analytic/analytic.component';


export const containers = [ ReportsComponent, AnalyticComponent];


export * from './reports/reports.component';
export * from './analytic/analytic.component';


