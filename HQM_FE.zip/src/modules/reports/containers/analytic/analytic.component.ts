import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { AnalyticModel } from './analytic.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router, ActivatedRoute } from '@angular/router';

const APIEndpoint = environment.APIEndpoint;

@Component({
    selector: 'sb-analytic',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './analytic.component.html',
    styleUrls: ['analytic.component.scss'],
    standalone: false
})
export class AnalyticComponent implements OnInit {
    waitMessage = false;
    waitMessageText = '';
    alert: boolean = false;
    user: AnalyticModel;
    addGroupForm?: FormGroup;
    submitted = false;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    addGroupUrl: string = '';
    public serverEndPoint = APIEndpoint;
    users: any;
    dataList: any;
    success: any
    error: any
    displayStyle = "none";
    constructor(private formBuilder: FormBuilder, private router: Router, private hospitalService: HospitalService) {
        this.user = new AnalyticModel();
    }
    ngOnInit() {

        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        this.addGroupUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/group/create";
        this.addGroupForm = this.formBuilder.group({
            groupId: ['', [Validators.required]],
            groupName: ['', [Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]],
            Insurance_Company_ID: [null]
        });

    }
    get f() { return this.addGroupForm?.controls; }
    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }


    //Create api addgroup system
    onSubmit() {
        console.log(this.addGroupForm?.value)
        this.submitted = true;
        if (this.addGroupForm?.invalid) {
            this.addGroupForm.reset();
            return;
        }
        this.hospitalService.addGroupsystem(this.addGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.addGroupForm?.reset(this.user);
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success!"
                setTimeout(() => {
                    this.successMessage = true;
                }, 2500)
            }, (error: any) => {
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
                setTimeout(() => {
                    this.errorMessage = true;
                }, 2500)
            });
    }
}




