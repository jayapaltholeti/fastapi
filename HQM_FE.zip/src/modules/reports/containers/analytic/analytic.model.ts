
export class AnalyticModel {
    Group_ID?: string;
    Group_Name?: string;
    Insurance_Company_ID?: string;

}