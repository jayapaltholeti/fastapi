import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ReportsModel } from '../containers/reports/reports.model';
import { Router, ActivatedRoute } from '@angular/router';



@Injectable({
  providedIn: 'root'
})
export class HospitalService {
  private apiURL = "http://localhost:7001/api/rest/private/hqm/v1/hospital/insurancecompany/getlist";
  private url = "http://localhost:7001/api/rest/private/hqm/v1/hospital/measuregroup/getlist";
  private url2 = "http://localhost:7001/api/rest/private/hqm/v1/hospital/measureidlist/getlist";

  httpHeaders?: HttpHeaders;
  constructor(private httpClient: HttpClient, private router: Router) { }

  setHeader() {
    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
    }
    this.httpHeaders = new HttpHeaders().set('Accept', 'application/json');
    // this.httpHeaders = this.httpHeaders.append('Content-Type', 'text');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Origin', '20.124.91.34');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Credentials', 'true');//
    this.httpHeaders = this.httpHeaders.append("Authorization", 'Bearer ' + sessionStorage.getItem("token"));
  }

  getAuth$(): Observable<{}> {
    return of({});
  }
  addGroupsystem(url: string, payload: any): Observable<any> {
    // console.log('url', url);
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  addMeasuregroup(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  addMeasuregroupId(url: string, payload: any): Observable<any> {
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }
  getAll(): Observable<any[]> {
    this.setHeader();
    return this.httpClient.get<any[]>(this.apiURL)
  }
  getAllMeasureGroupList(): Observable<any[]> {
    this.setHeader();
    return this.httpClient.get<any[]>(this.url)
  }
  getAllMeasureIdList(): Observable<any[]> {
    this.setHeader();
    return this.httpClient.get<any[]>(this.url2)
  }
}



