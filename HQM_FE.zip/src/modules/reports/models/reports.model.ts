export interface Reports {
    id: string;
    firstName: string;
    lastName: string;
    email: string;
}
