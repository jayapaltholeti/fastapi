import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router } from '@angular/router';



@Injectable({
  providedIn: 'root'
})
export class PayoutService {
  getAuth$() {
      throw new Error('Method not implemented.');
  }

  httpHeaders?: HttpHeaders;
  constructor(private readonly httpClient: HttpClient, private readonly router: Router) { }

  setHeader() {
    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
    }
    this.httpHeaders = new HttpHeaders().set('Accept', 'application/json');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Origin', '20.124.91.34');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    this.httpHeaders = this.httpHeaders.append("Authorization", 'Bearer ' + sessionStorage.getItem("token"));
  }

  getRequest(url: string): Observable<any> {
    this.setHeader();
    console.log('this.httpHeaders', this.httpHeaders);
    return this.httpClient.get(url, { headers: this.httpHeaders,withCredentials: true });
  }

  postRequest(url: string, payload: any): Observable<any> {
    this.setHeader();
    console.log('this.httpHeaders post ', this.httpHeaders);
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }

}
