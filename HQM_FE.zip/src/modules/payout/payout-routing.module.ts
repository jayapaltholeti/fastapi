/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SBRouteData } from '@modules/navigation/models';

/* Module */
import { PayoutModule } from './payout.module'

import * as payoutContainers from './containers'

/* Routes */
export const ROUTES: Routes = [

    {
        path: 'upload',
        canActivate: [],
        component: payoutContainers.UploadComponent,
        data: {
            title: 'Pages Login - HQM',
            breadcrumbs: [
                {
                    text: 'Masters',
                    active: true,
                },
            ],
        } as SBRouteData,
    },

    {
        path: 'calculate-payout',
        canActivate: [],
        component: payoutContainers.CalculatePayoutComponent,
        data: {
            title: 'Pages Login - HQM',
        } as SBRouteData,
    },

    {
        path: 'display-payout',
        canActivate: [],
        component: payoutContainers.DisplayPayoutComponent,
        data: {
            title: 'Pages Login - HQM',
        } as SBRouteData,
    },

    {
        path: 'national-percentile',
        canActivate: [],
        component: payoutContainers.NationalPercentileComponent,
        data: {
            title: 'Pages Login - HQM',
        } as SBRouteData,
    },
    {
        path: 'hospital-percentile',
        canActivate: [],
        component: payoutContainers.HospitalPercentileComponent,
        data: {
            title: 'Pages Login - HQM',
        } as SBRouteData,
    },

];

@NgModule({
    imports: [PayoutModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class PayoutRoutingModule { }
