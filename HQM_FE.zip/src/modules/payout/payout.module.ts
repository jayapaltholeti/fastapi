/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { DataTablesModule } from 'angular-datatables';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';




/* Components */
import * as payoutComponent from './components'

/* Containers */
import * as payoutContainers from './containers'

/* Guards */
import * as mastersGuards from './guards'

/* Services */
import * as hospitalServices from './services'

import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        FormsModule,
        AppCommonModule,
        NavigationModule,
        DataTablesModule,
         NgMultiSelectDropDownModule.forRoot()

    ],

    providers: [...hospitalServices.services, ...mastersGuards.guards],
    declarations: [...payoutContainers.containers, ...payoutComponent.components],
    exports: [...payoutContainers.containers, ...payoutComponent.components],
})
export class PayoutModule { }

