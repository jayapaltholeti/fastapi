import { Component, OnInit } from '@angular/core';
import { HospitalPercentileModel } from './hospital-percentile.model';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient} from '@angular/common/http';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;
class DataTablesResponse {
  data?: any[];
  draw?: number;
  recordsFiltered?: number;
  recordsTotal?: number;
}

@Component({
    selector: 'sb-hospital-percentile',
    templateUrl: './hospital-percentile.component.html',
    styleUrls: ['./hospital-percentile.component.scss'],
    standalone: false
})
export class HospitalPercentileComponent implements OnInit {

  getTableUrl: string = "";
  persons?: any[];
  isUpdate = false;
  alert: boolean = false;
  user: HospitalPercentileModel;
  addGroupForm?: FormGroup;
  submitted = false;
  Facility_Name = '';
  addMeasuregroupIdUrl: string = '';
  GetAllMeasureGroupListUrl: string = ''
  GetAllMeasureIdListUrl: string = ''
  updateGroupUrl: string = '';
  deleteGroupUrl: string = '';
  public serverEndPoint = APIEndpoint;
  users: any;
  measureGrouplist: any;
  measureIdlist: any;
  errorMessage: boolean = false;
  successMessage: boolean = false;
  errorMessageText?: string;
  successMessageText?: string;
  page: any;
  filterTerm!: string;
  newItem: any = {};
  getYearListUrl: string = "";
  getYearList?: [];
  displayStyle = "none";
  isLoading: boolean = false;
  isDataShow: boolean = false;

  measureIDS: any;
  GetAllMeasureIdsUrl: string = '';
  hospitalObject: any = {
    // ID: '11',
    year: null,
    hospital_id: null,
    hospital_Name: '',
    insurance_company_id: 1,
    measure_group_id: null,
    measure_ID: null,
    table_name: null,
    Measure_Group_Name: '',
    batchName: '',
    allocation: '',
    user_id: 1,
    System_Performance_Score: 0,
    System_Target_Score: 0,
    file: "",
    originalName: "",
    Is_Manual: 0
};
hospitalObjectModel: any = {
  // ID: '11',
  year: null,
  hospital_id: null,
  insurance_company_id: 1,
  measure_group_id: null,
  measure_ID: null,
  file: ""
};
  hospitalList: any;
  GetAllHospitalListUrl: string = '';
  GetPercentRankUrl: string = '';
  payoutDetailsList: any;
  percentRankData: boolean = false;

  constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly http: HttpClient, private readonly hospitalService: HospitalService) {
    this.user = new HospitalPercentileModel();
  }
  // ngOnDestroy(): void {
  //   throw new Error('Method not implemented.');
  // }
  // ngAfterViewInit(): void {
  //   throw new Error('Method not implemented.');
  // }

  ngOnInit(): void {

    console.log("oninit Loading...........");

    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
    }
    
    
    this.GetAllMeasureGroupListUrl = this.serverEndPoint + "/rest/private/hqm/v1/payout/hospital/measuregrouplist";
    this.getYearListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/year/get";
    this.GetAllHospitalListUrl = this.serverEndPoint + "/rest/private/hqm/v1/payout/hospital/getlist";
    this.GetPercentRankUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospitalpercentrank/getrank";
    

    this.getYear();
  }


  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";
  }
  closeAlert() {
    this.successMessage = false
    this.errorMessage = false;
  }
  onSelectHospital(val: any, id: any) {
    console.log("Hospital ID ", val);
    console.log("mySelect ID ", id);
    let hospitaltext = val.target.selectedOptions[0].innerHTML;
    console.log(hospitaltext);
    this.isDataShow = false;

    this.hospitalObject.hospital_id = id;
    this.hospitalObject.hospital_Name = hospitaltext;
    console.log("Hospital ID ", this.hospitalObject);
    if (this.hospitalObject.year != "null" && this.hospitalObject.hospital_id != "null") {
        this.getMeasureGroupListFunc();
    } else {
        this.measureGrouplist = [];
    }
}

getMeasureGroupListFunc() {
  console.log("Inside Get MeasureGroup Func ");
  this.hospitalService.postRequest(this.GetAllMeasureGroupListUrl, this.hospitalObject).subscribe((measureGrouplist: any) => {
      this.measureGrouplist = measureGrouplist.data;
      this.hospitalObject.measure_group_id = null;
      console.log(measureGrouplist, "measureGrouplist");
  }, (error: any) => {
      console.log(" Get MeasureGroup Func Error ");
      this.successMessage = false;
      this.errorMessage = true;
      this.errorMessageText = "Error."
  });
}
  onSelectYear(val: any) {
    console.log("year ", val);
    this.hospitalObject.year = val;
    this.hospitalObject.measure_group_id = null;
    this.hospitalList = []
 
    if (val == "null") {
        this.hospitalObject.hospital_id = null;
    } else {
        this.getHospitalFunc()
    }
  }

  onBackdropKeyDown(event: KeyboardEvent): void {
  // TODO: implement logic
}

  getHospitalFunc() {
    console.log("Inside Get Hospital Func ");
    this.hospitalService.postRequest(this.GetAllHospitalListUrl, this.hospitalObject).subscribe((hospitalListResult: any) => {
        this.hospitalList =  hospitalListResult.data.filter((facility: { Facility_Name: string; }) => facility.Facility_Name !== 'Brown University Health');
        console.log(this.hospitalList, "Hospital List");
    }, (error: any) => {
        console.log(" Get Hospital Func Error ");
        this.successMessage = false;
        this.errorMessage = true;
        this.errorMessageText = "Error."
    });
}


  getYear() {
    console.log("Get Year");
    this.reset();
    this.hospitalService.postRequest(this.getYearListUrl, this.hospitalObject)
      .subscribe((response: any) => {
        console.log(response, "get year List....");
        this.getYearList = response.data;

      }, (error: any) => {
        console.log(error, "error get year List....");
        if (error.status == 404) {
          this.getYearList = [];
        }
      });
  }


  onSelectMeasureGroup(val: any) {
    console.log(val, "val...................");
    this.hospitalObject.measure_group_id = val.ID;

    this.hospitalObject.Measure_Group_Name = val.Measure_Group_Name.trim();
    this.hospitalObject.Is_Manual = val.Is_Manual
  
    if (this.hospitalObject.year && this.hospitalObject.measure_group_id && this.hospitalObject.hospital_id && this.hospitalObject.insurance_company_id) {
        this.getMeasureGroupPercentRank();
    }
}

  getMeasureGroupPercentRank() {
    this.isDataShow = false
    this.isLoading = true;
    this.hospitalService.postRequest(this.GetPercentRankUrl, this.hospitalObject).subscribe((data: any) => {
      this.payoutDetailsList = data.data.recordset;
      this.percentRankData = this.payoutDetailsList.every((data : any )=> !data.HPR_Final_Score ) 
      this.isLoading = false ;
      this.isDataShow = true;
    }, (error: any) => {
      this.successMessage = false;
      this.isLoading = false;
      this.errorMessage = true;
      this.errorMessageText = "Error."
    });
  }

 
  reset() {
    this.submitted = false;
    this.errorMessage = false;
    this.isUpdate = false;
    this.addGroupForm?.reset();
  }



}
