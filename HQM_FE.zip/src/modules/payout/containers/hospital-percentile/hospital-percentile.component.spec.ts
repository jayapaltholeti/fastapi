import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';

import { HospitalPercentileComponent } from './hospital-percentile.component';

describe('HospitalPercentileComponent', () => {
  let component: HospitalPercentileComponent;
  let fixture: ComponentFixture<HospitalPercentileComponent>;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [ HospitalPercentileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HospitalPercentileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
