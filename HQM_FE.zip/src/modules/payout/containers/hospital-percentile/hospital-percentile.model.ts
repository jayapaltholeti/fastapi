export class HospitalPercentileModel {
    measure_group_id?: any;
    measure_ID?: any;
    year?: null;
    ID?: any;
}