
export class CalculatePayoutModel {
    Group_ID?: string;
    Group_Name?: string;
    Insurance_Company_ID?: string;

}