import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PayoutService } from '@modules/payout/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
import { Select2Data } from 'ng-select2-component';

import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';

const APIEndpoint = environment.APIEndpoint;
const data: Select2Data = [
    {
        value: 'heliotrope',
        label: 'Heliotrope',
        data: { color: 'white', name: 'Heliotrope' },
    },
    {
        value: 'hibiscus',
        label: 'Hibiscus',
        data: { color: 'red', name: 'Hibiscus' },
    },
];
// @NgModule({
//     imports: [
//         NgMultiSelectDropDownModule,
//         CommonModule,
//         FormsModule,
//         ReactiveFormsModule
//     ],
//     schemas: [NO_ERRORS_SCHEMA],
// })

@Component({
    selector: 'sb-calculate-payout',
    // changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './calculate-payout.component.html',
    styleUrls: ['calculate-payout.component.scss'],
    standalone: false
})

export class CalculatePayoutComponent implements OnInit {
    dropdownList: any[] = []
    selectedItems: any[] = [];
    dropdownSettings = {};
    alert: boolean = false;
    // user: CalculatePayoutModel;
    addGroupForm?: FormGroup;
    submitted = false;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    clicked: boolean = true;
    payclicked: boolean = false;
    successMessageText?: string;
    waitMessage: boolean = false;
    waitMessageText?: string;
    addGroupUrl: string = '';
    public serverEndPoint = APIEndpoint;
    users: any;
    dataList: any;
    success: any
    error: any
    GetAllMeasureGroupListUrl: string = '';
    GetAllScaleMeasureGroupListUrl: string = '';
    GetLifeSpanTableNameListurl: string = '';
    getScaleRangeDetailsList: string = '';
    GetAllMeasureIdsUrl: string = '';
    GetAllScaleMeasureIdsUrl: string = '';
    GetBothScore: string = '';
    GetAllMeasureGroupAllocationUrl: string = '';
    GetAllHospitalListUrl: string = '';
    payoutCalculateUrl: string = '';
    updateMeasureContriUrl: string = '';
    allocationCalculateUrl: string = '';
    uploadUrl: string = '';
    modifyAllocationUrl: string = '';
    measureGrouplist: any;
    scaleMeasureGrouplist: any;
    lifeSpanTableList: any;
    measureIDS: any;
    scaleMeasureIDS: any;
    measureallocation: any;
    payoutDetailsListUrl: string = '';
    getCriteriaUrl: string = '';
    payoutDetailsList: any;
    scaleRangeDetailsList: any;
    scaleRangeStatus: string = 'Please Select all Fields';
    total_allocation: any;
    total_MeasureContribution: any;
    CriteriaList: any;
    payoutObject: any = {
        // ID: '11',
        year: null,
        hospital_id: null,
        hospital_Name: '',
        insurance_company_id: 1,
        measure_group_id: null,
        measure_ID: null,
        table_name: null,
        Measure_Group_Name: '',
        batchName: '',
        allocation: '',
        user_id: 1,
        System_Performance_Score: 0,
        System_Target_Score: 0,
        file: "",
        originalName: "",
        Is_Manual: 0
    };
    scaleObject: any = {
        // ID: '11',
        year: null,
        hospital_id: 9,
        hospital_Name: '',
        insurance_company_id: 1,
        measure_group_id: null,
        measure_ID: null,
        table_name: null,
        Measure_Group_Name: '',
        // batchName: '',
        // allocation: '',
        user_id: 1,
        // System_Performance_Score: 0,
        // System_Target_Score: 0,
        // file: "",
        // originalName: "",
        Is_Manual: 0
    };
    payoutObjectModel: any = {
        // ID: '11',
        year: null,
        hospital_id: null,
        insurance_company_id: 1,
        measure_group_id: null,
        measure_ID: null,
        file: ""
    };
    scaleObjectModel: any = {
        // ID: '11',
        year: null,
        hospital_id: null,
        insurance_company_id: 1,
        measure_group_id: null,
        measure_ID: null,
        file: ""
    };
    clearTimer: null | ReturnType<typeof setInterval> = null
    Timer: any
    userId?: string;
    getYearList?: [];
    dmaLifespanStatusList?: [];
    getYearListUrl: string = "";
    getBatchListUrl: string = "";
    getStatusListUrl: string = "";
    getYearHospitalByBatchUrl: string = "";
    getBatchByNameUrl: string = "";
    updateObject: any = {
        hospital_id: null,
        measure_group_id: 1,
        performance_notes: '',
        comments: '',
        measure_contribution: '',
        r_id: '',
        user_id: 1
    };
    isUploadShow: boolean = false;
    isAllocation: boolean = true;
    isNewBatch: boolean = false;
    isdisabled: boolean = false;
    isBatchExist: boolean = false;
    formData?: any = new FormData();
    buttonTextDropDown: string = "Select a file";

    selectedFiles?: FileList;
    currentFile?: File;

    hospitalList: any;
    selectYear: any = {};
    payoutResultlist: any;
    isEdit: any;
    Measure_Group_Name: any = null;
    Facility_Name: any = null;
    currentUser: any;
    isDisabled: boolean = false;
    displayStyle = "none";
    // =========== EDIT ALLCOATION PERCENTAGE MODAL ===========
    closeResult = '';
    measureIDAllocationList: any = [];
    measureIDAllocationObject: any = {};
    isValidated: any = false;
    isErrorExists: any = false;
    isInvalidAllocation: any = false;
    modifiedAllocationResult: any = false;
    isRounding: any = false;
    isLoading: boolean = false;
    isScaleLoading: boolean = false;
    isDataShow: boolean = false;
    updateAllocation: boolean = false;
    showAllocationBtn: boolean = false;
    showCriteriaBtn: boolean = false;
    isModified: boolean = false;
    showCriteriaTable: boolean = false;
    isMeasureContribution: boolean = false;
    isModalOpen: boolean = false;
    scaleRangeValidationUrl: string = '';
    expireMessageText?: string;
    expireMessage: boolean = false;
    displayStylePopup = 'none';

    isButtonUploadDisabled(): boolean {
        return (
            this.payoutObject.file === '' ||
            this.payoutObject.measure_group_id === null ||
            this.payoutObject.measure_ID === null
        );
    }
    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly payoutService: PayoutService, private readonly modalService: NgbModal) {
    }

    ngOnInit() {
        this.dmaLifespanStatusList = [];
        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.userId = this.currentUser.id

        if (this.checkStatusPermission()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }

        this.dropdownSettings = {
            singleSelection: true,
            idField: 'item_id',
            textField: 'item_text',
            selectAllText: false,
            unSelectAllText: 'UnSelect All',
            itemsShowLimit: 3,
            allowSearchFilter: true,
            noDataAvailablePlaceholderText: 'test'
        };

        this.GetAllMeasureGroupListUrl = this.serverEndPoint + "/rest/private/hqm/v1/payout/hospital/measuregrouplist";
        this.GetAllScaleMeasureGroupListUrl = this.serverEndPoint + "/rest/private/hqm/v1/payout/hospital/scaleMeasuregrouplist";
        this.GetAllHospitalListUrl = this.serverEndPoint + "/rest/private/hqm/v1/payout/hospital/getlist";
        this.allocationCalculateUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/assignAllocation";
        this.payoutCalculateUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/calculate/payout";
        this.payoutDetailsListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/payout/details";
        this.updateMeasureContriUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/modifyAllocation";
        this.getCriteriaUrl = this.serverEndPoint + "/rest/private/hqm/v1/measuregroup/criteria";
        this.GetAllMeasureIdsUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getMearureIDs";
        this.GetAllScaleMeasureIdsUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getScaleMearureIDs";
        this.GetAllMeasureGroupAllocationUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getMearureAllocation";
        this.getYearListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/year/get";
        this.uploadUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/lifespan/file/upload";
        this.GetBothScore = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getBothScore";
        this.getBatchListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/batchList";
        this.getBatchByNameUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/batchbyname";
        this.getYearHospitalByBatchUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getYearHospitalByBatchName";
        this.GetLifeSpanTableNameListurl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getTableName";
        this.getScaleRangeDetailsList = this.serverEndPoint + "/rest/private/hqm/v1/hospital/getScaleRangeDetailsList";
        this.getStatusListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/lifespan/statusList";
        this.modifyAllocationUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/modifyMeasureIDAllocation";
        this.scaleRangeValidationUrl = this.serverEndPoint + "/rest/private/hqm/v1/payout/hospital/scaleRangeValidation";


        this.selectYear = [{ item_id: 2019, item_text: 2019 }, { item_id: 2020, item_text: 2020 }, { item_id: 2021, item_text: 2021 }, { item_id: 2022, item_text: 2022 }];
        this.successMessage = false;
        this.errorMessage = false;
        // Form Validation
        // this.addGroupForm = this.formBuilder.group({
        //     groupId: ['', [Validators.required]],
        //     groupName: ['', [Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]],
        //     Insurance_Company_ID: [null]
        // });
        // this.getMeasureGroupListFunc();
        // this.getHospitalFunc();
        this.getYear();
        this.getBatchList();
        if (this.payoutObject.hospital_id && this.payoutObject.measure_group_id && this.payoutObject.hospital_id && this.payoutObject.insurance_company_id) {
            this.getPayoutDetailsListFunc();
        }
    }

    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }
    onItemSelect(item: any) {
        console.log(item, "select.");
        this.payoutObject.batchName = item.item_text;
        this.isBatchExist = true;
        this.getYearHospitalByBatchName();
    }
    onSelectAll(items: any) {
        console.log(items);
    }
    onDeSelect(items: any) {
        console.log('items', items);
        this.cancelBatch()
        this.isdisabled = false
    }

    checkStatusPermission() {
        let found = false;
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Calculate Payout') {
                found = true;
            }
        });
        return found;
    }
    // Get Hospital
    getHospitalFunc() {
        console.log("Inside Get Hospital Func ");
        this.payoutService.postRequest(this.GetAllHospitalListUrl, this.payoutObject).subscribe((hospitalListResult: any) => {
            this.hospitalList = hospitalListResult.data;
            console.log(this.hospitalList, "Hospital List");
        }, (error: any) => {
            console.log(" Get Hospital Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }
    cancel() {
        this.displayStylePopup = 'none';
    }


    getYear() {
        console.log("Get Year");
        this.payoutService.postRequest(this.getYearListUrl, this.payoutObject)
            .subscribe((response: any) => {
                console.log(response, "get year List....");
                this.getYearList = response.data;
            }, (error: any) => {
                console.log(error, "error get year List....");
                if (error.status == 404) {
                    this.getYearList = [];
                }
            });
    }

    handleKey(event: KeyboardEvent): void {
  // TODO: implement logic
}


    getYearHospitalByBatchName() {
        console.log("Get getYearHospitalByBatchName", this.payoutObject);
        this.payoutService.postRequest(this.getYearHospitalByBatchUrl, this.payoutObject)
            .subscribe((response: any) => {
                console.log(response, "Get getYearHospitalByBatchName List....");
                this.payoutObject.year = response[0].Year + "";
                // var hospital = response[0].Facility_List_ID
                this.getHospitalFuncWithParam(response[0]);
                console.log(this.payoutObject, " this.payoutObject ....");
            }, (error: any) => {
                if (error.error.status == 404) { /* empty */ }
            });
    }
    // Get Hospital
    getHospitalFuncWithParam(hospital: any) {
        console.log("Inside Get Hospital Func ");
        this.payoutService.postRequest(this.GetAllHospitalListUrl, this.payoutObject).subscribe((hospitalListResult: any) => {
            this.hospitalList = hospitalListResult.data;
            this.payoutObjectModel.hospital_id = Number.parseInt(hospital.Facility_List_ID);
            this.payoutObject.hospital_id = Number.parseInt(hospital.Facility_List_ID);
            this.payoutObject.hospital_Name = hospital.Facility_Name;
            this.callonHospitalchange(this.payoutObject.hospital_Name, this.payoutObject.hospital_id);
            console.log(this.payoutObject, " this.payoutObject ....");
        }, (error: any) => {
            console.log(" Get Hospital Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    getBatchList() {
        console.log("Get Batch", this.payoutObject);
        this.payoutService.postRequest(this.getBatchListUrl, this.payoutObject)
            .subscribe((response: any) => {
                console.log(response, "Get Batch List....");
                this.dropdownList = response

            }, (error: any) => {
                if (error.error.status == 404) { /* empty */ }
            });
    }

    getBacthByName() {
        this.isBatchExist = false;
        console.log("Get getBacthByName", this.payoutObject);
        this.payoutService.postRequest(this.getBatchByNameUrl, this.payoutObject).subscribe((response: any) => {
            console.log(response, "Get getBacthByName List....");
        }, (error: any) => {
            console.log(error, "Error get Batch List....");
            if (error.error.status == 404) {
                this.isBatchExist = false;
            } else if (error.error.status == 302) {
                console.log(error, "trueeee....");
                this.payoutObject.batchName = '';
                this.isBatchExist = true;
            }
        }
           
        );
    }

    onFocusOutEvent(event: any) {
        this.payoutObject.batchName = event.target.value
        console.log(event.target.value);
        this.getBacthByName();

    }

    onSelectMeasureGroup(val: any) {
        console.log(val, "val...................");
        this.payoutObject.measure_group_id = val.ID;
        this.payoutObject.Measure_Group_Name = val.Measure_Group_Name.trim();
        this.payoutObject.Is_Manual = val.Is_Manual
        this.hideTable();
        if (this.payoutObject.year && this.payoutObject.measure_group_id && this.payoutObject.hospital_id && this.payoutObject.insurance_company_id) {
            this.Measure_Group_Name = val.Measure_Group_Name.trim();
            if (this.Measure_Group_Name === "Healthcare Associated Infections (HAI)") {
                console.log("True");
            }
            if (this.Facility_Name === 'Brown University Health') {
                this.payoutObject.measure_ID = null
                this.payoutObject.file = ''
                this.buttonTextDropDown = "Select a file";
                console.log("Lifespan Group");
                this.getMeasureGroupIDs();
                this.getPayoutDetailsListFunc();
                this.getMeasureGroupAllocation();
            } else {
                this.getPayoutDetailsListFunc();
                this.getCriteriaFunc();
                this.getMeasureGroupAllocation();
            }
        }
    }
    onSelectScaleMeasureGroup(val: any) {
        console.log(val, "val...................");


        this.scaleRangeDetailsList = []
        this.scaleRangeStatus = 'Please select ID'
        this.scaleObject.measure_group_id = val.ID;
        this.scaleObject.Measure_Group_Name = val.Measure_Group_Name.trim();
        // this.scaleObject.Is_Manual = val.Is_Manual
        this.hideTable();
        if (this.scaleObject.year && this.scaleObject.measure_group_id && this.scaleObject.hospital_id && this.scaleObject.insurance_company_id) {
            if (this.Facility_Name === 'Brown University Health') {
                console.log("Lifespan Group");
                this.getScaleMeasureGroupIDs();
            }
        }
    }

    onSelectHospital(val: any, id: any) {
        console.log("Hospital ID ", val);
        console.log("mySelect ID ", id);
        let hospitaltext = val.target.selectedOptions[0].innerHTML;
        console.log(hospitaltext);
        this.payoutObject.allocation = null;
        this.Facility_Name = hospitaltext.trim();
        if (this.Facility_Name === 'Brown University Health') {
            console.log("true", id);
            this.isUploadShow = true;
            this.isAllocation = false;
            this.updateAllocation = false;
            this.isDataShow = false;
        } else {
            console.log("false", val);
            this.isUploadShow = false;
            this.isAllocation = true;
            this.updateAllocation = false;
            this.isDataShow = false;
            this.showCriteriaBtn = false
        }
        this.payoutObject.hospital_id = id;
        this.payoutObject.hospital_Name = hospitaltext;
        console.log("Hospital ID ", this.payoutObject);
        if (this.payoutObject.year != "null" && this.payoutObject.hospital_id != "null") {
            this.getMeasureGroupListFunc();
        } else {
            this.payoutObject.hospital_id = null;
            this.payoutObject.hospital_Name = '';
            this.payoutObject.measure_group_id = null;
            this.payoutObject.measure_ID = null;
            this.payoutObject.table_name = null;
            this.payoutObject.Measure_Group_Name = '';
            this.payoutObject.allocation = null;
            this.payoutObject.System_Performance_Score = 0;
            this.payoutObject.System_Target_Score = 0;

            this.payoutObjectModel.hospital_id = null;
            this.payoutObjectModel.measure_group_id = null;
            this.payoutObjectModel.measure_ID = null;
            this.CriteriaList = [];
            this.payoutDetailsList = [];
            this.measureGrouplist = [];
        }
    }
    callonHospitalchange(hospitaltext: any, id: any) {
        console.log("Hospital ID ", hospitaltext);
        console.log("mySelect ID ", id);
        this.isdisabled = true;
        this.Facility_Name = hospitaltext.trim();
        if (this.Facility_Name === 'Brown University Health') {
            console.log("true", id);
            this.isUploadShow = true;
            this.isAllocation = false;
        } else {
            console.log("false", this.Facility_Name);
            this.isUploadShow = false;
            this.isAllocation = true;
        }
        this.payoutObject.hospital_id = id;
        this.payoutObject.hospital_Name = this.Facility_Name;
        console.log("Hospital ID ", this.payoutObject);
        if (this.payoutObject.year && this.payoutObject.hospital_id) {
            this.getMeasureGroupListFunc();
        }
    }

    onSelectYear(val: any) {
        console.log("year ", val);
        this.payoutObject.year = val;
        this.payoutObject.measure_group_id = null;
        this.payoutObject.hospital_id = null;
        this.payoutObject.allocation = null;
        this.isDataShow = false;
        this.showCriteriaBtn = false;
        this.hospitalList = []
        if (val == null) {
            this.payoutObject.hospital_id = null;
        } else {
            this.getHospitalFunc()
        }
    }
    onScaleSelectYear(val: any) {
        console.log("year ", val);
        this.scaleObject.year = val;
        this.scaleObject.measure_group_id = null;
        this.scaleMeasureGrouplist = []
        this.scaleRangeDetailsList = []
        this.scaleObject.measure_ID = null;
        this.scaleObjectModel.measure_group_id = null;
        if (val == null) {
            this.scaleObject.hospital_id = null;
        } else {
            this.getScaleMeasureGroupListFunc()
        }
    }
    onSelectScaleMeasureID(val: any) {
        console.log('Inside Scale Measure ID getScaleRangeDetailsList');
        this.scaleRangeStatus = '';
        this.isScaleLoading = true
        this.payoutService.postRequest(this.getScaleRangeDetailsList, this.scaleObject).subscribe((tablelist: any) => {
            console.log(tablelist, 'scale final list ');
            this.scaleRangeDetailsList = tablelist
            this.isScaleLoading = false
        }, (error: any) => {
            this.scaleRangeDetailsList = []
            this.isScaleLoading = false
            console.log(" Get MeasureGroup Func Error ");
        });


    }

    onSelectMeasureID(val: any) {
        this.payoutObject.file = ''
        this.buttonTextDropDown = "Select a file";
        if (this.payoutObject.Is_Manual) {
            if (this.payoutObject.year && this.payoutObject.measure_group_id && this.payoutObject.hospital_id && this.payoutObject.insurance_company_id) {
                console.log(this.payoutObject.Is_Manual, "true.................");
                this.getPayoutDetailsListFunc()
            }
        } else {
            this.payoutService.postRequest(this.GetLifeSpanTableNameListurl, this.payoutObject).subscribe((tablelist: any) => {
                console.log(tablelist, "tablelist");
                let MeasureGroupTab = tablelist;
                interface MeasureGroup {
                    Measure_Group_List_ID: string;
                    Table_Name: string;
                }

                const match = MeasureGroupTab.find(
                    (item: MeasureGroup) =>
                        item.Measure_Group_List_ID === String(this.payoutObject.measure_group_id)
                );

                if (match) {
                    this.payoutObject.table_name = match.Table_Name;
                }

                if (this.payoutObject.year && this.payoutObject.measure_group_id && this.payoutObject.hospital_id && this.payoutObject.insurance_company_id) {
                    // this.getPayoutDetailsListFunc()
                    this.getBothScore();
                }
                console.log(this.payoutObject, " this.payoutObject");
            }, (error: any) => {
                console.log(" Get MeasureGroup Func Error ");
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
            });
        }
    }

    // Get Measure Group List Function
    getMeasureGroupListFunc() {
        console.log("Inside Get MeasureGroup Func ");
        this.payoutService.postRequest(this.GetAllMeasureGroupListUrl, this.payoutObject).subscribe((measureGrouplist: any) => {
            this.measureGrouplist = measureGrouplist.data;
            this.payoutObject.measure_group_id = null;
            console.log(measureGrouplist, "measureGrouplist");
        }, (error: any) => {
            console.log(" Get MeasureGroup Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }
    getScaleMeasureGroupListFunc() {
        console.log("Inside Get MeasureGroup Func ");
        this.payoutService.postRequest(this.GetAllScaleMeasureGroupListUrl, this.scaleObject).subscribe((measureGrouplist: any) => {
            this.scaleMeasureGrouplist = measureGrouplist.data;
            this.scaleObject.measure_group_id = null;
            console.log(measureGrouplist, "measureGrouplist");
        }, (error: any) => {
            console.log(" Get MeasureGroup Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    // Get Measure Group List Function
    getLifeSpanTableName() {
        console.log("Inside Get getLifeSpanTableName Func ");
        this.payoutService.postRequest(this.GetLifeSpanTableNameListurl, this.payoutObject).subscribe((tablelist: any) => {
            this.lifeSpanTableList = tablelist.data;
            console.log(this.lifeSpanTableList, "lifeSpanTableList");
        }, (error: any) => {
            console.log(" Get MeasureGroup Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    // Get Measure Group  IDS List Function
    getMeasureGroupIDs(): any {
        console.log("Inside Get getMeasureGroupIDs Func ", this.payoutObject);
        this.payoutService.postRequest(this.GetAllMeasureIdsUrl, this.payoutObject).subscribe((measureIDs: any) => {
            this.measureIDS = measureIDs;
            console.log(measureIDs, "getMeasureGroupIDs");
        }, (error: any) => {
            console.log(" Get getMeasureGroupIDs Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }
    getScaleMeasureGroupIDs(): any {
        console.log("Inside Get getScaleMeasureGroupIDs Func ", this.scaleObject);
        this.payoutService.postRequest(this.GetAllScaleMeasureIdsUrl, this.scaleObject).subscribe((measureIDs: any) => {
            this.scaleMeasureIDS = measureIDs;
            console.log(measureIDs, "getScaleMeasureGroupIDs");
        }, (error: any) => {
            console.log(" Get getScaleMeasureGroupIDs Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    stopRefreshStatusList() {
        return clearInterval(Number(this.clearTimer))
    }

    refreshStatusList() {
        this.clearTimer = setInterval(() => {
            console.log('Refresh Status List')
            this.getStatusList();
        }, 5000);
    }

    checkStatus() {
        return this.dmaLifespanStatusList?.every((value: any) => value.Status === 'Completed')
    }

    getStatusList() {
        console.log("Get List DMA Status getStatusListUrl", this.payoutObject);
        if (this.payoutObject.year) {
            this.payoutObject.userId = this.userId
            this.payoutService.postRequest(this.getStatusListUrl, this.payoutObject)
                .subscribe((response: any) => {
                    console.log(response, "get status List....");
                    this.dmaLifespanStatusList = response;
                    if (this.checkStatus()) {
                        this.stopRefreshStatusList()
                        this.payoutObject.file = "";
                        this.buttonTextDropDown = "Select a file";
                        this.clicked = true;
                        this.waitMessage = false;
                        this.successMessage = true;
                        this.successMessageText = 'File Uploaded Successfully.!'
                        setTimeout(() => {
                            this.successMessage = false;
                        }, 2500)
                    }
                    if (!this.checkStatus()) {
                        this.waitMessage = true;
                        this.waitMessageText = 'Please Wait, File is Uploading...'
                        setTimeout(() => {
                            if (!this.checkStatus()) {
                                this.waitMessage = false;
                                this.successMessage = false;
                                this.expireMessage = true;
                                this.expireMessageText = 'File Upload is Taking Longer than Usual...';
                                this.stopRefreshStatusList();
                                this.checkStatus = () => true;
                                this.clicked = true;

                                setTimeout(() => {
                                    this.expireMessage = false;
                                    this.displayStylePopup = 'block';
                                }, 5000);
                            }
                        }, 210000);
                    }
                    if (this.errorMessage) {
                        this.clicked = true;
                    }
                    console.log('status ---', this.dmaLifespanStatusList)

                }, (error: any) => {
                    console.log(error, "error get status List....");
                    if (error.status == 404) {
                        this.dmaLifespanStatusList = [];
                    }
                });
        } else {
            this.dmaLifespanStatusList = [];
        }
    }

    confirm() {
        this.displayStylePopup = 'none';
        this.expireMessage = false;
        globalThis.location.reload();
    }

    addNewBatch() {
        console.log("Add new Batch ");
        this.payoutObject.year = null;
        this.payoutObject.hospital_id = null;
        this.payoutObject.hospital_Name = '';
        this.payoutObject.measure_group_id = null;
        this.payoutObject.measure_ID = null;
        this.payoutObject.table_name = null;
        this.payoutObject.Measure_Group_Name = '';
        this.payoutObject.batchName = '';
        this.payoutObject.allocation = null;
        this.payoutObject.System_Performance_Score = 0;
        this.payoutObject.System_Target_Score = 0;

        this.payoutObjectModel.year = null;
        this.payoutObjectModel.hospital_id = null;
        this.payoutObjectModel.measure_group_id = null;
        this.payoutObjectModel.measure_ID = null;
        this.CriteriaList = [];
        this.payoutDetailsList = [];

        this.ngOnInit();
        this.isNewBatch = true;
        this.selectedItems = [];
        this.isdisabled = false;
        this.isBatchExist = false;
        this.updateAllocation = false;
        this.showAllocationBtn = true
        this.showCriteriaBtn = false;
    }

    cancelBatch() {
        console.log("cancel Batch ");
        this.payoutObject.year = null;
        this.payoutObject.hospital_id = null;
        this.payoutObject.hospital_Name = '';
        this.payoutObject.measure_group_id = null;
        this.payoutObject.measure_ID = null;
        this.payoutObject.table_name = null;
        this.payoutObject.Measure_Group_Name = '';
        this.payoutObject.batchName = '';
        this.payoutObject.allocation = null;
        this.payoutObject.System_Performance_Score = 0;
        this.payoutObject.System_Target_Score = 0;
        this.payoutObject.Is_Manual = 0;

        this.payoutObjectModel.year = null;
        this.payoutObjectModel.hospital_id = null;
        this.payoutObjectModel.measure_group_id = null;
        this.payoutObjectModel.measure_ID = null;
        this.CriteriaList = [];
        this.payoutDetailsList = [];
        this.hospitalList = [];
        this.measureGrouplist = [];
        this.isNewBatch = false;
        this.isBatchExist = false;
        this.showAllocationBtn = false;
        this.showCriteriaBtn = false;
        this.isDataShow = false;
        this.isUploadShow = false;
        this.isAllocation = true;
        this.getBatchList();
    }
    // Get getBothScore Function
    getBothScore() {
        console.log("Inside Get getBothScore Func ", this.payoutObject);
        this.payoutService.postRequest(this.GetBothScore, this.payoutObject).subscribe((measureIDs: any) => {

            this.payoutObject.System_Performance_Score = measureIDs[0].System_Performance_Score;
            this.payoutObject.System_Target_Score = measureIDs[0].System_Target_Score;
            this.getPayoutDetailsListFunc()

        }, (error: any) => {
            console.log(" Get getBothScore Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    // Get Measure Group List Function
    getMeasureGroupAllocation() {
        console.log("Inside getMeasureGroupAllocation  ");
        this.payoutObject.allocation = ''
        this.payoutService.postRequest(this.GetAllMeasureGroupAllocationUrl, this.payoutObject).subscribe((measureGropallocation: any) => {
            this.measureallocation = measureGropallocation;
            console.log(this.measureallocation);
            this.payoutObject.allocation = this.measureallocation[0].Measure_Group_Allocation_Percentage;
            console.log(this.measureallocation, "getMeasureGroupAllocation");
        }, (error: any) => {
            console.log(" Get MeasureGroup Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    Edit_measureId(val: any, index: any) {
        console.log("Edit Measure ID Function", index);
        console.log(val);
        this.isEdit = index;
    }

    // Update Measure ID Details.
    Update_measureId(val: any, index: any) {
        val.user_id = 1;
        console.log("updatet Measure Group", val);
        this.updateObject.hospital_id = val;
        this.updateObject.measure_group_id = val.Measure_ID;
        this.updateObject.performance_notes = val.Performance_Notes ? val.Performance_Notes : '';
        this.updateObject.comments = val.Comments ? val.Comments : '';
        this.updateObject.measure_contribution = val.Measure_Contribution;
        this.updateObject.r_id = val.r_id;
        this.updateObject.user_id = 1;
        console.log("Update Object", this.updateObject);
        this.errorMessage = false;
        this.successMessage = false;
        if (val.Measure_Contribution) {
            let regexp = /^\d\d*(\.\d+)?$/;
            let isNumber = regexp.test(val.Measure_Contribution);
            if (!isNumber) {
                this.errorMessage = true;
                this.errorMessageText = "Error! Measure Contribution should be Number Only"
                return;
            } else if (val.Measure_Contribution > 100) {
                this.errorMessage = true;
                this.errorMessageText = "Error! Please Enter the Valid Measure Contribution."
                return;
            }
        }
        this.waitMessage = true;
        this.waitMessageText = "Warning! Please Wait... Updating Measure ID Details.";
        this.payoutService.postRequest(this.updateMeasureContriUrl, this.updateObject).subscribe((measureIDResult: any) => {
            this.getPayoutDetailsListFunc();
            console.log(measureIDResult, "measureIDResult");
            this.waitMessage = false;
            this.errorMessage = false;
            this.successMessage = true;
            this.successMessageText = "Success! Measure ID Details Updated Successfully.!";
            this.isEdit = null;
            setTimeout(() => {
                this.successMessage = false;
            }, 2500);
        }, (error: any) => {
            console.log(" Get payout Func Error ");
            this.waitMessage = false;
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error! Measure ID Details Update Failed."
            setTimeout(() => {
                this.errorMessage = false;
            }, 2500)
        });
    }
    // Allocation value change fn
    onInputChange() {
        if (this.payclicked) {
            this.isModified = false;
            this.isMeasureContribution = false
        } else {
            this.isModified = true;
            this.isMeasureContribution = false
        }
    }

    onBatchChange() {
        clearTimeout(this.Timer);

        this.Timer = setTimeout(() => {

            if (this.payoutObject.year && this.payoutObject.measure_group_id && this.payoutObject.hospital_id && this.payoutObject.insurance_company_id) {

                if (this.Facility_Name === 'Brown University Health') {
                    console.log("Lifespan Group");
                    this.getMeasureGroupIDs();
                    this.getPayoutDetailsListFunc();
                    this.getMeasureGroupAllocation();
                } else {
                    this.getPayoutDetailsListFunc();
                    this.getCriteriaFunc();
                    this.getMeasureGroupAllocation();
                }
            }
        }, 1000);
    }
    showTable() {
        this.showCriteriaTable = true;
    }

    hideTable() {
        this.showCriteriaTable = false;
    }

    // Get getPayoutDetailsListFunc
    getPayoutDetailsListFunc() {
        console.log("Inside Get getPayoutDetailsListFunc ", this.payoutObject);
        this.errorMessage = false;
        setTimeout(() => {
            this.successMessage = false;
        }, 2500)
        this.payoutDetailsList = [];
        this.total_allocation = 0;
        this.total_MeasureContribution = 0;
        this.isDataShow = false;
        this.updateAllocation = true;
        this.isModified = false;
        this.isMeasureContribution = false;
        this.isLoading = true
        this.payoutService.postRequest(this.payoutDetailsListUrl, this.payoutObject).subscribe((payoutDetailsListResult: any) => {
            this.isDataShow = true;
            this.showAllocationBtn = true;
            this.showCriteriaBtn = true;
            this.payoutDetailsList = payoutDetailsListResult.data.recordset;
            console.log("payoutDetailsList --------->", this.payoutDetailsList);
            let count = 0;
            let measureContributionCount = 0
            if (this.payoutDetailsList.length > 0) {

                this.payoutDetailsList.forEach(
                    (detail: { Measure_ID_Allocation_Percentage?: string; Measure_Contribution?: string }) => {
                        const allocation = detail.Measure_ID_Allocation_Percentage;
                        const contribution = detail.Measure_Contribution;

                        if (allocation) {
                            count += Number.parseFloat(allocation);
                        }

                        if (contribution) {
                            measureContributionCount += Number.parseFloat(contribution);
                        }
                    }
                );


            }
            console.log(count)

            this.total_allocation = count;

            if (measureContributionCount == 0) {
                this.payclicked = false;
            } else {
                this.payclicked = true;
            }
            this.total_MeasureContribution = measureContributionCount;
            this.isLoading = false
            console.log("payoutList", this.total_allocation)
            console.log(payoutDetailsListResult, "payoutDetailsList");
        }, (error: any) => {
            console.log(" Get MeasureGroup Func Error ");
            this.isLoading = false
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    // Get getPayoutDetailsListFunc
    getCriteriaFunc() {
        console.log("Inside Get getCriteriaFunc ", this.payoutObject);
        this.errorMessage = false;
        this.successMessage = false;
        this.isLoading = true
        this.CriteriaList = []
        this.isDataShow = false
        this.payoutService.postRequest(this.getCriteriaUrl, this.payoutObject).subscribe((criteriaResult: any) => {
            this.isLoading = false
            this.isDataShow = true
            this.CriteriaList = criteriaResult;
            console.log(this.CriteriaList, "CriteriaList");
        }, (error: any) => {
            this.isLoading = false;
            console.log(" Get MeasureGroup Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    // Allocation Calculation
    allocation() {
        console.log("Inside Allocation. ");
        console.log("Allocation Object. ", this.payoutObject);
        this.errorMessage = false;
        this.successMessage = false;
        if (this.payoutObject.year == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Year."
            return;
        }
        if (this.payoutObject.hospital_id == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Hospital."
            return;
        }
        if (this.payoutObject.measure_group_id == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Measure Group."
            return;
        }
        if (this.payoutObject.batchName == '') {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Enter the Batch Name."
            return;
        }
        if (this.payoutObject.allocation) {
            let isNumber = /^[+]?\d+(\.\d+)?$/.test(this.payoutObject.allocation);
            if (!isNumber) {
                this.errorMessage = true;
                this.errorMessageText = "Error! Allocation Percentage should be Number Only"
                return;
            } else if (this.payoutObject.allocation > 100) {
                this.errorMessage = true;
                this.errorMessageText = "Error! Please Enter the Valid Percentage."
                return;
            }
        } else {
            this.errorMessage = true;
            this.errorMessageText = "Error! Allocation Percentage should not be Empty."
            return;
        }
        this.waitMessage = true;
        this.isLoading = true;
        this.waitMessageText = "Warning! Please Wait... Percentage (%) is Allocating to Measure Ids.";
        this.payoutService.postRequest(this.allocationCalculateUrl, this.payoutObject).subscribe((measureGrouplist: any) => {
            console.log(measureGrouplist, "measureGrouplist");
            this.isLoading = false;
            if (measureGrouplist.status == 201) {
                this.waitMessage = false;
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = measureGrouplist.message;
                this.getPayoutDetailsListFunc();
            }
        }, (error: any) => {
            console.log(" Get Allocation Func Error ", error);
            this.isLoading = false;
            this.waitMessage = false;
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = error.error.message
            setTimeout(() => {
                this.errorMessage = false;
            }, 2500)
        });
    }

    // Payout Calculation
    payout() {
        this.payclicked = false;
        console.log("Inside payout.", this.payoutObject);
        this.errorMessage = false;
        this.successMessage = false;
        if (this.payoutObject.year == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Year."
            return;
        }
        if (this.payoutObject.hospital_id == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Hospital."
            return;
        }
        if (this.payoutObject.measure_group_id == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Measure Group."
            return;
        }
        if (this.payoutObject.batchName == '' || this.payoutObject.batchName == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Enter the Batch Name."
            return;
        }

        this.waitMessage = true;
        this.isLoading = true;
        this.waitMessageText = "Hospital Payout is being calculated";
        console.log("payoutObject", this.payoutObject);
        if (!this.payoutObject.Is_Manual && this.payoutObject.hospital_id === 9) {
            this.payoutService.postRequest(this.scaleRangeValidationUrl, this.payoutObject).subscribe((vaildateResult: any) => {
                console.log(vaildateResult);
                this.payoutService.postRequest(this.payoutCalculateUrl, this.payoutObject).subscribe((payoutResult: any) => {
                    console.log("payoutObject", this.payoutObject);
                    this.isLoading = false
                    console.log("Payout calculated Successfully. ");
                    this.getPayoutDetailsListFunc();
                    this.waitMessage = false;
                    this.errorMessage = false;
                    this.successMessage = true;
                    this.successMessageText = "Hospital Payout is successfully calculated";
                    this.payclicked = true;
                    setTimeout(() => {
                        this.successMessage = false;
                    }, 2500);
                }, (error: any) => {
                    console.log(" Get payout Func Error ", error);
                    this.payclicked = false;
                    this.isLoading = false
                    if (error.error.status === 409) {
                        this.waitMessage = false;
                        this.successMessage = false;
                        this.errorMessage = true;
                        this.errorMessageText = error.error.message;
                        setTimeout(() => {
                            this.errorMessage = false;
                        }, 2500)
                    } else {
                        this.waitMessage = false;
                        this.successMessage = false;
                        this.errorMessage = true;
                        this.errorMessageText = "Error. Payout Calculation Failed."
                        setTimeout(() => {
                            this.errorMessage = false;
                        }, 2500)
                    }
                });


            }, (error: any) => {


                this.isLoading = false
                if (error.error.status === 409) {
                    this.waitMessage = false;
                    this.successMessage = false;
                    this.errorMessage = true;
                    this.errorMessageText = error.error.message;
                    setTimeout(() => {
                        this.errorMessage = false;
                    }, 2500)
                } else {
                    this.waitMessage = false;
                    this.successMessage = false;
                    this.errorMessage = true;
                    this.errorMessageText = "Error. Scale Range Validaiton Failed."
                    setTimeout(() => {
                        this.errorMessage = false;
                    }, 2500)
                }
            })
                
        }
        if (this.payoutObject.hospital_id !== 9 || this.payoutObject.Is_Manual) {
            this.payoutService.postRequest(this.payoutCalculateUrl, this.payoutObject).subscribe((payoutResult: any) => {
                console.log("payoutObject", this.payoutObject);
                this.isLoading = false
                console.log("Payout calculated Successfully. ");
                this.getPayoutDetailsListFunc();
                this.waitMessage = false;
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Hospital Payout is successfully calculated";
                this.payclicked = true;
                setTimeout(() => {
                    this.successMessage = false;
                }, 2500);
            }, (error: any) => {
                console.log(" Get payout Func Error ", error);
                this.payclicked = false;
                this.isLoading = false
                if (error.error.status === 409) {
                    this.waitMessage = false;
                    this.successMessage = false;
                    this.errorMessage = true;
                    this.errorMessageText = error.error.message;
                    setTimeout(() => {
                        this.errorMessage = false;
                    }, 2500)
                } else {
                    this.waitMessage = false;
                    this.successMessage = false;
                    this.errorMessage = true;
                    this.errorMessageText = "Error. Payout Calculation Failed."
                    setTimeout(() => {
                        this.errorMessage = false;
                    }, 2500)
                }
            });
        }
    }


    selectFile(event: any): void {
        console.log("File Selected------ ", event);
        this.errorMessage = false;
        this.errorMessageText = "";
        this.payoutObject.file = event.target.files;
        this.payoutObject.originalName = event.target.files[0].name
        if (this.payoutObject.file) {
            this.buttonTextDropDown = event.target.files[0].name
        }
    }

    upload() {
        this.clicked = false;

        if (this.payoutObject.file) {
            const file = this.payoutObject.file.item(0);

            if (file) {
                this.currentFile = file;
                const fileName = this.currentFile ? this.currentFile.name : "";

                if (fileName.endsWith(".csv")) {
                    this.ifCsvFile(this.payoutObject.file, file);
                } else if (fileName.endsWith(".xlsx") || fileName.endsWith(".xls")) {
                    this.uploadFile(this.payoutObject.file, file);
                } else {
                    alert("Upload Excel File.");
                }
            }
        }

        this.refreshStatusList();
    }

    async ifCsvFile(event: File[], file: File) {
        const uploadedFile = event[0];

        try {
            const text = await uploadedFile.text();

            if (!text) {
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText =
                    "Error: " + file.name + " File is empty. Please upload the correct file.";
                return;
            }

            const csvRecordsArray = text.split(/\r\n|\n/);
            const fileWithoutHeader = csvRecordsArray.length - 1;

            if (fileWithoutHeader < 1) {
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText =
                    "Error: " + file.name + " File is empty. Please upload the correct file.";
                return;
            }

            this.uploadFile(event, file);
        } catch {
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error reading file. Please try again.";
        }
    }

    uploadFile(fileInputEvent: any, file: any) {
        console.log("uploadFile====== ", fileInputEvent[0].name);
        this.errorMessage = false;
        this.successMessage = false;
        this.formData.delete('year')
        this.formData.delete('upload')
        this.formData.delete('user_id')
        this.formData.delete('Measure_Group_Name')
        this.formData.delete('table_name')
        this.formData.delete('measure_group_id')
        this.formData.delete('measure_ID')
        this.formData.delete('fileName')
        this.formData.delete('originalName')
        this.formData.append("year", this.payoutObject.year);
        this.formData.append("measure_group_id", this.payoutObject.measure_group_id);
        this.formData.append("Measure_Group_Name", this.payoutObject.Measure_Group_Name);
        this.formData.append("measure_ID", this.payoutObject.measure_ID);
        this.formData.append("table_name", this.payoutObject.table_name);
        this.formData.append("user_id", this.payoutObject.user_id);
        this.formData.append("upload", fileInputEvent[0]);
        this.formData.append("fileName", fileInputEvent[0].name);
        this.formData.append('originalName', this.payoutObject.originalName)
        console.log(this.payoutObject, "object data..");
        this.errorMessage = false;
        this.successMessage = false;
        this.waitMessage = false;

        this.payoutService.postRequest(this.uploadUrl, this.formData)
            .subscribe((response: any) => {
                console.log(response, "upload response")
                this.waitMessage = false;
                this.errorMessage = false;

                this.successMessageText = "File Uploaded Successfully.!";
                setTimeout(() => {
                    this.successMessage = false;
                }, 2500)
            }, (error: any) => {
                console.error(error);
            });
    }

    // 1. EDIT MEASURE ID ALLOCATION PERCENTAGE MODAL
    open(content: any) {
        this.getMeasureGroupIDs();
        this.isValidated = false;
        this.isInvalidAllocation = false;
        this.isRounding = false;
        this.payoutDetailsList.forEach((detail: { Score: string; Measure_ID_Allocation_Percentage: any; Measure_ID: any; }) => {
            const isNA = detail?.Score === "Not Available";
            const allocation = isNA
                ? "NULL"
                : Number(detail?.Measure_ID_Allocation_Percentage).toFixed(3);

            const tempObj = {
                allocation,
                measureId: detail?.Measure_ID,
                errorMessage: "",
                isNA
            };

            this.measureIDAllocationList.push(tempObj);
        });

        this.modalService.open(content, {
            ariaLabelledBy: 'modal-basic-title',
            centered: true,
            scrollable: true,
            size: 'lg',
            backdrop: 'static'
        }).result.then(
            (result) => {
                // SAVE MODAL
                if (result === "Save") {
                    const tempMeasureIDAllocation: Array<{ ID: number; Allocation: any }> = [];

                    this.measureIDAllocationList.forEach((allocationItem: { measureId: any[]; allocation: any; }) => {
                        const measureId = Array.isArray(allocationItem.measureId)
                            ? allocationItem.measureId[1]
                            : allocationItem.measureId;

                        this.measureIDS.forEach((measure: { Measure_ID: any; ID: any; }) => {
                            if (measureId === measure.Measure_ID) {
                                tempMeasureIDAllocation.push({
                                    ID: measure.ID,
                                    Allocation: allocationItem.allocation
                                });
                            }
                        });
                    });

                    this.modifyAllocation(tempMeasureIDAllocation);
                    this.measureIDAllocationList = [];
                } else {
                    this.closeResult = `Closed with: ${result}`;
                    console.log(this.closeResult);
                    this.measureIDAllocationList = [];
                }

            },
            // DISMISS MODAL
            (error_) => {
                this.closeResult = `Dismissed ${this.getDismissReason(error_)}`;
                console.log(this.closeResult);
                this.measureIDAllocationList = [];
            },
        );
    }
    openScale(content2: any) {
        this.isModalOpen = true;
        this.modalService.open(content2, {
            ariaLabelledBy: 'modal-basic-title',
            centered: true,
            scrollable: true,
            size: 'lg',
            backdrop: 'static'
        }).result.then(
            (result) => {
                // SAVE MODAL

            },
            // DISMISS MODAL
            () => {
                this.isModalOpen = false;
                this.scaleRangeDetailsList = [];
                this.scaleObject.measure_ID = null;
                this.scaleObjectModel.measure_group_id = null;
                this.scaleObject.year = null;

            },
        );
    }

    // 2. VALIDATE ALLOCATION PERCENTAGE
    validateAllocation(content: any, index: number) {
        this.isValidated = false;
        this.isInvalidAllocation = false;
        this.isRounding = false;
        console.log("INSIDE validateAllocation()", content?.target.value);
        if (content?.target.value.length) {
            let isNumber = /^[+]?\d+(\.\d+)?$/.test(content?.target.value);
            console.log(isNumber);
            if (!isNumber) {
                this.measureIDAllocationList[index].errorMessage = "Allocation Percentage should be Number Only.";
                this.isErrorExists = true;
            } else if (content?.target.value > 100) {
                this.measureIDAllocationList[index].errorMessage = "Please Enter the Valid Percentage.";
                this.isErrorExists = true;
            } else if (!this.measureIDAllocationList[index].isNA) {
                this.measureIDAllocationList[index].errorMessage = "";
                this.measureIDAllocationList[index].allocation = content?.target.value;
                this.validateTotalAllocation(index);
            }
        } else if (content?.target.value.length == 0) {
            this.measureIDAllocationList[index].errorMessage = "Allocation Percentage should not be Empty.";
            this.isErrorExists = true;
        }
    }

    // 3. VALIDATE TOTAL ALLOCATION 
    validateTotalAllocation(index: number) {
        let tempTotal = 0;
        this.measureIDAllocationList.forEach(
            (item: { allocation?: string | number }) => {
                const allocation = Number(item.allocation);

                if (allocation > 0 && allocation <= this.payoutObject.allocation) {
                    tempTotal += allocation;
                }
            }
        );


        if (tempTotal == this.payoutObject.allocation || tempTotal.toFixed(3) == this.payoutObject.allocation || tempTotal.toFixed(2) == this.payoutObject.allocation) {
            this.isInvalidAllocation = false;
            this.isErrorExists = false;
            this.isRounding = false;
        } else if (Math.abs(this.payoutObject.allocation - Number(tempTotal.toFixed(3))) <= 0.004) {
            this.isInvalidAllocation = false;
            this.isErrorExists = false;
            this.isRounding = true;
        } else {
            this.isInvalidAllocation = true;
            this.isErrorExists = true;
            this.isRounding = false;
        }
        console.log(tempTotal, Number(this.payoutObject.allocation));
    }

    // 4. SEND MODIFIED ALLCOATION TO API
    modifyAllocation(allocationList: any) {
        // 4.1 REQUEST OBJECT
        this.measureIDAllocationObject = {
            batchName: this.payoutObject?.batchName,
            hospital_Name: this.payoutObject?.hospital_Name.trim(),
            hospital_id: this.payoutObject?.hospital_id,
            insurance_company_id: this.payoutObject?.insurance_company_id,
            measure_group_id: this.payoutObject?.measure_group_id,
            user_id: this.payoutObject?.user_id,
            year: this.payoutObject?.year,
            measure_ids: allocationList
        }
        console.log(this.measureIDAllocationObject);

        // 4.2 CALL API
        this.payoutService.postRequest(this.modifyAllocationUrl, this.measureIDAllocationObject).subscribe((modifiedAllocationResponse: any) => {
            this.modifiedAllocationResult = modifiedAllocationResponse?.data;
            // 4.3 RE-POPULATE THE EDITED MEASURE ID ALLOCATION IN THE MAIN TABLE
            this.getPayoutDetailsListFunc();
            this.successMessage = true;
            this.successMessageText = "Measure ID Allocation Updated Successfully!";
            this.errorMessage = false;
            setTimeout(() => {
                this.successMessage = false;
            }, 2500);
        }, (error: any) => {
            console.log("Modify Allocation API Error!");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = 'Error! Updating Allocation';
            setTimeout(() => {
                this.errorMessage = false;
            }, 2500);
        });
    }

    // CLOSE MODAL
    private getDismissReason(reason: any): string {
        if (reason === ModalDismissReasons.ESC) {
            return 'by pressing ESC';
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
            return 'by clicking on a backdrop';
        } else {
            return `with: ${reason}`;
        }
    }

    reset() {
        this.isEdit = null;
        this.getPayoutDetailsListFunc();
    }
}
