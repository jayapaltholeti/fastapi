import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { DataTableDirective } from 'angular-datatables';
import { NationalPercentileModel } from './national-percentile.model';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs';

import { HospitalService } from '@modules/masters/services';
import { environment } from '../../../../environments/environment';
import { Router } from '@angular/router';
const APIEndpoint = environment.APIEndpoint;
class DataTablesResponse {
    data?: any[];
    draw?: number;
    recordsFiltered?: number;
    recordsTotal?: number;
}
@Component({
    selector: 'sb-national-percentile',
    templateUrl: './national-percentile.component.html',
    styleUrls: ['national-percentile.component.scss'],
    standalone: false
})
export class NationalPercentileComponent implements OnDestroy, OnInit {

    // Data table
    @ViewChild(DataTableDirective, { static: false })
    dtElement?: DataTableDirective;
    dtTrigger: Subject<void> = new Subject<void>();
    httpHeaders?: HttpHeaders;
    dtOptions: DataTables.Settings = {};
    getTableUrl: string = "";
    persons?: any[];
    postObject: any = {
        user: 1,
        measure_group_id: null,
        measure_ID: null,
        year: null,
    };
    isUpdate = false;
    alert: boolean = false;
    user: NationalPercentileModel;
    addGroupForm?: FormGroup;
    submitted = false;
    addMeasuregroupIdUrl: string = '';
    GetAllMeasureGroupListUrl: string = ''
    GetAllMeasureIdListUrl: string = ''
    updateGroupUrl: string = '';
    deleteGroupUrl: string = '';
    public serverEndPoint = APIEndpoint;
    users: any;
    measureGrouplist: any;
    measureIdlist: any;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    page: any;
    filterTerm!: string;
    newItem: any = {};
    getYearListUrl: string = "";
    getYearList?: [];
    displayStyle = "none";
    isLoading: boolean = false;
    isDataShow: boolean = false;

    measureIDS: any;
    GetAllMeasureIdsUrl: string = '';
    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly http: HttpClient, private readonly hospitalService: HospitalService) {
        this.user = new NationalPercentileModel();

    }
    ngOnInit() {
        if (!sessionStorage.getItem('token')) {
            this.router.navigate(['auth/login']);
            return; // prevent initializing the table when unauthenticated
        }

        // URLs
        this.addMeasuregroupIdUrl = `${this.serverEndPoint}/rest/private/hqm/v1/hospital/measuregroupidlist/create`;
        this.GetAllMeasureGroupListUrl = `${this.serverEndPoint}/rest/private/hqm/v1/nationalPercentile/getMearureGroup`;
        this.GetAllMeasureIdListUrl = `${this.serverEndPoint}/rest/private/hqm/v1/hospital/measureidlist/getlist`;
        this.updateGroupUrl = `${this.serverEndPoint}/rest/private/hqm/v1/measureid/update`;
        this.deleteGroupUrl = `${this.serverEndPoint}/rest/private/hqm/v1/measureid/delete`;
        this.getTableUrl = `${this.serverEndPoint}/rest/private/hqm/v1/hospital/getNationalPercentile`;
        this.GetAllMeasureIdsUrl = `${this.serverEndPoint}/rest/private/hqm/v1/nationalPercentile/getMearureIDs`;
        this.getYearListUrl = `${this.serverEndPoint}/rest/private/hqm/v1/nationalPercentile/year/get`;

        // DataTables options (single assignment)
        const that = this;
        this.dtOptions = {
            pagingType: 'full_numbers',
            pageLength: 10,
            scrollY: '400',
            scrollX: true,
            serverSide: true,
            processing: true,
            dom: '<"float-left"B><"float-right"f>rt<"row"<"col-sm-4"i><"col-sm-2"l><"col-sm-6"p>>',
            searching: false,
            ajax: (dataTablesParameters: any, callback: DataTablesAjaxCallback) => {
                dataTablesParameters['dateObject'] = this.postObject;
                this.isLoading = true;

                that.http.post<DataTablesResponse>(
                    this.getTableUrl,
                    dataTablesParameters,
                    {
                        headers: new HttpHeaders({
                            'Content-Type': 'application/json',
                            'Authorization': 'Bearer ' + sessionStorage.getItem('token')
                        }),
                        withCredentials: true
                    }
                ).subscribe({
                    next: (resp) => {
                        this.isLoading = false;
                        const rows = Array.isArray(resp?.data?.[0]) ? resp.data[0] : (resp?.data ?? []);
                        that.persons = rows;

                        callback({
                            draw: dataTablesParameters.draw,
                            recordsTotal: resp?.recordsTotal ?? rows.length,
                            recordsFiltered: resp?.recordsFiltered ?? rows.length,
                            data: rows
                        });
                    },
                    error: () => {
                        this.isLoading = false;
                        this.isDataShow = false;
                        callback({
                            draw: dataTablesParameters.draw,
                            recordsTotal: 0,
                            recordsFiltered: 0,
                            data: []
                        });
                    }
                });
            },
            columns: [
                { data: 'Percentile_5' },
                { data: 'Percentile_10' },
                { data: 'Percentile_25' },
                { data: 'Percentile_33_33' },
                { data: 'Percentile_42' },
                { data: 'Percentile_50' },
                { data: 'Percentile_58' },
                { data: 'Percentile_66_67' },
                { data: 'Percentile_75' },
                { data: 'Percentile_90' }
            ]
        };

        this.getYear();
    }


    // get f() { return this.addGroupForm?.controls; }

    //Create Add Measure GroupId
    // onSubmit() {
    //     console.log(this.addGroupForm?.value)
    //     this.submitted = true;
    //     if (this.addGroupForm?.invalid) {
    //         return;
    //     }
    //     this.hospitalService.addMeasuregroupId(this.addMeasuregroupIdUrl, this.user)
    //         .subscribe((response: any) => {
    //             console.log(this.user, "user")
    //             console.log("Responce", response)
    //             // window.location.reload();
    //             this.errorMessage = false;
    //             this.successMessage = true;
    //             this.successMessageText = "Success! Hospital Measure ID Created Successfully."
    //             this.rerender();
    //             this.reset()
    //         }, (error: any) => {
    //             console.log("error", error)
    //             this.successMessage = false;
    //             this.errorMessage = true;
    //             this.errorMessageText = "Error! Hospital Measure ID Already Exist."
    //             this.reset()
    //         });
    // }

    //Get Measure Id List
    getMeasureIdList() {
        this.hospitalService.getAllMeasureIdList(this.GetAllMeasureIdListUrl)
            .subscribe((measureIdlist: any) => {
                this.measureIdlist = measureIdlist.data;
                console.log(this.measureIdlist, "measureIdlist");
            }, (error: any) => {
                console.log(" GetAll MeasureIdList Error ");
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error."
            });
    }
    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

    //Get AllMeasureGroup List
    getAllMeasureGroupList() {
        console.log("getAllMeasureGroupList...................", this.user);
        this.hospitalService.getAllMeasureGroupList(this.GetAllMeasureGroupListUrl, this.user)
            .subscribe((measureGrouplist: any) => {
                this.measureGrouplist = measureGrouplist;
                console.log(measureGrouplist, "getAllMeasureGroupList data...................");
            }, (error: any) => {

                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Get Measure ID List Error."
                this.reset()
            });
    }

    onSelectMeasureGroup(val: any) {
        console.log(val, "val...................");
        this.postObject.measure_group_id = val;
        console.log("postObject", this.postObject);
        if (this.user.year && this.user.measure_group_id) {
            this.getMeasureGroupIDs();
        }
    }


    get f() {
        return this.addGroupForm?.controls;
    }

    getMeasureGroupIDs() {
        console.log("Inside Get getMeasureGroupIDs Func ", this.user);
        this.hospitalService.postRequest(this.GetAllMeasureIdsUrl, this.user).subscribe((measureIDs: any) => {
            this.measureIDS = measureIDs;
            console.log(measureIDs, "getMeasureGroupIDs");
            if (this.isDataShow) {
                this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
                    // Destroy the table first
                    dtInstance.destroy();
                });
            }
            this.isDataShow = false;
        }, (error: any) => {
            console.log(" Get getMeasureGroupIDs Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }
    onSelectMeasureID(val: any) {
        console.log("Inside Get onSelectMeasureID Func ", val);
        this.postObject.measure_ID = val;
        console.log("postObject", this.postObject);
        if (this.postObject.year && this.postObject.measure_group_id) {
            this.rerender();
        }
    }

    onSelectYear(val: any) {
        console.log("Inside Get onSelectYear Func ", val);
        this.postObject.year = val;
        console.log("postObject", this.postObject);
        this.getAllMeasureGroupList();
    }


    getYear() {
        console.log("Get Year");
        this.reset();
        this.hospitalService.postRequest(this.getYearListUrl, this.user)
            .subscribe((response: any) => {
                console.log(response, "get year List....");
                this.getYearList = response.data;

            }, (error: any) => {
                console.log(error, "error get year List....");
                if (error.status == 404) {
                    this.getYearList = [];
                }
            });
    }


    addMeasuregroup() {
        this.router.navigate(['masters/add-measure-group']);
    }
    onUpdate() {
        console.log(this.addGroupForm?.value)
        this.submitted = true;
        if (this.addGroupForm?.invalid) {
            return;
        }
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.updateGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Measure ID Updated Successfully."
                setTimeout(() => {
                    this.successMessage = false;
                }, 2500)
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Measure ID Not Exist."
                setTimeout(() => {
                    this.errorMessage = false;
                }, 2500)
                this.reset()
            });
    }

    reset() {
        this.submitted = false;
        this.errorMessage = false;
        this.isUpdate = false;
        this.addGroupForm?.reset();
    }

    deleteFun(val: any) {
        console.log("Delete Function", val)
        this.user.ID = val.Measure_ID_List_ID
        console.log(this.user, "User Object..");
        this.hospitalService.addGroupsystem(this.deleteGroupUrl, this.user)
            .subscribe((response: any) => {
                console.log(this.user, "user")
                console.log("Responce", response)
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = "Success! Measure ID Delete Successfully."
                setTimeout(() => {
                    this.successMessage = false;
                }, 2500)
                this.rerender();
                this.reset()
            }, (error: any) => {
                console.log("error", error)
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error! Measure ID Not Exist."
                setTimeout(() => {
                    this.errorMessage = false;
                }, 2500)
                this.reset()
            });
    }

    editFun(val: any) {
        console.log("Edit Function", val)
        this.isUpdate = true;
        this.user.ID = val.Measure_ID_List_ID;
        this.user.measure_group_id = Number.parseInt(val.Measure_Group_List_ID);

        this.user.measure_ID = val.Measure_ID;

        console.log("User Object", this.user)
    }

    closeAlert() {
        this.successMessage = false
        this.errorMessage = false;
    }

    onBackdropKeyDown(event: KeyboardEvent) {
        // Add your logic here
        if (event.key === 'Escape') {
            this.closePopup();
        }
    }


    ngOnDestroy(): void {
        // Do not forget to unsubscribe the event
        this.dtTrigger.unsubscribe();
    }

    rerender(): void {
        try {
            if (this.isDataShow) {
                this.dtElement?.dtInstance.then((dtInstance: DataTables.Api) => {
                    // Destroy the table first
                    dtInstance.destroy();
                    // Call the dtTrigger to rerender again
                    this.dtTrigger.next();
                });
            } else {
                this.isDataShow = true;
                this.dtTrigger.next();
            }
        } catch (err) {
            console.log(err);
        }
    }

}




