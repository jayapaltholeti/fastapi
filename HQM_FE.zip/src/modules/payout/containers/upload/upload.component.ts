import { Component, OnInit } from '@angular/core';
import { PayoutService } from '../../services/payout.service';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { environment } from '../../../../environments/environment';
import bsCustomFileInput from 'bs-custom-file-input';
import { NgbDatepickerNavigateEvent } from '@ng-bootstrap/ng-bootstrap';


const APIEndpoint = environment.APIEndpoint;
@Component({
  selector: 'sb-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss'],
  standalone: false
})
export class UploadComponent implements OnInit {

  errorMessage: boolean = false;
  successMessage: boolean = false;
  errorMessageText?: string;
  successMessageText?: string;
  waitMessage: boolean = false;
  waitMessageText?: string;

  public serverEndPoint = APIEndpoint;
  hasBaseDropZoneOver?: boolean;
  hasAnotherDropZoneOver?: boolean;
  response?: string;
  GetAllMeasureGroupListUrl: string = "";
  uploadUrl: string = "";
  measureGrouplist?: [];


  clearTimer: null | ReturnType<typeof setInterval> = null
  importUrl: string = "";
  uploadUrl2: string = "";
  saveUrl: string = "";
  getFileTypesUrl: string = "";
  getTableDetailsUrl: string = "";
  getStatusListUrl: string = "";
  dmaAllList?: [];
  dmaStatusList?: [];

  getYearList?: [];
  getYearListUrl: string = "";
  getYearsUrl: string = "";
  sqlArray?: [];
  records?: [];
  userId?: string;
  formData?: any = new FormData();

  exceltoJson: any = {};

  fileObject: any = {
    year: null,
    measure_group_id: null,
    Measure_Group_Name: "",
    file: "",
    user_id: 1,
    Table_Name: "",
    originalName: ""
  };

  selectedFiles?: FileList;
  currentFile?: File;
  isUploadBtnDisabled?: boolean = false;
  isProcessBtnDisabled?: boolean = true;
  isPushBtnDisabled?: boolean = true;
  btnclassblue?: string = "btn btn-blue";
  btnclasssolid?: string = "btn btn-solid";

  uploadbtnclassblue?: string = this.btnclassblue;
  processbtnclasssolid?: string = this.btnclasssolid;
  pushbtnclasssolid?: string = this.btnclasssolid;


  browseButton: boolean = false;
  importButton: boolean = true;
  browseButtonContainer: boolean = false;
  buttonText: string = "Upload";
  buttonTextDropDown: string = "Select file";
  processButtonContainer: boolean = true;
  pushButtonContainer: boolean = true;
  isButtonUpload: boolean = false;
  isButtonProsess: boolean = false;
  selectYear: any = {};
  processAPI: string = "";
  importSFDC: string = "";
  importHealthChain: string = "";
  fileUpload: string = "";
  exportSFDC: string = "";
  updatePredictionScore: string = "";
  GetFilesCategory: string = "";

  selectedName: any = {
    fileTypeId: 0,
    fileType: "No Data",
    tablename: "NoData",
    fileName: "NoData",
    Operation: "Upload file"
  };

  fileUploadObject: any = {
    year: null,
    measure_group_id: null,
    Measure_Group_Name: '',
    file: '',
    user_id: 1,
    Table_Name: ''
  };

  payoutObject: any = {
    year: null,
    hospital_id: null,
    insurance_company_id: 1,
    measure_group_id: null,
    Measure_Group_Name: '',
    batchName: '',
    allocation: '',
    user_id: 1
  };

  sppercent: any;
  progressbarshow = false;
  getSPProgressUrl: string = "";
  currentUser: any;
  isDisabled: boolean = false;
  displayStyle = "none";
  isLoading: boolean = false;
  isDataShow: boolean = false;
  isButtonUploadDisabled(): boolean {
    return (
      this.fileUploadObject.year === null ||
      this.fileUploadObject.measure_group_id === null ||
      this.fileUploadObject.file === ''
    );
  }

  constructor(private readonly router: Router, private readonly payoutService: PayoutService) { }

  dateNavigate($event: NgbDatepickerNavigateEvent) {
    console.log("dateNavigate=== ", $event.next.month);
    console.log($event.next.year);
    this.fileObject.fileMonth = $event.next.month;
    this.fileObject.fileYear = $event.next.year;
  }

  ngOnInit(): void {
    bsCustomFileInput.init()
    this.dmaStatusList = [];
    this.browseButtonContainer = true;
    this.processButtonContainer = true;
    this.pushButtonContainer = true;
    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
    }
    this.successMessage = false;
    this.errorMessage = false;
    this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
    this.userId = this.currentUser.id;
    if (this.checkStatusPermission()) {
      this.isButtonUpload = false;
      console.log("prermission enabled......", this.isDisabled);
    } else {
      this.isButtonUpload = true;
      console.log("prermission Disabled......", this.isDisabled);
    }

    this.GetAllMeasureGroupListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/measuregroup/getlist";
    this.GetFilesCategory = this.serverEndPoint + "/rest/private/hqm/v1/hospital/file/get";

    //Import user uploaded csv files 
    this.updatePredictionScore = this.serverEndPoint + "/rest/private/dma/v1/updatepredictionscore";
    this.uploadUrl = this.serverEndPoint + "/rest/private/dma/v1/user/fileUpload";

    this.getFileTypesUrl = this.serverEndPoint + "/rest/private/dma/v1/user/files/type";
    this.getStatusListUrl = this.serverEndPoint + "/rest/private/dma/v1/user/dma/list";
    this.saveUrl = this.serverEndPoint + "/rest/private/dma/v1/user/movefile";
    this.getTableDetailsUrl = this.serverEndPoint + "/rest/private/dma/v1/table/get";
    this.exportSFDC = this.serverEndPoint + "/rest//private/app/v1/exportSFDC";
    //Import csv files from SFDC 
    this.importSFDC = this.serverEndPoint + "/rest/private/app/v1/importSFDC";
    //Import csv files from Healthchain
    this.importHealthChain = this.serverEndPoint + "/rest/private/dma/v1/user/importHealthChain";
    this.processAPI = this.serverEndPoint + "/rest/private/app/v1/process";
    this.getSPProgressUrl = this.serverEndPoint + "/rest/private/dma/v1/user/files/SPProgressStatus";
    this.getYearListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/year/get";
    this.getYearsUrl = this.serverEndPoint + "/rest/private/hqm/v1/getYears";
    this.getMeasureGroupListFunc();
    this.getStatusList();
    this.getYears();
  }

  openPopup() {
    this.displayStyle = "block";
  }
  closePopup() {
    this.displayStyle = "none";
  }
  // Get Measure Group List Function
  getMeasureGroupListFunc() {
    console.log("Inside Get MeasureGroup Func ");
    this.payoutService.postRequest(this.GetFilesCategory, this.payoutObject).subscribe((measureGrouplist: any) => {
      this.measureGrouplist = measureGrouplist.data;
      console.log(measureGrouplist, "measureGrouplist");
    }, (error: any) => {
      console.log(" Get MeasureGroup Func Error ");
      this.successMessage = false;
      this.errorMessage = true;
      this.errorMessageText = "Error."
    });
  }

  getYears() {
    this.payoutService.getRequest(this.getYearsUrl)
      .subscribe((yearList: any) => {
        const yearsList = yearList.data;
        this.selectYear = yearsList.map((yearObj: { Year: any; }) => ({
          item_id: yearObj.Year,
          item_text: yearObj.Year
        }));

      }, (error: any) => {
        console.log("Get Years Func Error ");
        this.successMessage = false;
        this.errorMessage = true;
        this.errorMessageText = "Getting Years Error."
      });
  }

  onSelectYear(val: any) {

    console.log(val);
    this.fileObject.year = val;
    if (this.fileObject.year === 'null') {
      this.isDataShow = false
    } else {
      this.fileObject.file = '';
      this.fileObject.originalName = '';
      this.isLoading = true;
      setTimeout(() => {
        this.getStatusList()
      }, 1000)
      setTimeout(() => {
        this.isLoading = false;
        this.isDataShow = true;
      }, 2000)
      this.fileUploadObject.measure_group_id = null;
      this.fileUploadObject.file = '';
      this.buttonTextDropDown = "Select file";
      // this.refreshStatusList()
    }
  }
  onDivKeyDown(event: KeyboardEvent) {
    if (event.key === 'Escape') {
      this.closePopup();
    }
  }

  onSelectMeasureGroup(val: any) {
    console.log("selected Measure group.", val);
    this.fileObject.year = this.fileUploadObject.year
    this.fileObject.measure_group_id = val.ID;
    this.fileObject.Measure_Group_Name = val.Categories;
    this.fileObject.Table_Name = val.Table_Name;
    // this.fileObject.originalName = val.originalName
    console.log("fileObject  .", this.fileObject);
  }

  CheckProgress() {
    this.progressbarshow = true;
    this.sppercent = 5;
    let intervalID = setInterval(() => {
      console.log('getSPStatus ==', this.fileObject.fileMonth, this.fileObject.procfileMonth);
      this.payoutService.postRequest(this.getSPProgressUrl, this.fileObject)
        .subscribe((response: any) => {
          this.sqlArray = response;
          sessionStorage.setItem('issprunning', '1');
          sessionStorage.setItem('processingmonth', this.fileObject.procfileMonth);
          sessionStorage.setItem('processingyear', this.fileObject.procfileYear);
          console.log("getSPStatus api res", JSON.stringify(response));
          console.log("getSPStatus api length", response.length);
          console.log("issprunning set", sessionStorage.getItem('issprunning'), this.fileObject.fileYear, this.fileObject.fileMonth, this.fileObject.procfileMonth, this.fileObject.procfileYear);
          if (response.length == 5) {
            clearInterval(intervalID);
            sessionStorage.setItem('issprunning', '0');
            //
            let static_result = "";
            this.payoutService.postRequest(this.updatePredictionScore, static_result)
              .subscribe((resultStatus: any) => {
                console.log("Prediction score updated.");
              }, (error: any) => {
                console.log("Prediction api error", error)
              });
            //
            this.ngOnInit();
          }
          let totalpercent = 0;
          for (let i = 0; response.length > i; i++) {
            console.log("For loop ==== ", response[i].percentage);
            totalpercent = totalpercent + response[i].percentage;
            console.log("totalpercent==== ", totalpercent);
            this.sppercent = totalpercent;
          }
          console.log("sppercent==== ", this.sppercent);
        }, (error: any) => {
          console.log("getSPStatus api error", error)
        });
    }, 5000);
  }

  on_proccess_button_click() {
    this.progressbarshow = true;
    this.fileObject.procfileMonth = this.fileObject.fileMonth;
    this.fileObject.procfileYear = this.fileObject.fileYear;
    //---
    this.CheckProgress();
    //---
    console.log("tablename------ ", this.fileObject);
    this.payoutService.postRequest(this.processAPI, this.fileObject)
      .subscribe((response: any) => {
        this.sqlArray = response;
        console.log("Process api res", response)
      }, (error: any) => {
      });
  }

  selectFile(event: any): void {
    console.log("File Selected------ ", event);
    this.errorMessage = false;
    this.errorMessageText = "";
    this.fileObject.file = event.target.files;
    this.fileObject.originalName = event.target.files[0].name
    if (this.fileObject.file) {
      this.buttonTextDropDown = event.target.files[0].name
    }
  }

  uploadAndProcessFile(): void {
    console.log("Inside upload And Process File...");

    if (!this.fileObject.measure_group_id) {
      this.setError("Please Select a File Type.");
      return;
    }

    if (!this.fileObject.year) {
      this.setError("Please Select a Year.");
      return;
    }

    console.log("File object ------ ", this.fileObject);

    const uploadedFiles = this.fileObject.file;
    if (!uploadedFiles) {
      this.setError("No file selected.");
      return;
    }

    const file: File | null = uploadedFiles.item(0);
    if (!file) {
      this.setError("Invalid file.");
      return;
    }

    this.currentFile = file;
    const fileName = file.name.toLowerCase();

    if (fileName.endsWith(".csv")) {
      this.ifCsvFile(uploadedFiles, file);
    } else if (fileName.endsWith(".xlsx") || fileName.endsWith(".xls")) {
      this.uploadFile(uploadedFiles, file);
    } else {
      this.setError("Upload Excel File.");
      return;
    }

    this.refreshStatusList();
  }

  private setError(message: string): void {
    this.errorMessage = true;
    this.errorMessageText = message;
  }


  async ifCsvFile(event: any, file: File): Promise<void> {
    console.log("Inside CSV Function");

    try {
      const csvData = await file.text();

      if (!this.isValidCsvContent(csvData, file)) {
        return;
      }

      this.uploadFile(event, file);

    } catch (error) {
      console.log("Error occurred while reading file!", error);
    }
  }

  private isValidCsvContent(csvData: string | null, file: File): boolean {
    if (!csvData) {
      this.setCsvError(file, "File is Empty...! Please upload the right file.!");
      return false;
    }

    const rows = csvData.split(/\r\n|\n/);
    const dataRowCount = rows.length - 1;

    if (dataRowCount < 1) {
      this.setCsvError(file, "File is Empty...! Please upload the right file.!");
      return false;
    }

    return true;
  }

  private setCsvError(file: File, message: string): void {
    this.successMessage = false;
    this.errorMessage = true;
    this.errorMessageText = `Error: ${file.name} ${message}`;
  }


  ifXlsxFile(fileInputEvent: any, file: any) {
    this.exceltoJson = {};
    let headerJson: any = {};
    /* wire up file reader */

    const reader: FileReader = new FileReader();
    reader.readAsBinaryString(fileInputEvent[0]);
    console.log("filename", fileInputEvent[0].name);
    this.exceltoJson['filename'] = fileInputEvent[0].name;
    reader.onload = (e: any) => {

      let csvData = reader.result;
      console.log(csvData, "file is empty or not");
      /* create workbook */
      const binarystr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(binarystr, { type: 'binary' });

      console.log(wb, "is data empty..");
      for (let i = 0; i < wb.SheetNames.length; ++i) {
        const wsname: string = wb.SheetNames[i];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];
        const data = XLSX.utils.sheet_to_json(ws); // to get 2d array pass 2nd parameter as object {header: 1}
        this.exceltoJson[`sheet${i + 1}`] = data;
        const headers = this.get_header_row(ws);
        headerJson[`header${i + 1}`] = headers;
      }
      this.exceltoJson['headers'] = headerJson;
      let isEmpty = headerJson.header1;

      if (isEmpty.length <= '0') {
        console.log(isEmpty.length, "true");
        this.successMessage = false;
        this.errorMessage = true;
        this.errorMessageText = "Error:" + file.filetype + " File is Empty...! Please upload the right file.! ";
        return;
      }

      let headersRow = this.getHeaderArrayXlsx(headerJson.header1);
      console.log("result====================================================", headersRow);
      let result = this.isEqual(headersRow, this.sqlArray, file);
      if (result?.status === "False") {
        this.successMessage = false;
        this.errorMessage = true;
        this.errorMessageText = result?.message;
        return;
      }
      // Calling Upload Function
      this.uploadFile(fileInputEvent, file)
    };
  }

  // Upload Function.
  uploadFile(fileInputEvent: any, file: any) {
    console.log("uploadFile====== ", fileInputEvent[0].name);
    this.errorMessage = false;
    this.successMessage = false;
    this.formData.delete('year')
    this.formData.delete('upload')
    this.formData.delete('user_id')
    this.formData.delete('Measure_Group_Name')
    this.formData.delete('Table_Name')
    this.formData.delete('measure_group_id')
    this.formData.delete('fileName')
    this.formData.delete('originalName')
    this.formData.append("year", this.fileObject.year);
    this.formData.append("measure_group_id", this.fileObject.measure_group_id);
    this.formData.append("Measure_Group_Name", this.fileObject.Measure_Group_Name);
    this.formData.append("Table_Name", this.fileObject.Table_Name);
    this.formData.append("user_id", this.fileObject.user_id);
    this.formData.append("upload", fileInputEvent[0]);
    this.formData.append("fileName", fileInputEvent[0].name);
    this.formData.append('originalName', this.fileObject.originalName)

    console.log(this.fileObject, "object data..");
    this.errorMessage = false;
    this.successMessage = false;
    this.waitMessage = true;
    this.waitMessageText = "Please Wait.. File Is Uploading..";
    this.payoutService.postRequest(this.uploadUrl, this.formData)
      .subscribe((response: any) => {

        console.log(response, "upload response")
        this.getStatusList();
        this.waitMessage = false;
        this.errorMessage = false;
        this.successMessage = true;
        this.successMessageText = "File Uploaded Successfully. Please Refer Below Table for the Current Status of Upload!";
        setTimeout(() => {
          this.successMessage = false;
          this.isDataShow = true
        }, 5000)
      }, (error: any) => {
        console.error(error);
      });
  }

  isEqual(a: any, b: any, file: any) {
    console.log("Calling isEqual Function..", a.length, "-", b.length);
    if (a.length == b.length) {
      return { 'status': "False", 'message': "Error: In a " + file.name + " File fields are missing.!  " + JSON.stringify(b) };
    } else {
      let successArray = [];
      for (let i = 0; i < b.length; i++) {
        console.log(a[i].COLUMN_NAME, b[i].COLUMN_NAME);
        if (a[i].COLUMN_NAME == b[i].COLUMN_NAME && a[i].ORDINAL_POSITION == b[i].ORDINAL_POSITION) {
          successArray.push(b[i].COLUMN_NAME);
          if (successArray.length === b.length) {
            return { 'status': "True", 'message': "Success" };
          }
        } else {
          return { 'status': "False", 'message': "Error: In a " + file.name + " file  : [ " + b[i].COLUMN_NAME + " ] field is missing on column postion number : [ " + b[i].ORDINAL_POSITION + " ]. Please Correct & Upload Right File.!" };
        }
      }
    }
  }

  getHeaderArray(csvRecordsArr: any) {
    const headers = (csvRecordsArr[0] as string).split(',');
    const headerArray = headers.map((header, index) => ({
      COLUMN_NAME: header.replace('"', ""),
      ORDINAL_POSITION: index + 1
    }));

    return headerArray;
  }

  getHeaderArrayXlsx(csvRecordsArr: any) {
    const headerArray = csvRecordsArr.map((value: string, index: number) => ({
      COLUMN_NAME: value.replace('"', ""),
      ORDINAL_POSITION: index + 1
    }));

    return headerArray;
  }

  getDataRecordsArrayFromCSVFile(csvRecordsArray: any, headerLength: any) {
    let csvArr = [];
    for (let i = 1; i < csvRecordsArray.length; i++) {
      let curruntRecord = (<string>csvRecordsArray[i]).split(',');
      if (curruntRecord.length == headerLength) {/*empty*/ }
    }
    // return csvArr;  
  }

  getFileTypeList() {
    console.log("inside getFileTypeList");
    this.fileObject.userId = this.userId
    this.payoutService.postRequest(this.getFileTypesUrl, this.fileObject)
      .subscribe((response: any) => {
        console.log(response, "GetFileTypes List Response1111111111......");
        this.dmaAllList = response;

      }, (error: any) => {
      });
  }

  checkStatus() {
    return this.dmaStatusList?.every((value: any) => value.Status === 'Completed')
  }

  checkStatusPermission() {
    let found = false;
    this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
      if (att.Access === 'Edit' && att.Module_Name === 'Upload') {
        found = true;
      }
    });
    return found;
  }

  stopRefreshStatusList() {
    return clearInterval(Number(this.clearTimer))
  }

  refreshStatusList() {
    this.clearTimer = setInterval(() => {
      console.log('Refresh Status List')
      this.getStatusList();
    }, 5000);
  }


  getStatusList() {
    console.log("Get List DMA Status getStatusListUrl", this.fileObject);
    if (this.fileObject.year) {
      this.fileObject.userId = this.userId
      this.fileObject.file = '';
      this.payoutService.postRequest(this.getStatusListUrl, this.fileObject)
        .subscribe((response: any) => {
          console.log(response, "get status List....");
          this.dmaStatusList = response;
          if (this.checkStatus()) {
            this.fileUploadObject.measure_group_id = null;
            this.fileUploadObject.file = '';
            this.buttonTextDropDown = "Select file";
            this.stopRefreshStatusList();
          }
        }, (error: any) => {
          console.log(error, "error get status List....");
          if (error.status == 404) {
            this.dmaStatusList = [];
          }
        });
    } else {
      this.dmaStatusList = [];
    }
  }

  getYear() {
    console.log("Get Year", this.fileObject);
    this.fileObject.userId = this.userId
    this.payoutService.postRequest(this.getYearListUrl, this.fileObject)
      .subscribe((response: any) => {
        console.log(response, "get year List....");
        this.getYearList = response;
      }, (error: any) => {
        console.log(error, "error get year List....");
        if (error.status == 404) {
          this.getYearList = [];
        }
      });
  }

  changefiletype(e: any) {
    console.log(this.selectedName, "selectedName");
    this.errorMessage = false;
    this.errorMessageText = "";
    this.successMessage = false;
    if (this.selectedName.fileTypeId == 2 || this.selectedName.fileTypeId == 3 || this.selectedName.fileTypeId == 4 || this.selectedName.fileTypeId == 10 || this.selectedName.fileTypeId == 12) {
      this.browseButtonContainer = true;
      this.buttonText = this.selectedName.Operation
    } else {
      this.browseButtonContainer = false;
      this.buttonText = this.selectedName.Operation

    }
  }

  onchangeMonth(changeMonth: any) {
    console.log("month", changeMonth);
    this.errorMessage = false;
    this.successMessage = false;
    this.fileObject.fileMonth = changeMonth;
  }

  onchangeYear(changeYear: any) {
    this.errorMessage = false;
    this.successMessage = false;
    this.fileObject.fileYear = changeYear
  }

  saveFile() {
    if (!this.fileObject.fileMonth) {
      this.errorMessage = true;
      this.errorMessageText = "Please Select a Month."
      return;
    }
    if (!this.fileObject.fileYear) {
      return;
    }
    let status = (this.checkIfExist(this.dmaAllList));
    if (status.status) {
      this.successMessage = false;
      this.errorMessage = true;
      this.errorMessageText = "Info : Please Upload All Files..!"
      return;
    }
    this.payoutService.postRequest(this.saveUrl, { "userId": this.userId, "month": this.fileObject.fileMonth, "year": this.fileObject.fileYear })
      .subscribe((response: any) => {
        console.log(response, "responce file save responce....");
        this.successMessage = true;
        this.errorMessage = false;
        this.successMessageText = response.message
        setTimeout(() => {
          this.successMessage = false;
        }, 2000)
        this.getFileTypeList();
      }, (error: any) => {
        if (error.status == 400) {
          this.successMessage = false;
          this.errorMessage = true;
          this.errorMessageText = error.error.message
          setTimeout(() => {
            this.errorMessage = false;
          }, 2000)
        }
      });
  }

  checkIfExist(dmaList: any) {
    const status = dmaList.some((item: { isUploaded: null; }) => item?.isUploaded === null);
    return { status };
  }


  import(APIURL: any) {
    console.log("Import url..", APIURL);
    this.errorMessage = false;
    this.successMessage = false;
    this.waitMessage = true;
    this.waitMessageText = "Please Wait... Leads Data Importing!";
    this.isButtonUpload = true;
    this.isButtonProsess = true;
    this.payoutService.postRequest(APIURL, this.fileObject)
      .subscribe((response: any) => {
        console.log(response, "Import SFDC or HealthChain responce");
        this.ngOnInit();
        this.waitMessage = false;
        this.errorMessage = false;
        this.successMessage = true;
        this.successMessageText = "Leads Data Imported Successfully.!";
        setTimeout(() => {
          this.successMessage = false;
        }, 2000)
        this.isButtonUpload = false;
        this.isButtonProsess = false;
      }, (error: any) => {
        this.successMessage = false;
        this.waitMessage = false;
        this.errorMessage = true;
        this.isButtonUpload = true;
        this.isButtonProsess = true;
        this.errorMessageText = "Leads Data Import Failed..!";
        setTimeout(() => {
          this.errorMessage = false;
        }, 2000)
      });
  }

  get_header_row(sheet: any) {
    let fileLength = Object.keys(sheet).length;
    if (fileLength > 0) {
      let headers = [];
      let range = XLSX.utils.decode_range(sheet['!ref']);
      let C, R = range.s.r; /* start in the first row */
      /* walk every column in the range */
      for (C = range.s.c; C <= range.e.c; ++C) {
        let cell = sheet[XLSX.utils.encode_cell({ c: C, r: R })] /* find the cell in the first row */
        // console.log("cell",cell)
        let hdr = "UNKNOWN " + C; // <-- replace with your desired default 
        if (cell?.t) {
          hdr = XLSX.utils.format_cell(cell);
          headers.push(hdr);
        }
      }
      return headers;
    } else {
      return [];
    }
  }


  pre() {
    //  document why this method 'pre' is empty



  }

  next() {
    // document why this method 'next' is empty


  }
}
