
export class UploadModel {
    Measure_Group_Name?: string;
    Insurance_Company_ID?: string;


}