import {  Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PayoutService } from '@modules/payout/services';
import { environment } from '../../../../environments/environment';
import { Router} from '@angular/router';

import { concat, Observable, of, Subject } from 'rxjs';
import { DataService, Person } from '../../services/data.service'
import { catchError, distinctUntilChanged, switchMap, tap } from 'rxjs/operators';
import { DisplayPayoutModel } from './display-payout.model';

const APIEndpoint = environment.APIEndpoint;

@Component({
    selector: 'sb-display-payout',
    // changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './display-payout.component.html',
    styleUrls: ['display-payout.component.scss'],
    standalone: false
})
export class DisplayPayoutComponent implements OnInit {

    //autocomplete
    people$?: Observable<Person[]>;
    peopleLoading = false;
    peopleInput$ = new Subject<string>();
    selectedPersons: Person[] = <any>[{ name: 'Karyn Wright' }, { name: 'Other' }];

    //

    alert: boolean = false;
    user: DisplayPayoutModel;
    addGroupForm?: FormGroup;
    submitted = false;
    errorMessage: boolean = false;
    successMessage: boolean = false;
    errorMessageText?: string;
    successMessageText?: string;
    waitMessage: boolean = false;
    waitMessageText?: string;
    addGroupUrl: string = '';
    public serverEndPoint = APIEndpoint;
    users: any;
    dataList: any;
    success: any
    error: any
    GetAllMeasureGroupListUrl: string = '';
    GetAllHospitalListUrl: string = '';
    GetBatchUrl: string = '';
    payoutCalculateUrl: string = '';
    updateMeasureContriUrl: string = '';
    allocationCalculateUrl: string = '';
    measureGrouplist: any;
    payoutDetailsListUrl: string = '';
    getCriteriaUrl: string = '';
    deleteBatchUrl: string = '';
    payoutDetailsList: any;
    CriteriaList: any;
    payoutObject: any = {
        // ID: '11',
        year: null,
        hospital_id: null,
        insurance_company_id: 1,
        measure_group_id: null,
        Measure_Group_Name: '',
        batchName: '',
        allocation: '',
        user_id: 1
    };
    getYearList?: [];
    getYearListUrl: string = "";
    updateObject: any = {
        hospital_id: null,
        measure_group_id: 1,
        performance_notes: '',
        comments: '',
        measure_contribution: '',
        r_id: '',
        user_id: 1
    }; 
    hospitalList: any;
    batchList: any;
    selectYear: any = {};
    payoutResultlist: any;
    isEdit: any;

    total_allocation: any;
    total_MeasureContribution: any;

    searchedOptions: any;
    currentUser: any;
    isDisabled: boolean = false;
    isDisplay: boolean = true;
    isLoading: boolean = false;
    isDataShow : boolean = false;
    displayModal: boolean = false;
    displayStyleDelete = 'none';
    isButtonDeleteDisabled(): boolean {
        return (
          this.payoutObject.batchName === null ||
          this.payoutObject.hospital_id === null ||
          this.payoutObject.year === ''
        );
      }
      ortest : string =''
    displayStyle = "none";
    Facility_id : any = ''
    constructor(private readonly formBuilder: FormBuilder, private readonly router: Router, private readonly payoutService: PayoutService, private readonly dataService: DataService) {
        this.user = new DisplayPayoutModel();
    }
    ngOnInit() {

        if (sessionStorage.getItem("token") === null) {
            this.router.navigate(['auth/login']);
        }
        this.GetAllMeasureGroupListUrl = this.serverEndPoint + "/rest/private/hqm/v1/payout/hospital/measuregrouplist";
        this.GetAllHospitalListUrl = this.serverEndPoint + "/rest/private/hqm/v1/payout/hospital/getlist";
        this.allocationCalculateUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/assignAllocation";
        this.payoutCalculateUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/calculate/payout";
        this.payoutDetailsListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/payout/display";
        this.updateMeasureContriUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/modifyAllocation";
        this.getCriteriaUrl = this.serverEndPoint + "/rest/private/hqm/v1/measuregroup/criteria";
        this.GetBatchUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/batch";
        this.deleteBatchUrl = this.serverEndPoint + "/rest/private/hqm/v1/delete/batch";

        this.getYearListUrl = this.serverEndPoint + "/rest/private/hqm/v1/hospital/year/get";
        this.selectYear = [{ item_id: 2019, item_text: 2019 }, { item_id: 2020, item_text: 2020 }, { item_id: 2021, item_text: 2021 }, { item_id: 2022, item_text: 2022 }, { item_id: 2023, item_text: 2023 }];
        this.errorMessage = false;

        this.currentUser = JSON.parse(sessionStorage.getItem('user') || '{}');
        this.user.User_Id = this.currentUser.ID;
        this.user.Insurance_Company_ID = this.currentUser.Insurance_Company_ID;
        this.user.role = this.currentUser.rols[0].Role;
        this.user.module_name = 'Group Hospital';
        if (this.checkStatus()) {
            this.isDisabled = false;
            console.log("prermission enabled......", this.isDisabled);
        } else {
            this.isDisabled = true;
            console.log("prermission Disabled......", this.isDisabled);
        }
        // Form Validation
        // this.addGroupForm = this.formBuilder.group({
        //     groupId: ['', [Validators.required]],
        //     groupName: ['', [Validators.required, Validators.pattern('^[a-zA-Z \-\']+')]],
        //     Insurance_Company_ID: [null]
        // });
        // this.getMeasureGroupListFunc();
        // this.getHospitalFunc();
        this.getYear();
        this.payoutObject.batchName = null;
        if (this.payoutObject.year && this.payoutObject.hospital_id && this.payoutObject.insurance_company_id) {
            this.getPayoutDetailsListFunc();
            this.getBatchFunc();
        }

    }
    // get f() { return this.addGroupForm?.controls; }


    trackByFn(item: Person) {
        return item.id;
    }

    private loadPeople() {
        this.people$ = concat(
            of([]), // default items
            this.peopleInput$.pipe(
                distinctUntilChanged(),
                tap(() => this.peopleLoading = true),
                switchMap(term => this.dataService.getPeople(term).pipe(
                    catchError(() => of([])), // empty list on error
                    tap(() => this.peopleLoading = false)
                ))
            )
        );
    }
    openPopup() {
        this.displayStyle = "block";
    }
    closePopup() {
        this.displayStyle = "none";
    }

    // Get Hospital
    getHospitalFunc() {
        console.log("Inside Get Hospital Func ");
        this.payoutService.postRequest(this.GetAllHospitalListUrl, this.payoutObject).subscribe((hospitalListResult: any) => {
            this.hospitalList = hospitalListResult.data;
            this.reset();
            console.log(this.hospitalList, "Hospital List");
        }, (error: any) => {
            console.log(" Get Hospital Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
        });
    }

    onDivKeyDown(event: KeyboardEvent): void {
  // TODO: implement logic
}

    checkStatus() {
        let found = false;
        this.user.permission = "View";
        this.currentUser.rols.forEach((att: { Access: string; Module_Name: string; }) => {
            if (att.Access === 'Edit' && att.Module_Name === 'Group Hospital') {
                this.user.permission = "Edit";
                found = true;
            }
        });
        return found;
    }

    // Get batch
    getBatchFunc() {
        console.log("Inside Get batchList Func ");
        this.payoutService.postRequest(this.GetBatchUrl, this.payoutObject).subscribe((batchResult: any) => {
            this.batchList = batchResult;
            this.reset();
            console.log(batchResult, "batchList");
        }, (error: any) => {
            console.log(" Get Hospital Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
            setTimeout(()=>{
                this.errorMessage = false;
            },2500)
        });
    }

    getYear() {
        console.log("Get Year");
        this.reset();
        this.payoutService.postRequest(this.getYearListUrl, this.payoutObject)
            .subscribe((response: any) => {
                console.log(response, "get year List....");
                this.getYearList = response.data;
            }, (error: any) => {
                console.log(error, "error get year List....");
                if (error.status == 404) {
                    this.getYearList = [];
                }
            });
    }

    onSelectMeasureGroup(val: any) {
        this.payoutObject.measure_group_id = val;

        if (this.payoutObject.year && this.payoutObject.measure_group_id && this.payoutObject.hospital_id && this.payoutObject.insurance_company_id) {

            this.reset();
            this.getPayoutDetailsListFunc();
            this.getCriteriaFunc();
        }
    }

    onSelectHospital(val: any) {
        this.payoutObject.hospital_id = val;
        this.payoutObject.measure_group_id = null;
        this.payoutObject.batchName = null;
        if(this.payoutObject.hospital_id == 'null'){
        this.batchList = []
       }else if (this.payoutObject.year && this.payoutObject.hospital_id) {
            this.reset();
            this.getBatchFunc();
        }
    }

    onSelectBatch(val: any) {
        this.payoutObject.batchName = val;
        if (this.payoutObject.year && this.payoutObject.hospital_id) {
            this.Facility_id = this.payoutObject.hospital_id
            this.getPayoutDetailsListFunc();
        }
        if (this.payoutObject.year && this.payoutObject.hospital_id && this.payoutObject.batchName) {
           if(!this.isDisabled){
            this.isDisplay =false;
           } 
        }
    }

    onSelectYear(val: any) {
        this.payoutObject.year = val;
        this.payoutObject.measure_group_id = null;
        this.payoutObject.batchName = null;
        this.payoutObject.hospital_id = null
        if(this.payoutObject.year == 'null'){
        this.hospitalList =[ ]
       }else{
        if (this.payoutObject.year && this.payoutObject.measure_group_id && this.payoutObject.hospital_id && this.payoutObject.insurance_company_id) {
            this.getPayoutDetailsListFunc()
        }
        if (this.payoutObject.year) {
            this.getHospitalFunc()
        }
       }
    }

    // Get Measure Group List Function
    getMeasureGroupListFunc() {
        console.log("Inside Get MeasureGroup Func ");
        this.payoutService.postRequest(this.GetAllMeasureGroupListUrl, this.payoutObject).subscribe((measureGrouplist: any) => {
            this.measureGrouplist = measureGrouplist.data;
            console.log(measureGrouplist, "measureGrouplist");
        }, (error: any) => {
            console.log(" Get MeasureGroup Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."

        });
    }

    Edit_measureId(val: any, index: any) {
        console.log("Edit Measure ID Function", index);
        console.log(val);
        this.isEdit = index;
    }

    // Update Measure ID Details.
    Update_measureId(val: any, index: any) {
        val.user_id = 1;
        console.log("updatet Measure Group", val);

        this.updateObject.hospital_id = val;
        this.updateObject.measure_group_id = val.Measure_ID;
        this.updateObject.performance_notes = val.Performance_Notes;
        this.updateObject.comments = val.Comments;


        this.updateObject.measure_contribution = val.Measure_Contribution;
        this.updateObject.r_id = val.r_id;
        this.updateObject.user_id = 1;
        console.log("Update Object", this.updateObject);

        this.errorMessage = false;
        this.successMessage = false;
        if (val.Measure_Contribution) {
            let regexp = /^[1-9]\d*(\.\d+)?$/;
            let isNumber = regexp.test(val.Measure_Contribution);

            if (!isNumber) {
                this.errorMessage = true;
                this.errorMessageText = "Error! Measure Contribution should be Number Only"
                return;
            } else if (val.Measure_Contribution > 100) {
                this.errorMessage = true;
                this.errorMessageText = "Error! Please Enter the Valid Measure Contribution."
                return;
            }
        }
        this.waitMessage = true;
        this.waitMessageText = "Warning! Please Wait... Updating Measure ID Details.";
        this.payoutService.postRequest(this.updateMeasureContriUrl, this.updateObject).subscribe((measureIDResult: any) => {
            this.getPayoutDetailsListFunc();
            console.log(measureIDResult, "measureIDResult");
            this.waitMessage = false;
            this.errorMessage = false;
            this.successMessage = true;
            this.successMessageText = "Success! Measure ID Details Updated Successfully.!";
            this.isEdit = null;
            setTimeout(() => {
                this.successMessage = false;
            }, 2500);
        }, (error: any) => {
            console.log(" Get payout Func Error ");
            this.waitMessage = false;
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error! Measure ID Details Updation Failed."
            setTimeout(()=>{
                this.errorMessage = false;
            },2500)
        });
    }

    // Get getPayoutDetailsListFunc
   getPayoutDetailsListFunc() {
  this.errorMessage = false;
  this.isLoading = true;
  this.payoutDetailsList = [];
  this.total_allocation = 0;
  this.total_MeasureContribution = 0;
  this.isDataShow = false;

  this.payoutService.postRequest(this.payoutDetailsListUrl, this.payoutObject)
    .subscribe(
      (payoutDetailsListResult: any) => {
        this.isLoading = false;
        this.payoutDetailsList = payoutDetailsListResult.data.recordset;

        let count = 0;
        let measureContributionCount = 0;

        if (this.payoutDetailsList.length > 0) {
          this.isDataShow = true;

          this.payoutDetailsList.forEach((detail: { Allocation_Percentage: any; Measure_Contribution: any; }) => {
            const allocation = detail?.Allocation_Percentage;
            const contribution = detail?.Measure_Contribution;

            if (allocation && allocation !== "null") {
              count += Number.parseFloat(allocation);
            }

            if (contribution) {
              measureContributionCount += Number.parseFloat(contribution);
            }
          });
        }

        this.total_allocation = count;
        this.total_MeasureContribution = measureContributionCount;
      },
      () => {
        this.successMessage = false;
        this.errorMessage = true;
        this.errorMessageText = "Error.";

        setTimeout(() => {
          this.errorMessage = false;
        }, 2500);
      }
    );
}

    // Get getPayoutDetailsListFunc
    getCriteriaFunc() {
        console.log("Inside Get getCriteriaFunc ", this.payoutObject);
        this.errorMessage = false;
        this.successMessage = false;
        this.payoutService.postRequest(this.getCriteriaUrl, this.payoutObject).subscribe((criteriaResult: any) => {
            this.CriteriaList = criteriaResult;
            console.log(this.CriteriaList, "CriteriaList");
        }, (error: any) => {
            console.log(" Get MeasureGroup Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error."
            setTimeout(()=>{
                this.errorMessage = false;
            },2500)
        });
    }

    // Allocation Calculation
    allocation() {
        console.log("Inside Allocation. ");
        console.log("Allocation Object. ", this.payoutObject);
        this.errorMessage = false;
        this.successMessage = false;
        if (this.payoutObject.year == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Year."
            return;
        }
        if (this.payoutObject.hospital_id == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Hospital."
            return;
        }
        if (this.payoutObject.measure_group_id == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Measure Group."
            return;
        }
        if (this.payoutObject.batchName == '') {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Enter the Batch Name."
            return;
        }
        if (this.payoutObject.allocation) {
            let isNumber = /^\d+$/.test(this.payoutObject.allocation);
            if (!isNumber) {
                this.errorMessage = true;
                this.errorMessageText = "Error! Allocation Percentage should be Number Only"
                return;
            } else if (this.payoutObject.allocation > 100) {
                this.errorMessage = true;
                this.errorMessageText = "Error! Please Enter the Valid Percentage."
                return;
            }
        } else {
            this.errorMessage = true;
            this.errorMessageText = "Error! Allocation Percentage should not be Empty."
            return;
        }
        this.waitMessage = true;
        this.waitMessageText = "Warning! Please Wait... Percentage (%) is Allocating to Measure Ids.";
        this.payoutService.postRequest(this.allocationCalculateUrl, this.payoutObject).subscribe((measureGrouplist: any) => {
            console.log(measureGrouplist, "measureGrouplist");
            if (measureGrouplist.status == 201) {
                this.waitMessage = false;
                this.errorMessage = false;
                this.successMessage = true;
                this.successMessageText = measureGrouplist.message;
                setTimeout(()=>{
                    this.successMessage = false;
                },2500)
                this.getPayoutDetailsListFunc();
            }
        }, (error: any) => {
            console.log(" Get Allocation Func Error ", error);
            this.waitMessage = false;
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = error.error.message
            setTimeout(()=>{
                this.errorMessage = false;
            },2500)
        });
    }



    // Payout Calculation
    payout() {
        console.log("Inside payout.", this.payoutObject);
        this.errorMessage = false;
        this.successMessage = false;
        if (this.payoutObject.year == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Year."
            return;
        }
        if (this.payoutObject.hospital_id == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Hospital."
            return;
        }
        if (this.payoutObject.measure_group_id == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Select a Measure Group."
            return;
        }
        if (this.payoutObject.batchName == '' || this.payoutObject.batchName == null) {
            this.errorMessage = true;
            this.errorMessageText = "Error! Please Enter the Batch Name."
            return;
        }

        this.waitMessage = true;
        this.waitMessageText = "Warning! Please Wait... Payout is Calculating.";
        this.payoutService.postRequest(this.payoutCalculateUrl, this.payoutObject).subscribe((payoutResult: any) => {
            console.log(payoutResult, "payoutResultlist");
            console.log("Payout calculated Successfully. ");
            this.waitMessage = false;
            this.errorMessage = false;
            this.successMessage = true;
            this.successMessageText = "Success! Payout Calculated Successfully.!";
            setTimeout(()=>{
                this.successMessage = false;
            },2500)
            this.getPayoutDetailsListFunc();
        }, (error: any) => {
            console.log(" Get payout Func Error ", error);
            if (error.error.status === 409) {
                this.waitMessage = false;
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = error.error.message;
                setTimeout(()=>{
                    this.errorMessage = false;
                },2500)
            } else {
                this.waitMessage = false;
                this.successMessage = false;
                this.errorMessage = true;
                this.errorMessageText = "Error. Payout Calculation Failed."
                setTimeout(()=>{
                    this.errorMessage = false;
                },2500)
            }
        });
    }

    reset() {
        this.isEdit = null;
    }

    deleteBatch() {

        this.displayStyleDelete = 'block';
    }
    
    cancelDelete() {
        this.displayStyleDelete = 'none';
    }
    confirmDeleteAction() {
        this.displayStyleDelete = 'none';
        this.deleteBatchFunc();
    }
    // Get Measure Group List Function
    deleteBatchFunc() {
        console.log("Delete Function Called." , this.payoutObject);
        this.payoutService.postRequest(this.deleteBatchUrl, this.payoutObject).subscribe((batchResult: any) => {
            console.log("batch Deleted.");
            this.errorMessage = false;
            this.successMessage = true;
            this.successMessageText = "Success! Batch Deleted Successfully."
            setTimeout(()=>{
            this.successMessage = false;
            },2500)
            this.ngOnInit();
        }, (error: any) => {
            console.log(" Get MeasureGroup Func Error ");
            this.successMessage = false;
            this.errorMessage = true;
            this.errorMessageText = "Error.";
             setTimeout(()=>{
                this.errorMessage = false;
            },2500)
            this.reset();
        });
    }

    //Create api addgroup system
    // onSubmit() {
    // console.log(this.addGroupForm?.value)
    // this.submitted = true;
    // if (this.addGroupForm?.invalid) {
    //     this.addGroupForm.reset();
    //     return;
    // }
    // this.hospitalService.addGroupsystem(this.addGroupUrl, this.user)
    //     .subscribe((response: any) => {
    //         console.log(this.user, "user")
    //         console.log("Responce", response)
    //         this.addGroupForm?.reset(this.user);
    //         this.errorMessage = false;
    //         this.successMessage = true;
    //         this.successMessageText = "Success!"
    //     }, (error: any) => {
    //         this.successMessage = false;
    //         this.errorMessage = true;
    //         this.errorMessageText = "Error."
    //     });
    // }
}




