
export class DisplayPayoutModel {
    Group_ID?: string;
    Group_Name?: string;
    Insurance_Company_ID?: string;
    module_name?: string; 
    User_Id?: any;
    ID?: any;
    role?: string; 
    permission?: string;
}