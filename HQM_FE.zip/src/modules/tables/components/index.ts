
import { SortIconComponent } from './sort-icon/sort-icon.component';

export const components = [ SortIconComponent];

export * from './sort-icon/sort-icon.component';
