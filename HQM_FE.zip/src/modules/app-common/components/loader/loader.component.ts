import { Component, OnInit, Input } from '@angular/core';

@Component({
    selector: 'sb-loader',
    templateUrl: './loader.component.html',
    styleUrls: ['./loader.component.scss'],
    standalone: false
})
export class LoaderComponent implements OnInit {
  @Input() isLoading: boolean = false;
  @Input() isScaleLoading: boolean = false;

  constructor() { }

  ngOnInit(): void { /*empty*/ }

}
