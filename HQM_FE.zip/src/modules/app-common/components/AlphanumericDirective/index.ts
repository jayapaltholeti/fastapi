import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[appAlphanumeric]',
    standalone: false
})
export class AlphanumericDirective {

    constructor(private readonly el: ElementRef) { }
  
    @HostListener('input', ['$event']) onInputChange(event: Event) {
      const initialValue = this.el.nativeElement.value;
      this.el.nativeElement.value = initialValue.replaceAll(/[^a-zA-Z0-9()_/\- ]/g, '');
      if (initialValue !== this.el.nativeElement.value) {
        event.stopPropagation();
      }
    }
  }