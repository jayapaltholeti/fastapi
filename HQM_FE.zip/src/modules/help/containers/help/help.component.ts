import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';


@Component({
    selector: 'sb-help',
    changeDetection: ChangeDetectionStrategy.OnPush,
    templateUrl: './help.component.html',
    styleUrls: ['help.component.scss'],
    standalone: false
})
export class HelpComponent implements OnInit {
    errorMessage = false; errorMessageText = ''; successMessage = false; successMessageText = ''; waitMessage = false; waitMessageText = ''
    constructor() { }
    ngOnInit() { }


    // openPdf() {
    //     window.open('', '_blank')
    // }
}
