
import { HelpComponent } from './help/help.component';

export const containers = [HelpComponent];

export * from './help/help.component';









