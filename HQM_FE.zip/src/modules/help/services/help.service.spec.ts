import { TestBed } from '@angular/core/testing';

import {PayoutService} from './help.service'

describe('HospitalService', () => {
    let hospitalService: PayoutService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [PayoutService],
        });
        hospitalService = TestBed.inject(PayoutService);
    });

    describe('getAuth$', () => {
        it('should return Observable<Auth>', () => {
            hospitalService.getAuth$().subscribe(response => {
                expect(response).toEqual({});
            });
        });
    });
});

