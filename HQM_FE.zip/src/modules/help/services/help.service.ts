import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Router, ActivatedRoute } from '@angular/router';


import {ResDataModal} from '../../dashboard/containers/view-grid/resDataModal';

@Injectable({
  providedIn: 'root'
})
export class PayoutService {

  httpHeaders?: HttpHeaders;
  constructor(private httpClient: HttpClient, private router: Router) { }

  setHeader() {
    if (sessionStorage.getItem("token") === null) {
      this.router.navigate(['auth/login']);
    }
    this.httpHeaders = new HttpHeaders().set('Accept', 'application/json');
    // this.httpHeaders = this.httpHeaders.append('Content-Type', 'text');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Origin', '20.124.91.34');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Methods', 'GET,HEAD,OPTIONS,POST,PUT');
    this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    // this.httpHeaders = this.httpHeaders.append('Access-Control-Allow-Credentials', 'true');//
    this.httpHeaders = this.httpHeaders.append("Authorization", 'Bearer ' + sessionStorage.getItem("token"));
  }

  getRequest(url: string): Observable<any> {
    this.setHeader();
    return this.httpClient.get(url, { headers: this.httpHeaders, withCredentials: true });
  }

  postRequest(url: string, payload: any): Observable<any> {
    // console.log('url', url); 
    this.setHeader();
    return this.httpClient.post(url, payload, { headers: this.httpHeaders, withCredentials: true });
  }

}
