/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';

import { DataTablesModule } from 'angular-datatables';

/* Modules */
import { AppCommonModule } from '@common/app-common.module';
import { NavigationModule } from '@modules/navigation/navigation.module';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import {MatAutocompleteModule} from '@angular/material/autocomplete';



/* Components */
import * as helpComponent from './components'

/* Containers */
import * as helpContainers from './containers'

/* Guards */
import * as mastersGuards from './guards'

/* Services */
import * as hospitalServices from './services'

import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        ReactiveFormsModule,
        FormsModule,
        AppCommonModule,
        NavigationModule,
        DataTablesModule,
         NgMultiSelectDropDownModule.forRoot()

    ],

    providers: [...hospitalServices.services, ...mastersGuards.guards],
    declarations: [...helpContainers.containers, ...helpComponent.components],
    exports: [...helpContainers.containers, ...helpComponent.components],
})
export class HelpModule { }

