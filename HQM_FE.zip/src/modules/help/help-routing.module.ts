/* tslint:disable: ordered-imports*/
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SBRouteData } from '@modules/navigation/models';

/* Module */
import { HelpModule } from './help.module'

import * as helpContainers from './containers'

/* Guards */
import * as mastersGuards from './guards'

/* Routes */
export const ROUTES: Routes = [


    {
        path: 'help',
        canActivate: [],
        component: helpContainers.HelpComponent,
        data: {
            title: 'Page-Help - HQM',
        } as SBRouteData,
    },

];

@NgModule({
    imports: [HelpModule, RouterModule.forChild(ROUTES)],
    exports: [RouterModule],
})
export class HelpRoutingModule { }
