export const environment = {
    production: true,
    APIEndpoint:'https://hqm-be-dev-app-01.yellowwater-7db21bcc.eastus2.azurecontainerapps.io/api',
    reportsUrl: 'https://app.powerbi.com/reportEmbed?reportId=b0c16127-63e6-4015-b3a9-ffecf9ab48de&autoAuth=true&ctid=2c93d3cb-f285-49c4-8265-fba1bd1fe468',
    analyticsUrl:'https://app.powerbi.com/reportEmbed?reportId=504bb184-404f-4568-bef3-1be9955e6ca0&autoAuth=true&ctid=2c93d3cb-f285-49c4-8265-fba1bd1fe468'
};