import { HTTP_INTERCEPTORS, provideHttpClient, withInterceptorsFromDi, withXsrfConfiguration } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DataTablesModule } from 'angular-datatables';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { BnNgIdleService } from 'bn-ng-idle';
import { NgxSliderModule } from '@angular-slider/ngx-slider';
import { NgChartsModule } from 'ng2-charts';
import { XsrfInterceptor } from './xsrf.interceptor';
import { SharedModule } from './shared/shared.module';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent
  ],
  bootstrap: [AppComponent], imports: [BrowserModule,
    // NgxPaginationModule,
    AppRoutingModule,
    DataTablesModule,
    SharedModule,
    BsDatepickerModule.forRoot(),
    NgxSliderModule,
    FormsModule,
    NgMultiSelectDropDownModule.forRoot(),
    NgChartsModule], providers: [
      BnNgIdleService,
      {
        provide: HTTP_INTERCEPTORS,
        useClass: XsrfInterceptor,
        multi: true,
      },
      provideHttpClient(withInterceptorsFromDi(), withXsrfConfiguration({})),
    ]
})
export class AppModule { }
