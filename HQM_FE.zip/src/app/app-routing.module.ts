import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
    {
        path: '',
        pathMatch: 'full',
        redirectTo: '/auth/login',
    },
    // {path:'file', component: FileuploadComponent},
    {
        path: 'charts',
        loadChildren: () =>
            import('modules/charts/charts-routing.module').then(m => m.ChartsRoutingModule),
    },
    {
        path: 'masters',
        loadChildren: () =>
            import('modules/masters/masters-routing.module').then(m => m.MastersRoutingModule),
    },
    {
        path: 'reports',
        loadChildren: () =>
            import('modules/reports/reports-routing.module').then(m => m.ReportsRoutingModule),
    },
    {
        path: 'administration',
        loadChildren: () =>
            import('modules/administration/administration-routing.module').then(m => m.AdministrationRoutingModule),
    },
    {
        path: 'payout',
        loadChildren: () =>
            import('modules/payout/payout-routing.module').then(m => m.PayoutRoutingModule),
    },
    {
        path: 'dashboard',
        loadChildren: () =>
            import('modules/dashboard/dashboard-routing.module').then(
                m => m.DashboardRoutingModule
            ),
    },
    {
        path: 'auth',
        loadChildren: () =>
            import('modules/auth/auth-routing.module').then(m => m.AuthRoutingModule),
    },
    {
        path: 'error',
        loadChildren: () =>
            import('modules/error/error-routing.module').then(m => m.ErrorRoutingModule),
    },
    {
        path: 'tables',
        loadChildren: () =>
            import('modules/tables/tables-routing.module').then(m => m.TablesRoutingModule),
    },
    {
        path: 'version',
        loadChildren: () =>
            import('modules/utility/utility-routing.module').then(m => m.UtilityRoutingModule),
    },
    {
        path: 'help',
        loadChildren: () =>
            import('modules/help/help-routing.module').then(m => m.HelpRoutingModule),
    },
    {
        path: '**',
        pathMatch: 'full',
        loadChildren: () =>
            import('modules/error/error-routing.module').then(m => m.ErrorRoutingModule),
    },
];

@NgModule({
    imports: [RouterModule.forRoot(routes)],
    exports: [RouterModule],
})
export class AppRoutingModule { }
