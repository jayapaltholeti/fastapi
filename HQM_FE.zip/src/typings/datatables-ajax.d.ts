// src/typings/datatables-ajax.d.ts

// Minimal type for DataTables ajax callback
declare type DataTablesAjaxCallback = (data: any) => void;

// Optional: if you want a stronger type, you can replace `any` with the shape of your server response
// declare type DataTablesAjaxCallback = (data: { recordsTotal: number; recordsFiltered: number; data: any[] }) => void;
