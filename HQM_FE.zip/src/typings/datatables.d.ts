// src/typings/datatables.d.ts
/// <reference types="datatables.net" />

// Re‑export DataTables namespace so TS 4.4+ accepts it
declare namespace DataTables {
  type Settings = DataTables.SettingsConfig;
  type Api = DataTables.ApiInstance;
}
